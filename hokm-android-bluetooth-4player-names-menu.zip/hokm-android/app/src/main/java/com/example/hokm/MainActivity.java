package com.example.hokm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private BluetoothGameManager bluetooth;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF1F6B47);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("بله", (d,w)->r.confirm()).setNegativeButton("خیر", (d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show(); return true;
            }
        });
        bluetooth = new BluetoothGameManager(this, web);
        web.addJavascriptInterface(new BluetoothBridge(), "AndroidBluetooth");
        setContentView(web);
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html"); else web.restoreState(savedInstanceState);
    }
    private class BluetoothBridge {
        @JavascriptInterface public void requestPermissions(){ bluetooth.requestPermissions(); }
        @JavascriptInterface public void startServer(){ bluetooth.startServer(); }
        @JavascriptInterface public void startServer4(){ bluetooth.startServer(3); }
        @JavascriptInterface public void listPaired(){ bluetooth.listPaired(); }
        @JavascriptInterface public void connect(String address){ bluetooth.connect(address); }
        @JavascriptInterface public void send(String json){ bluetooth.send(json); }
        @JavascriptInterface public void sendToSeat(int seat, String json){ bluetooth.sendToSeat(seat, json); }
        @JavascriptInterface public void stop(){ bluetooth.stop(); }
    }
    @Override protected void onDestroy(){ if(bluetooth!=null) bluetooth.stop(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle out){ super.onSaveInstanceState(out); web.saveState(out); }
}
