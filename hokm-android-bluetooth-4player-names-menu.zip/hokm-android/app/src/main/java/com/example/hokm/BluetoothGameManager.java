package com.example.hokm;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.UUID;

/** Bluetooth RFCOMM transport for 2-player and 4-player games.
 *  In 4-player mode the host is seat 0 and accepts three client phones (seats 1..3).
 */
public class BluetoothGameManager {
    private static final String SERVICE_NAME = "Hokm Bluetooth Game";
    private static final UUID UUID_SERVICE = UUID.fromString("7b9e5f8c-0d54-4d45-9a8f-6e6a5f2b1c10");
    private final Activity activity;
    private final WebView web;
    private final BluetoothAdapter adapter;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final CopyOnWriteArrayList<Peer> peers = new CopyOnWriteArrayList<>();
    private BluetoothServerSocket serverSocket;
    private BluetoothSocket clientSocket;
    private OutputStream clientOut;
    private volatile boolean stopped;
    private volatile boolean host;
    private volatile int maxPeers = 1;

    private static class Peer {
        final int seat; final BluetoothSocket socket; final OutputStream out;
        Peer(int seat, BluetoothSocket socket) throws IOException { this.seat=seat; this.socket=socket; this.out=socket.getOutputStream(); }
    }

    public BluetoothGameManager(Activity activity, WebView web) {
        this.activity = activity; this.web = web; adapter = BluetoothAdapter.getDefaultAdapter();
    }
    private boolean allowed() {
        if (Build.VERSION.SDK_INT >= 31)
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return true;
    }
    public void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 31) activity.requestPermissions(new String[]{
            Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE
        }, 701);
    }
    public void startServer() { startServer(1); }
    public void startServer(int maxClients) {
        if (adapter == null) { emitError("این گوشی بلوتوث ندارد."); return; }
        if (!allowed()) { requestPermissions(); return; }
        stop(); stopped=false; host=true; maxPeers=Math.max(1, Math.min(3,maxClients));
        io.execute(() -> {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, UUID_SERVICE);
                emit("{\"type\":\"serverReady\",\"max\":"+maxPeers+"}");
                while (!stopped && peers.size() < maxPeers) {
                    BluetoothSocket s = serverSocket.accept();
                    if (stopped) { try{s.close();}catch(Exception ignored){} break; }
                    int seat = peers.size()+1;
                    Peer p = new Peer(seat,s); peers.add(p);
                    sendRaw(p, "{\"type\":\"seat\",\"seat\":"+seat+"}");
                    emit("{\"type\":\"peerConnected\",\"seat\":"+seat+",\"count\":"+peers.size()+"}");
                    readPeer(p);
                }
                if (serverSocket != null) { try { serverSocket.close(); } catch(Exception ignored){} serverSocket=null; }
            } catch (Exception e) { if(!stopped) emitError(e.getMessage()); }
        });
    }
    private void readPeer(Peer p) {
        io.execute(() -> {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(p.socket.getInputStream(), StandardCharsets.UTF_8));
                String line;
                while(!stopped && (line=br.readLine())!=null) {
                    String safe=line.replace("\\","\\\\").replace("\"","\\\"");
                    emit("{\"type\":\"peerMessage\",\"seat\":"+p.seat+",\"payload\":"+JSONObject.quote(line)+"}");
                }
            } catch(Exception ignored) {}
            finally {
                peers.remove(p); if(!stopped) emit("{\"type\":\"peerDisconnected\",\"seat\":"+p.seat+",\"count\":"+peers.size()+"}");
                try{p.socket.close();}catch(Exception ignored){}
            }
        });
    }
    public void listPaired() {
        if(adapter==null){emitError("این گوشی بلوتوث ندارد.");return;} if(!allowed()){requestPermissions();return;}
        try { JSONArray a=new JSONArray(); for(BluetoothDevice d:adapter.getBondedDevices()){JSONObject o=new JSONObject();o.put("name",d.getName()==null?"گوشی بدون نام":d.getName());o.put("address",d.getAddress());a.put(o);} JSONObject r=new JSONObject();r.put("type","devices");r.put("items",a);emit(r.toString()); }
        catch(Exception e){emitError(e.getMessage());}
    }
    public void connect(String address) { if(!allowed()){requestPermissions();return;} stop();stopped=false;host=false;maxPeers=1;
        io.execute(()->{try{BluetoothDevice d=adapter.getRemoteDevice(address);clientSocket=d.createRfcommSocketToServiceRecord(UUID_SERVICE);clientSocket.connect();clientOut=clientSocket.getOutputStream();emit("{\"type\":\"connected\"}");BufferedReader br=new BufferedReader(new InputStreamReader(clientSocket.getInputStream(),StandardCharsets.UTF_8));String line;while(!stopped&&(line=br.readLine())!=null){final String msg=line;activity.runOnUiThread(()->emitJs(msg));}}catch(Exception e){if(!stopped)emitError(e.getMessage());}finally{if(!stopped)emit("{\"type\":\"disconnected\"}");}});
    }
    private void sendRaw(Peer p,String json){try{p.out.write((json+"\n").getBytes(StandardCharsets.UTF_8));p.out.flush();}catch(Exception e){try{p.socket.close();}catch(Exception ignored){}}}
    public void send(String json){io.execute(()->{if(host){for(Peer p:peers)sendRaw(p,json);}else{try{if(clientOut!=null){clientOut.write((json+"\n").getBytes(StandardCharsets.UTF_8));clientOut.flush();}}catch(Exception e){emitError(e.getMessage());}}});}
    public void sendToSeat(int seat, String json){io.execute(()->{if(!host)return;for(Peer p:peers){if(p.seat==seat){sendRaw(p,json);break;}}});}
    public void stop(){stopped=true;try{if(serverSocket!=null)serverSocket.close();}catch(Exception ignored){}try{if(clientSocket!=null)clientSocket.close();}catch(Exception ignored){}for(Peer p:peers){try{p.socket.close();}catch(Exception ignored){}}peers.clear();serverSocket=null;clientSocket=null;clientOut=null;}
    private void emitError(String m){String msg=m==null?"خطای بلوتوث":m.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ");emit("{\"type\":\"error\",\"message\":\""+msg+"\"}");}
    private void emit(String json){activity.runOnUiThread(()->emitJs(json));}
    private void emitJs(String json){String safe=JSONObject.quote(json);web.evaluateJavascript("window.btReceive("+safe+");",null);}
}
