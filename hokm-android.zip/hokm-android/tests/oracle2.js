// آزمون تشخیصی (نه رقیب واقعی): بازیکن ۲ نفره‌ای که کارت‌های حریف را می‌بیند (تقلب) در برابر نسخهٔ فعلی.
// اگر حتی با دیدن همهٔ کارت‌ها برتری کم باشد، یعنی سقف مهارتِ قابل‌کسب از «استنباط» پایین است.
const path=require('path'),vm=require('vm');
const {load}=require('./lib/ctx2'),{mkDeal,deal,newStats,rnd}=require('./lib/arena2');
const arg=(k,d)=>{const i=process.argv.indexOf('--'+k);return i>0?process.argv[i+1]:d};
const N=+arg('deals',40),html=path.join(__dirname,'../legacy-webview/index.html');
const A=load(html);vm.runInContext('BOT2_MS=150',A);A.side=0;
const O=load(html);O.side=1;
const st=newStats();let win=0,tot=0;
for(let d=0;d<N;d++){
  const D=mkDeal();
  for(const par of [0,1]){ // بازیکن آگاه (oracle) روی صندلی par
    const bots=[par===0?O:A,par===1?O:A];
    const dl=deal(bots,D,st);
    const H=dl.H.map(h=>h.map(c=>({s:c.s,r:c.r}))),trump=dl.T,hk=dl.hk;let tk=[0,0],kt=null,trick=[],played=[],vo=[[],[]],turn=hk;
    const beats=(c,b)=>c.s===b.s?c.r>b.r:c.s===trump;let res=-1;
    while(res<0){
      const hand=H[turn],led=trick.length?trick[0].c.s:-1;let L=hand;if(led>=0){const f=hand.filter(c=>c.s===led);if(f.length)L=f}
      const X=turn,Oo=1-turn,mp=p=>p===X?1:0;let c;
      if(bots[X]===O&&L.length>1){
        O.__set({hands:[H[Oo],H[X]],tk:[tk[Oo],tk[X]],kt:kt==null?null:mp(kt),hk:mp(hk),trump,trick:trick.map(t=>({p:mp(t.p),c:t.c})),played,gone:[],vo:[vo[Oo],vo[X]]});
        const best=vm.runInContext(`(function(){exLim=60000;let bi=0,bv=-1e9;const L=legal2(1);for(let i=0;i<L.length;i++){const hs=[Q.hands[0],Q.hands[1]];let v=hs[1].length<=7?exact2(hs,L[i]):null;if(v===null)v=roll2(hs,1,L[i]);if(v>bv){bv=v;bi=i}}return L[bi]})()`,O);
        c=L.find(x=>x.s===best.s&&x.r===best.r)||L[0];
      }else if(L.length===1)c=L[0];
      else{bots[X].__set({hands:[H[Oo],H[X]],tk:[tk[Oo],tk[X]],kt:kt==null?null:mp(kt),hk:mp(hk),trump,trick:trick.map(t=>({p:mp(t.p),c:t.c})),played,gone:dl.gone[X],vo:[vo[Oo],vo[X]]});const mv=bots[X].__move();c=L.find(x=>x.s===mv.s&&x.r===mv.r)||L[0]}
      if(trick.length&&c.s!==trick[0].c.s)vo[X].push(trick[0].c.s);
      played.push(c.s*20+c.r);H[X]=H[X].filter(x=>x!==c);trick.push({p:X,c});
      if(trick.length<2){turn=Oo;continue}
      const w=beats(trick[1].c,trick[0].c)?trick[1].p:trick[0].p;tk[w]++;trick=[];turn=w;
      const hs=tk[0]>=7?0:tk[1]>=7?1:-1;if(hs>=0){if(tk[1-hs]===0&&kt==null)kt=hs;if(tk[1-hs]>0||tk[hs]===13)res=hs}
    }
    tot++;if(res===par)win++;
  }
}
const p=win/tot;console.log(`بازیکن آگاه از کارت‌های حریف (تقلب) در برابر ربات فعلی: ${(100*p).toFixed(1)}% ±${(196*Math.sqrt(p*(1-p)/tot)).toFixed(1)} (${tot} دور)`);
