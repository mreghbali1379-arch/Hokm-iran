// آزمون نشت اطلاعات: اگر محتوای کارت‌های پنهان حریف/یار را عوض کنیم (با همان تعداد و همان بذر تصادفی)،
// تصمیم ربات باید دقیقاً همان بماند. هر تفاوت یعنی ربات کارت‌های پنهان را «دیده».
// استفاده: node tests/leak.js [--positions 200]
const path=require('path'),vm=require('vm');
const arg=(k,d)=>{const i=process.argv.indexOf('--'+k);return i>0?process.argv[i+1]:d};
const P=+arg('positions',200),html=arg('file',path.join(__dirname,'../app/src/main/assets/index.html'));
const rnd=n=>Math.floor(Math.random()*n);
function seeded(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const realRandom=Math.random;
const pick=(f,seed)=>{Math.random=seeded(seed);try{return f()}finally{Math.random=realRandom}};
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=rnd(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
// ---------- ۴ نفره ----------
{
  const {load}=require('./lib/ctx4'),ctx=load(html);vm.runInContext('FIX_N=40;',ctx);
  let same=0,diffSeed=0,n=0;
  while(n<P){
    const d=[];for(let s=0;s<4;s++)for(let r=2;r<=14;r++)d.push({s,r});shuffle(d);
    const H=[0,1,2,3].map(i=>d.slice(i*13,i*13+13)),tr=rnd(4),hk=rnd(4);
    let trick=[],tk=[0,0],kt=null,seen=[],voids=[[],[],[],[]],plays=[],turn=hk;
    const beats=(c,b)=>c.s===b.s?c.r>b.r:c.s===tr,bestOf=t=>{let b=t[0];for(const x of t)if(beats(x.c,b.c))b=x;return b};
    const target=rnd(40)+4;let k=0,done=false;
    while(!done){
      const hand=H[turn],led=trick.length?trick[0].c.s:-1;let L=hand;if(led>=0){const f=hand.filter(c=>c.s===led);if(f.length)L=f}
      if(k===target&&L.length>1&&hand.length<=11){
        const st={H,trump:tr,hakem:hk,trick,tk,kt,seen,voids,plays,sc:[rnd(5),rnd(5)]};
        // نسخهٔ دستکاری‌شده: محتوای دست‌های دیگران جابه‌جا (تعداد هر نفر ثابت، محدودیت خال‌ها حفظ)
        const others=[0,1,2,3].filter(o=>o!==turn);const pool=shuffle(others.flatMap(o=>H[o]));let q=0;
        const H2=H.map((h,i)=>i===turn?h:pool.slice(q,q+=h.length));
        ctx.__set(st);const a=pick(()=>ctx.__move(turn),n+1);
        ctx.__set({...st,H:H2});const b=pick(()=>ctx.__move(turn),n+1);
        ctx.__set(st);const c=pick(()=>ctx.__move(turn),n+777);
        if(a&&b&&a.s===b.s&&a.r===b.r)same++;n++;if(a&&c&&(a.s!==c.s||a.r!==c.r))diffSeed++;
        break;
      }
      if(k>=52)break;
      const c=L[rnd(L.length)];const bb=trick.length?bestOf(trick):null;
      plays.push({seat:turn,c,len:trick.length,led,bs:bb?bb.seat:-1,bc:bb?bb.c:null});
      if(trick.length&&c.s!==trick[0].c.s)voids[turn].push(trick[0].c.s);
      seen.push(c.s*20+c.r);H[turn]=H[turn].filter(x=>x!==c);trick.push({seat:turn,c});k++;
      if(trick.length<4){turn=(turn+1)%4;continue}
      const w=bestOf(trick).seat;tk[w%2]++;trick=[];turn=w;
      if(tk[0]>=7||tk[1]>=7)break;
    }
  }
  console.log(`حکم ۴ نفره: ${same}/${P} تصمیم با دست‌های پنهان جابه‌جاشده کاملاً یکسان ماند`+(same===P?' ✔ بدون نشت':' ✘ نشت اطلاعات!')+` | حساسیت آزمون: با بذر دیگر ${diffSeed} مورد فرق کرد`);
  if(same!==P)process.exitCode=1;
}
// ---------- ۲ نفره ----------
{
  const {load}=require('./lib/ctx2'),ctx=load(html);vm.runInContext('BOT2_MS=1e9;',ctx);
  let same=0,n=0,diffSeed=0;
  while(n<P){
    const d=[];for(let s=0;s<4;s++)for(let r=2;r<=14;r++)if(r!==2||(s<2===false))d.push({s,r});shuffle(d);
    const H=[d.slice(0,13),d.slice(13,26)],tr=rnd(4),hk=rnd(2);
    let trick=[],tk=[0,0],kt=null,played=[],vo=[[],[]],turn=hk,k=0,done=false;
    const beats=(c,b)=>c.s===b.s?c.r>b.r:c.s===tr,target=rnd(16)+2;
    while(!done){
      const hand=H[turn],led=trick.length?trick[0].c.s:-1;let L=hand;if(led>=0){const f=hand.filter(c=>c.s===led);if(f.length)L=f}
      if(turn===1&&k>=target&&L.length>1&&hand.length<=11){
        const st={hands:[H[0],H[1]],tk:[tk[0],tk[1]],kt,hk:hk===1?1:0,trump:tr,trick:trick.map(t=>({p:t.p,c:t.c})),played,gone:[],vo:[vo[0],vo[1]]};
        const fake=shuffle(d.filter(c=>!H[1].includes(c)&&!played.includes(c.s*20+c.r)&&!trick.some(t=>t.c===c))).slice(0,H[0].length);
        ctx.__set(st);const a=pick(()=>ctx.__move(),n+1);
        ctx.__set({...st,hands:[fake,H[1]]});const b=pick(()=>ctx.__move(),n+1);
        ctx.__set(st);const c=pick(()=>ctx.__move(),n+777);
        if(a&&b&&a.s===b.s&&a.r===b.r)same++;n++;if(a&&c&&(a.s!==c.s||a.r!==c.r))diffSeed++;break;
      }
      if(k>=40)break;
      const c=L[rnd(L.length)];if(trick.length&&c.s!==trick[0].c.s)vo[turn].push(trick[0].c.s);
      played.push(c.s*20+c.r);H[turn]=H[turn].filter(x=>x!==c);trick.push({p:turn,c});k++;
      if(trick.length<2){turn=1-turn;continue}
      const w=beats(trick[1].c,trick[0].c)?trick[1].p:trick[0].p;tk[w]++;trick=[];turn=w;if(tk[0]>=7||tk[1]>=7)break;
    }
  }
  console.log(`حکم ۲ نفره: ${same}/${P} تصمیم با دست پنهان حریف جابه‌جاشده کاملاً یکسان ماند`+(same===P?' ✔ بدون نشت':' ✘ نشت اطلاعات!')+` | حساسیت آزمون: با بذر دیگر ${diffSeed} مورد فرق کرد`);
  if(same!==P)process.exitCode=1;
}
