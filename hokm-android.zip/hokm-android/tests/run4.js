// استفاده: node tests/run4.js --a <index.html جدید> --b <index.html قدیم | random | heur> --deals 100 [--ms 150]
const path=require('path'),vm=require('vm');
const {load,rival}=require('./lib/ctx4'),{playRound,newDeck,newStats,rnd}=require('./lib/arena4');
const arg=(k,d)=>{const i=process.argv.indexOf('--'+k);return i>0?process.argv[i+1]:d};
const root=path.join(__dirname,'..');
const A=arg('a',path.join(root,'app/src/main/assets/index.html')),Bs=arg('b',path.join(__dirname,'baseline/index_before.html'));
const N=+arg('deals',50),MS=arg('ms',null);
const ca=load(A);if(MS){vm.runInContext('BOT_MS='+MS+';TRUMP_MS='+MS,ca)}
let cb;if(Bs==='random'||Bs==='heur')cb=rival(ca,Bs);else{cb=load(Bs);const ms2=arg('msb',null);if(ms2)try{vm.runInContext('BOT_MS='+ms2,cb)}catch(e){}}
ca.side=0;cb.side=1;
const st=newStats();let win=0,tot=0,pts=0;const t0=Date.now();
for(let d=0;d<N;d++){
  const deck=newDeck(),hk=rnd(4);
  for(const par of [0,1]){
    const bots=[0,1,2,3].map(s=>s%2===par?ca:cb);
    const r=playRound(bots,hk,st,deck);const aw=r.t===par;win+=aw;tot++;pts+=aw?r.pts:-r.pts;
  }
  if((d+1)%10===0)console.error('..',d+1,'/',N,((Date.now()-t0)/1000|0)+'s');
}
const q=(a,p)=>{if(!a.length)return 0;const s=a.slice().sort((x,y)=>x-y);return s[Math.min(s.length-1,Math.floor(p*s.length))]};
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const p=win/tot,ci=196*Math.sqrt(p*(1-p)/tot);
const per=(P,k)=>st.dec[P]?(1000*st.err[P][k]/st.dec[P]).toFixed(1):'-';
console.log(JSON.stringify({A:path.basename(A),B:Bs,rounds:tot,A_roundWinPct:+(100*p).toFixed(1),ci95:+ci.toFixed(1),A_avgPointsPerRound:+(pts/tot).toFixed(3),
 timeMs:{A:{mean:+avg(st.ms[0]).toFixed(0),p95:+q(st.ms[0],.95).toFixed(0),max:+q(st.ms[0],1).toFixed(0)},B:{mean:+avg(st.ms[1]).toFixed(0),p95:+q(st.ms[1],.95).toFixed(0),max:+q(st.ms[1],1).toFixed(0)}},
 illegalMoves:st.illegal,exceptions:st.exc,
 strategicErrorsPer1000Decisions:{A:{wasteOvertake:per(0,'wasteOvertake'),missedWin:per(0,'missedWin'),trumpPartner:per(0,'trumpPartner')},B:{wasteOvertake:per(1,'wasteOvertake'),missedWin:per(1,'missedWin'),trumpPartner:per(1,'trumpPartner')}}},null,1));
