package com.example.hokm

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText
import org.json.JSONArray
import org.json.JSONObject

/**
 * The table of a two-player multi-phone game as seen by one player. It only draws what the host sends
 * ("state" messages with n = 2, see [MpHostEngine2]) and sends the player's choices back with [send].
 */
class Mp2Screen(
    private val a: Activity,
    private val snd: Sound,
    private val send: (JSONObject) -> Unit,
    private val onOptions: () -> Unit,
    private val onMenu: () -> Unit,
    private val onNewGame: () -> Unit,
    private val isHost: () -> Boolean
) {
    val col = LinearLayout(a)
    val log = GameLog(a)
    var last: JSONObject? = null
        private set

    private val scoreView = TextView(a)
    val msgView = TextView(a)
    private val rows = Array(2) { TextView(a) }
    private val drawBox = LinearLayout(a)
    private val takeUp = Button(a)
    private val takeDown = Button(a)
    private val pickRow = LinearLayout(a)
    private val discardBtn = Button(a)
    private val handGrid = GridLayout(a)
    private val restartBtn = Button(a)
    private val selected = LinkedHashSet<Int>()
    private var busy = false

    private fun dp(v: Int): Int = (v * a.resources.displayMetrics.density).toInt()

    private fun wrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun style(t: TextView, size: Float, bold: Boolean) {
        t.textSize = size
        t.setTextColor(Color.WHITE)
        if (bold) t.setTypeface(null, Typeface.BOLD)
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(12))
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL

        style(scoreView, 16f, true)
        col.addView(scoreView, wrap())

        style(msgView, 18f, false)
        msgView.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        msgView.setBackgroundColor(0x33000000)
        msgView.setPadding(dp(8), dp(8), dp(8), dp(8))
        col.addView(msgView, wrap().also { it.topMargin = dp(8) })

        val table = LinearLayout(a)
        table.orientation = LinearLayout.VERTICAL
        table.setPadding(dp(8), dp(8), dp(8), dp(8))
        table.setBackgroundColor(0x22FFFFFF)
        for (r in rows) {
            style(r, 17f, false)
            table.addView(r, wrap())
        }
        col.addView(table, wrap().also { it.topMargin = dp(8) })

        drawBox.orientation = LinearLayout.HORIZONTAL
        drawBox.visibility = View.GONE
        takeUp.isAllCaps = false
        takeDown.isAllCaps = false
        takeUp.setOnClickListener { take(true) }
        takeDown.setOnClickListener { take(false) }
        drawBox.addView(takeUp, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        drawBox.addView(takeDown, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(drawBox, wrap().also { it.topMargin = dp(8) })

        pickRow.orientation = LinearLayout.HORIZONTAL
        pickRow.visibility = View.GONE
        for (t in 0 until 4) {
            val b = Button(a)
            b.isAllCaps = false
            b.text = CardText.SUIT_NAMES[t] + " " + CardText.SUIT_SYMBOLS[t]
            b.contentDescription = "حکم " + CardText.SUIT_NAMES[t]
            b.setTextColor(if (t == 1 || t == 2) Color.RED else Color.BLACK)
            b.setOnClickListener {
                if (!busy) {
                    busy = true
                    send(JSONObject().put("t", "trump").put("s", t))
                }
            }
            pickRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(pickRow, wrap().also { it.topMargin = dp(8) })

        discardBtn.isAllCaps = false
        discardBtn.visibility = View.GONE
        discardBtn.setOnClickListener { confirmDiscard() }
        col.addView(discardBtn, wrap().also { it.topMargin = dp(8) })

        handGrid.columnCount = 5
        col.addView(handGrid, wrap().also { it.topMargin = dp(8) })

        val tools = LinearLayout(a)
        tools.orientation = LinearLayout.HORIZONTAL
        fun tool(text: String, f: () -> Unit) {
            val b = Button(a)
            b.text = text
            b.isAllCaps = false
            b.setOnClickListener { f() }
            tools.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        tool("دست قبل") { readLastTrick() }
        tool("وضعیت") { readStatus() }
        tool("گزینه‌ها") { onOptions() }
        tool("منو") { onMenu() }
        col.addView(tools, wrap().also { it.topMargin = dp(12) })
        run {
            val b = Button(a)
            b.text = "کارت‌های بازی‌شده در این دست"
            b.isAllCaps = false
            b.setOnClickListener { readTable() }
            col.addView(b, wrap().also { it.topMargin = dp(4) })
        }

        restartBtn.text = "بازی جدید"
        restartBtn.isAllCaps = false
        restartBtn.visibility = View.GONE
        restartBtn.setOnClickListener { onNewGame() }
        col.addView(restartBtn, wrap().also { it.topMargin = dp(8) })

        col.addView(log.view, wrap().also { it.topMargin = dp(16) })
    }

    // ------------------------------------------------------------------ helpers

    private fun ids(arr: JSONArray?): List<Int> {
        val l = ArrayList<Int>()
        if (arr != null) for (i in 0 until arr.length()) l.add(arr.optInt(i))
        return l
    }

    private fun pairs(arr: JSONArray?): List<IntArray> {
        val l = ArrayList<IntArray>()
        if (arr != null) for (i in 0 until arr.length()) {
            val p = arr.optJSONArray(i) ?: continue
            l.add(intArrayOf(p.optInt(0), p.optInt(1)))
        }
        return l
    }

    private fun card(id: Int) = Card(id / 20, id % 20)

    private fun nameOf(o: JSONObject, p: Int): String {
        val me = o.optInt("seat")
        if (p == me) return "شما"
        val n = o.optJSONArray("names")?.optString(p) ?: ""
        return if (n.isEmpty()) "حریف" else n
    }

    fun say(t: String) {
        msgView.text = t
        log.add(t)
    }

    private fun take(face: Boolean) {
        if (busy) return
        busy = true
        takeUp.isEnabled = false
        takeDown.isEnabled = false
        send(JSONObject().put("t", "take").put("face", face))
    }

    private fun confirmDiscard() {
        if (busy) return
        if (selected.size != 2) {
            say("باید دقیقاً دو کارت انتخاب کنید.")
            return
        }
        busy = true
        val arr = JSONArray()
        for (id in selected) arr.put(id)
        selected.clear()
        send(JSONObject().put("t", "discard").put("ids", arr))
    }

    // ------------------------------------------------------------------ drawing

    fun update(o: JSONObject) {
        last = o
        busy = false
        val me = o.optInt("seat")
        val need = o.optInt("need")
        if (need == 0) selected.clear()
        val sc = ids(o.optJSONArray("sc"))
        val tk = ids(o.optJSONArray("tk"))
        val trump = o.optInt("trump", -1)
        val trumpText = if (trump in 0..3) CardText.SUIT_NAMES[trump] + " " + CardText.SUIT_SYMBOLS[trump] else "—"
        if (sc.size == 2 && tk.size == 2) {
            scoreView.text = "امتیاز: شما " + CardText.fa(sc[me]) + "، حریف " + CardText.fa(sc[1 - me]) +
                " | دست‌ها: شما " + CardText.fa(tk[me]) + "، حریف " + CardText.fa(tk[1 - me]) +
                " | حکم: " + trumpText + " | حاکم: " + nameOf(o, o.optInt("hk"))
        }
        val tb = pairs(o.optJSONArray("table"))
        val tw = o.optInt("tableWin", -1)
        for (rel in 0 until 2) {
            val p = if (rel == 0) me else 1 - me
            val e = tb.firstOrNull { it[0] == p }
            var t = nameOf(o, p) + ": " + (if (e != null) CardText.cardName(card(e[1])) else "—")
            if (e != null && p == tw) t += " (برنده)"
            rows[rel].text = t
            CardArt.mark(rows[rel], if (e != null) card(e[1]) else null)
        }

        val st = o.optString("st")
        // taking a card
        val up = o.optInt("up", -1)
        val canTake = o.optBoolean("canTake")
        drawBox.visibility = if (st == "DRAW" && up >= 0) View.VISIBLE else View.GONE
        if (st == "DRAW" && up >= 0) {
            val c = card(up)
            takeUp.text = "کارت رو: " + CardText.cardName(c)
            takeUp.contentDescription = "برداشتن کارت رو، " + CardText.cardName(c)
            takeDown.text = "کارت پشت"
            takeDown.contentDescription = "برداشتن کارت پشت که دیده نمی‌شود"
            CardArt.mark(takeUp, c)
            CardArt.markBack(takeDown)
            takeUp.isEnabled = canTake
            takeDown.isEnabled = canTake
        }
        pickRow.visibility = if (o.optBoolean("canPick")) View.VISIBLE else View.GONE

        // the hand
        val legal = ids(o.optJSONArray("legal"))
        val cw = CardArt.cardWidth(a, 5)
        handGrid.removeAllViews()
        for (id in ids(o.optJSONArray("hand"))) {
            val c = card(id)
            val enabled = if (need > 0) true else legal.contains(id)
            handGrid.addView(CardArt.cardButton(a, c, cw, enabled, need > 0 && selected.contains(id)) {
                if (need > 0) {
                    if (selected.contains(id)) selected.remove(id) else if (selected.size < 2) selected.add(id)
                    last?.let { update2(it) }
                } else if (!busy) {
                    busy = true
                    for (i in 0 until handGrid.childCount) handGrid.getChildAt(i).isEnabled = false
                    send(JSONObject().put("t", "play").put("id", id))
                }
            })
        }
        discardBtn.visibility = if (need > 0) View.VISIBLE else View.GONE
        discardBtn.text = "کنار گذاشتن دو کارت (" + CardText.fa(selected.size) + " از ۲ انتخاب شده)"

        val over = o.optBoolean("over")
        restartBtn.visibility = if (over && isHost()) View.VISIBLE else View.GONE
        val say = o.optString("say")
        if (say.isNotEmpty()) say(if (over && !isHost()) "$say منتظر میزبان برای بازی جدید باشید." else say)
        val sfx = o.optJSONArray("sfx")
        if (sfx != null) for (i in 0 until sfx.length()) {
            val n = sfx.optString(i)
            if (n == "card") snd.card() else snd.sfx(n)
        }
        if (legal.isNotEmpty() || need > 0) focusFirst()
        SettingsUi.applyA11y(a, msgView)
    }

    /** Redraws after a local change (selection) without announcing the old sentence again. */
    private fun update2(o: JSONObject) {
        val saved = o.optString("say")
        o.put("say", "")
        o.put("sfx", JSONArray())
        update(o)
        o.put("say", saved)
    }

    private fun focusFirst() {
        for (i in 0 until handGrid.childCount) {
            val v = handGrid.getChildAt(i)
            if (v.isEnabled) {
                v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                return
            }
        }
    }

    // ------------------------------------------------------------------ reading aids

    private fun readTable() {
        val o = last ?: return
        var tb = pairs(o.optJSONArray("table"))
        if (tb.isEmpty()) tb = pairs(o.optJSONArray("last"))
        say(
            if (tb.isNotEmpty()) "روی زمین: " + tb.joinToString("، ") { nameOf(o, it[0]) + " " + CardText.cardName(card(it[1])) } + "."
            else "روی زمین کارتی نیست."
        )
    }

    private fun readLastTrick() {
        val o = last ?: return
        val l = pairs(o.optJSONArray("last"))
        if (l.isEmpty()) {
            say("هنوز دستی بازی نشده.")
            return
        }
        say("دست قبل: " + l.joinToString("، ") { nameOf(o, it[0]) + " " + CardText.cardName(card(it[1])) } +
            ". برنده: " + nameOf(o, o.optInt("lastWin")) + ".")
    }

    private fun readStatus() {
        val o = last ?: return
        val me = o.optInt("seat")
        val sc = ids(o.optJSONArray("sc"))
        val tk = ids(o.optJSONArray("tk"))
        val sb = StringBuilder()
        val trump = o.optInt("trump", -1)
        if (trump in 0..3) sb.append("حکم: ").append(CardText.SUIT_NAMES[trump]).append(". ")
        sb.append("حاکم: ").append(nameOf(o, o.optInt("hk"))).append(". ")
        if (sc.size == 2 && tk.size == 2) {
            sb.append("امتیاز: شما ").append(CardText.fa(sc[me])).append("، حریف ").append(CardText.fa(sc[1 - me])).append(". ")
            sb.append("دست‌ها: شما ").append(CardText.fa(tk[me])).append("، حریف ").append(CardText.fa(tk[1 - me])).append(". ")
        }
        val tb = pairs(o.optJSONArray("table"))
        if (tb.isNotEmpty()) {
            sb.append("روی میز: ").append(tb.joinToString("، ") { nameOf(o, it[0]) + " " + CardText.cardName(card(it[1])) }).append(". ")
        }
        val hand = ids(o.optJSONArray("hand"))
        if (hand.isNotEmpty()) sb.append("کارت‌های شما: ").append(hand.joinToString("، ") { CardText.cardName(card(it)) }).append(".")
        say(sb.toString())
    }
}
