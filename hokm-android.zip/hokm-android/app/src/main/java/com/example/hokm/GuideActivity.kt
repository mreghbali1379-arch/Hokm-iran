package com.example.hokm

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** The rules and how-to guide (assets/guide2.txt: "#" headings, "##" sub-headings, "•" bullets, plain text). */
class GuideActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL

        fun add(text: String, size: Float, bold: Boolean, top: Int, heading: Boolean) {
            val t = TextView(this)
            t.text = text
            t.textSize = size
            t.setTextColor(Color.WHITE)
            if (bold) t.setTypeface(null, Typeface.BOLD)
            t.setLineSpacing(0f, 1.15f)
            if (heading && Build.VERSION.SDK_INT >= 28) t.isAccessibilityHeading = true
            col.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = dp(top) })
        }

        add("راهنمای بازی", 26f, true, 0, true)
        val text = try {
            assets.open("guide2.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            "راهنما در دسترس نیست."
        }
        for (line in text.split('\n')) {
            val l = line.trim()
            if (l.isEmpty()) continue
            when {
                l.startsWith("## ") -> add(l.substring(3), 18f, true, 14, true)
                l.startsWith("# ") -> add(l.substring(2), 22f, true, 24, true)
                else -> add(l, 16f, false, 6, false)
            }
        }
        val sv = ScrollView(this)
        sv.background = CardArt.background(this)
        sv.addView(col)
        setContentView(sv)
    }
}
