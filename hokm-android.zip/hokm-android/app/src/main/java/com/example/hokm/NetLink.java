package com.example.hokm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.MacAddress;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.os.Build;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plays the game over Wi-Fi instead of Nearby Connections.
 *  - direct == false: every phone is on the same Wi-Fi network (router or a phone's hotspot).
 *    The host opens a TCP port and announces itself with mDNS (NsdManager).
 *  - direct == true : Wi-Fi Direct. The host creates a Wi-Fi Direct group, the others join it,
 *    then everything runs over the same TCP link.
 * It speaks the same small interface as the Nearby code in MainActivity (conn / open / msg / drop /
 * found / lost / err events), so the game logic in index.html does not change.
 */
final class NetLink {
    interface Out { void ev(String type, int cid, String data); }

    static final int PORT = 47531;
    private static final String SVC = "_hokm._tcp";

    private final Context ctx;
    private final Out out;
    private final boolean direct;
    private final Object lock = new Object();
    private final Map<Integer, Peer> peers = new HashMap<>();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();

    private volatile boolean closed = false;
    private volatile boolean hosting = false;
    private volatile boolean scanning = false;
    private volatile boolean scanActive = false;
    private volatile int max = 4;
    private volatile String room = "";
    private volatile String hostName = "";
    private volatile String myName = "";
    private volatile String wantRoom = null;
    private int nextId = 1;
    private ServerSocket server;

    NetLink(Context ctx, boolean direct, Out out) {
        this.ctx = ctx;
        this.direct = direct;
        this.out = out;
        startHeartbeat();
    }

    // ---------------------------------------------------------------- peers

    private final class Peer {
        final int id;
        final Socket sock;
        final OutputStream os;
        volatile boolean open = true;

        Peer(int id, Socket s) throws Exception {
            this.id = id;
            this.sock = s;
            this.os = s.getOutputStream();
        }

        void close() {
            open = false;
            try { sock.close(); } catch (Exception e) { }
        }
    }

    private void dropPeer(int id, Peer expected, boolean notify) {
        Peer p;
        synchronized (lock) {
            p = peers.get(id);
            if (p == null || (expected != null && p != expected)) return;
            peers.remove(id);
        }
        p.close();
        if (notify) out.ev("drop", id, "");
    }

    private void readLoop(Peer p, BufferedReader r) {
        try {
            String line;
            while (p.open && (line = r.readLine()) != null) {
                if (!line.isEmpty()) out.ev("msg", p.id, line);
            }
        } catch (Exception e) {
            // timeout or broken link
        }
        dropPeer(p.id, p, true);
    }

    void send(final int id, final String msg) {
        if (msg == null || closed) return;
        writer.submit(() -> {
            Peer p;
            synchronized (lock) { p = peers.get(id); }
            if (p == null) return;
            try {
                p.os.write((msg + "\n").getBytes(StandardCharsets.UTF_8));
                p.os.flush();
            } catch (Exception e) {
                dropPeer(id, p, true);
            }
        });
    }

    void drop(final int id) {
        writer.submit(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ie) { }
            dropPeer(id, null, false);
        });
    }

    // empty line every 3 s: a dead link is noticed within ~12 s
    private void startHeartbeat() {
        Thread hb = new Thread(() -> {
            while (!closed) {
                try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
                Integer[] ids;
                synchronized (lock) { ids = peers.keySet().toArray(new Integer[0]); }
                for (int k : ids) send(k, "");
            }
        });
        hb.setDaemon(true);
        hb.start();
    }

    // ---------------------------------------------------------------- host

    void startHost(int maxClients, String roomId, String name) {
        stopHost();
        max = maxClients;
        room = roomId == null ? "" : roomId;
        hostName = name == null ? "" : name;
        hosting = true;
        try {
            ServerSocket srv = new ServerSocket();
            srv.setReuseAddress(true);
            srv.bind(new InetSocketAddress(PORT));
            server = srv;
            new Thread(() -> acceptLoop(srv)).start();
        } catch (Exception e) {
            hosting = false;
            out.ev("err", 0, "باز کردن میزبان ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
            return;
        }
        if (direct) p2pHost(); else nsdRegister();
    }

    void stopHost() {
        hosting = false;
        ServerSocket s = server;
        server = null;
        if (s != null) { try { s.close(); } catch (Exception e) { } }
        if (direct) p2pStopHost(); else nsdUnregister();
    }

    private void acceptLoop(ServerSocket srv) {
        while (!closed && hosting) {
            try {
                final Socket s = srv.accept();
                new Thread(() -> incoming(s)).start();
            } catch (Exception e) {
                break;
            }
        }
    }

    private void incoming(Socket s) {
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(5000);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            String first = r.readLine();
            if (first == null || !first.startsWith("HK1\t")) { s.close(); return; }
            String name = first.substring(4).trim();
            OutputStream os = s.getOutputStream();
            int n;
            synchronized (lock) { n = peers.size(); }
            if (!hosting || n >= max) {
                os.write("FULL\n".getBytes(StandardCharsets.UTF_8));
                os.flush();
                s.close();
                return;
            }
            os.write("OK\n".getBytes(StandardCharsets.UTF_8));
            os.flush();
            s.setSoTimeout(12000);
            Peer p;
            int id;
            synchronized (lock) {
                id = nextId++;
                p = new Peer(id, s);
                peers.put(id, p);
            }
            InetAddress ia = s.getInetAddress();
            out.ev("conn", id, (name.isEmpty() ? "بازیکن" : name) + "\u0001tcp:" + (ia == null ? "" : ia.getHostAddress()));
            readLoop(p, r);
        } catch (Exception e) {
            try { s.close(); } catch (Exception x) { }
        }
    }

    // ---------------------------------------------------------------- client

    void startScan() {
        scanning = true;
        startDiscovery();
    }

    void stopScan() {
        scanning = false;
        if (wantRoom == null) stopDiscovery();
    }

    /** target = "tcp:ip:port" (same network), "p2p:mac|room" (Wi-Fi Direct) or "room:id". */
    void connect(final String target, String name) {
        myName = (name == null || name.isEmpty()) ? "بازیکن" : name;
        dropPeer(0, null, false);
        if (target == null) return;
        if (target.startsWith("tcp:")) {
            String body = target.substring(4);
            int k = body.lastIndexOf(':');
            if (k < 0) return;
            connectTcp(body.substring(0, k), parsePort(body.substring(k + 1)));
        } else if (target.startsWith("p2p:")) {
            String body = target.substring(4);
            int k = body.indexOf('|');
            if (k < 0) return;
            p2pConnect(body.substring(0, k), body.substring(k + 1));
        } else if (target.startsWith("room:")) {
            final String r = target.substring(5);
            wantRoom = r;
            startDiscovery();
            final long wait = direct ? 25000 : 12000;
            new Thread(() -> {
                try { Thread.sleep(wait); } catch (InterruptedException ie) { return; }
                if (r.equals(wantRoom)) {
                    wantRoom = null;
                    if (!scanning) stopDiscovery();
                    out.ev("err", 0, "بازی پیدا نشد. میزبان نزدیک نیست، بازی را بسته است یا وای‌فای هر دو گوشی روشن نیست.");
                }
            }).start();
        }
    }

    private static int parsePort(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return PORT; }
    }

    private void connectTcp(final String ip, final int port) {
        new Thread(() -> {
            Socket s = null;
            try {
                s = new Socket();
                s.connect(new InetSocketAddress(ip, port), 7000);
                s.setTcpNoDelay(true);
                s.setSoTimeout(7000);
                OutputStream os = s.getOutputStream();
                os.write(("HK1\t" + myName + "\n").getBytes(StandardCharsets.UTF_8));
                os.flush();
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String ans = r.readLine();
                if (!"OK".equals(ans)) {
                    s.close();
                    out.ev("err", 0, "FULL".equals(ans) ? "این میز پر است." : "اتصال برقرار نشد.");
                    return;
                }
                s.setSoTimeout(12000);
                Peer p = new Peer(0, s);
                Peer old;
                synchronized (lock) { old = peers.put(0, p); }
                if (old != null) old.close();
                scanning = false;
                wantRoom = null;
                stopDiscovery();
                out.ev("open", 0, "");
                readLoop(p, r);
            } catch (Exception e) {
                try { if (s != null) s.close(); } catch (Exception x) { }
                out.ev("err", 0, "اتصال برقرار نشد. مطمئن شوید میزبان بازی را باز کرده و وای‌فای هر دو گوشی روشن است. (جزئیات فنی: " + e.getMessage() + ")");
            }
        }).start();
    }

    void closeAll() {
        hosting = false;
        scanning = false;
        wantRoom = null;
        stopHost();
        stopDiscovery();
        Peer[] all;
        synchronized (lock) {
            all = peers.values().toArray(new Peer[0]);
            peers.clear();
        }
        for (Peer p : all) p.close();
        if (direct) p2pReset();
    }

    void shutdown() {
        closed = true;
        closeAll();
        p2pRelease();
        writer.shutdown();
    }

    private void startDiscovery() {
        if (direct) p2pScan(); else nsdScan();
    }

    private void stopDiscovery() {
        if (direct) p2pStopScan(); else nsdStopScan();
    }

    // ---------------------------------------------------------------- same Wi-Fi network (mDNS)

    private NsdManager nsd;
    private NsdManager.RegistrationListener regL;
    private NsdManager.DiscoveryListener discL;
    private final ArrayDeque<NsdServiceInfo> resolveQ = new ArrayDeque<>();
    private boolean resolving = false;
    private final Map<String, String> nsdTargets = new HashMap<>();

    private NsdManager nsdm() {
        if (nsd == null) nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
        return nsd;
    }

    private void nsdRegister() {
        try {
            NsdServiceInfo si = new NsdServiceInfo();
            si.setServiceName("HK-" + room);
            si.setServiceType(SVC);
            si.setPort(PORT);
            si.setAttribute("room", room);
            si.setAttribute("host", hostName);
            regL = new NsdManager.RegistrationListener() {
                @Override public void onRegistrationFailed(NsdServiceInfo i, int e) {
                    out.ev("err", 0, "اعلام میز در شبکهٔ وای‌فای ناموفق بود. (کد " + e + ")");
                }
                @Override public void onUnregistrationFailed(NsdServiceInfo i, int e) { }
                @Override public void onServiceRegistered(NsdServiceInfo i) { }
                @Override public void onServiceUnregistered(NsdServiceInfo i) { }
            };
            nsdm().registerService(si, NsdManager.PROTOCOL_DNS_SD, regL);
        } catch (Exception e) {
            out.ev("err", 0, "اعلام میز در شبکهٔ وای‌فای ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
        }
    }

    private void nsdUnregister() {
        NsdManager.RegistrationListener l = regL;
        regL = null;
        if (l != null) {
            try { nsdm().unregisterService(l); } catch (Exception e) { }
        }
    }

    private void nsdScan() {
        if (discL != null) return;
        try {
            discL = new NsdManager.DiscoveryListener() {
                @Override public void onStartDiscoveryFailed(String t, int e) {
                    discL = null;
                    out.ev("err", 0, "جست‌وجو در شبکهٔ وای‌فای ممکن نشد. (کد " + e + ")");
                }
                @Override public void onStopDiscoveryFailed(String t, int e) { }
                @Override public void onDiscoveryStarted(String t) { }
                @Override public void onDiscoveryStopped(String t) { }
                @Override public void onServiceFound(NsdServiceInfo i) { queueResolve(i); }
                @Override public void onServiceLost(NsdServiceInfo i) {
                    String tg;
                    synchronized (lock) { tg = nsdTargets.remove(i.getServiceName()); }
                    if (tg != null && scanning) out.ev("lost", 0, tg);
                }
            };
            nsdm().discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, discL);
        } catch (Exception e) {
            discL = null;
            out.ev("err", 0, "جست‌وجو در شبکهٔ وای‌فای ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
        }
    }

    private void nsdStopScan() {
        NsdManager.DiscoveryListener l = discL;
        discL = null;
        if (l != null) {
            try { nsdm().stopServiceDiscovery(l); } catch (Exception e) { }
        }
        synchronized (resolveQ) { resolveQ.clear(); }
    }

    private void queueResolve(NsdServiceInfo i) {
        synchronized (resolveQ) { resolveQ.add(i); }
        pumpResolve();
    }

    private void resolveDone() {
        synchronized (resolveQ) { resolving = false; }
        pumpResolve();
    }

    // older Android versions resolve only one service at a time, so queue them
    private void pumpResolve() {
        final NsdServiceInfo next;
        synchronized (resolveQ) {
            if (resolving || resolveQ.isEmpty()) return;
            next = resolveQ.poll();
            resolving = true;
        }
        try {
            nsdm().resolveService(next, new NsdManager.ResolveListener() {
                @Override public void onResolveFailed(NsdServiceInfo i, int e) { resolveDone(); }
                @Override public void onServiceResolved(NsdServiceInfo i) {
                    try { nsdResolved(i); } catch (Exception e) { }
                    resolveDone();
                }
            });
        } catch (Exception e) {
            resolveDone();
        }
    }

    private static String attr(Map<String, byte[]> a, String k) {
        if (a == null) return "";
        byte[] v = a.get(k);
        return v == null ? "" : new String(v, StandardCharsets.UTF_8);
    }

    private void nsdResolved(NsdServiceInfo i) {
        InetAddress h = i.getHost();
        if (h == null) return;
        String ip = h.getHostAddress();
        int port = i.getPort();
        String r = attr(i.getAttributes(), "room");
        String hn = attr(i.getAttributes(), "host");
        if (r.isEmpty()) return;
        String target = "tcp:" + ip + ":" + port;
        synchronized (lock) { nsdTargets.put(i.getServiceName(), target); }
        if (scanning) out.ev("found", 0, target + "\u0001" + r + "\u0001" + hn);
        String w = wantRoom;
        if (w != null && w.equals(r)) {
            wantRoom = null;
            connectTcp(ip, port);
        }
    }

    // ---------------------------------------------------------------- Wi-Fi Direct

    private WifiP2pManager p2p;
    private WifiP2pManager.Channel ch;
    private BroadcastReceiver rx;
    private volatile boolean pendingClient = false;

    private static String groupName(String r) { return "DIRECT-HK-" + r; }

    private static String groupPass(String r) { return "hokm-" + r + "-play"; }

    private WifiP2pManager.ActionListener al(final Runnable ok, final Runnable bad) {
        return new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() { if (ok != null) ok.run(); }
            @Override public void onFailure(int reason) { if (bad != null) bad.run(); }
        };
    }

    private boolean p2pInit() {
        if (p2p != null && ch != null) return true;
        try {
            p2p = (WifiP2pManager) ctx.getSystemService(Context.WIFI_P2P_SERVICE);
            if (p2p == null) return false;
            ch = p2p.initialize(ctx, Looper.getMainLooper(), null);
            rx = new BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent in) { p2pChanged(); }
            };
            ctx.registerReceiver(rx, new IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION));
            return ch != null;
        } catch (Exception e) {
            return false;
        }
    }

    private void p2pRelease() {
        BroadcastReceiver r = rx;
        rx = null;
        if (r != null) {
            try { ctx.unregisterReceiver(r); } catch (Exception e) { }
        }
    }

    private void p2pChanged() {
        if (p2p == null || ch == null || !pendingClient) return;
        try {
            p2p.requestConnectionInfo(ch, info -> {
                if (info != null && info.groupFormed && !info.isGroupOwner
                        && pendingClient && info.groupOwnerAddress != null) {
                    pendingClient = false;
                    connectTcp(info.groupOwnerAddress.getHostAddress(), PORT);
                }
            });
        } catch (Exception e) { }
    }

    private void p2pFail(String m) {
        out.ev("err", 0, m);
    }

    private void p2pHost() {
        if (!p2pInit()) {
            p2pFail("وای‌فای مستقیم روی این گوشی در دسترس نیست.");
            return;
        }
        final String r = room;
        try {
            // announce the table so other phones can find it
            Map<String, String> txt = new HashMap<>();
            txt.put("room", r);
            txt.put("host", hostName);
            final WifiP2pDnsSdServiceInfo si = WifiP2pDnsSdServiceInfo.newInstance("hk" + r, SVC, txt);
            p2p.clearLocalServices(ch, al(() -> addLocal(si), () -> addLocal(si)));
            // then make our own group with a name/password derived from the room id
            p2p.removeGroup(ch, al(this::createGroupNow, this::createGroupNow));
        } catch (Exception e) {
            p2pFail("باز کردن وای‌فای مستقیم ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
        }
    }

    private void addLocal(WifiP2pDnsSdServiceInfo si) {
        try { p2p.addLocalService(ch, si, al(null, null)); } catch (Exception e) { }
    }

    private void createGroupNow() {
        if (!hosting) return;
        final Runnable bad = () -> p2pFail("ساختن گروه وای‌فای مستقیم ممکن نشد. وای‌فای و موقعیت مکانی را روشن کنید و اجازه‌ها را بدهید.");
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                WifiP2pConfig cfg = new WifiP2pConfig.Builder()
                    .setNetworkName(groupName(room))
                    .setPassphrase(groupPass(room))
                    .build();
                p2p.createGroup(ch, cfg, al(null, bad));
            } else {
                p2p.createGroup(ch, al(null, bad));
            }
        } catch (Exception e) {
            bad.run();
        }
    }

    private void p2pStopHost() {
        if (p2p == null || ch == null) return;
        try { p2p.clearLocalServices(ch, al(null, null)); } catch (Exception e) { }
        try { p2p.removeGroup(ch, al(null, null)); } catch (Exception e) { }
    }

    private void p2pReset() {
        if (p2p == null || ch == null) return;
        pendingClient = false;
        try { p2p.cancelConnect(ch, al(null, null)); } catch (Exception e) { }
        try { p2p.removeGroup(ch, al(null, null)); } catch (Exception e) { }
    }

    private void p2pScan() {
        if (scanActive) return;
        if (!p2pInit()) {
            p2pFail("وای‌فای مستقیم روی این گوشی در دسترس نیست.");
            return;
        }
        scanActive = true;
        try {
            p2p.setDnsSdResponseListeners(ch,
                (inst, type, dev) -> { },
                (dom, txt, dev) -> {
                    String r = txt == null ? null : txt.get("room");
                    if (r == null || dev == null) return;
                    String h = txt.get("host");
                    String tg = "p2p:" + dev.deviceAddress + "|" + r;
                    if (scanning) out.ev("found", 0, tg + "\u0001" + r + "\u0001" + (h == null ? dev.deviceName : h));
                    String w = wantRoom;
                    if (w != null && w.equals(r)) {
                        wantRoom = null;
                        p2pConnect(dev.deviceAddress, r);
                    }
                });
            p2p.clearServiceRequests(ch, al(this::addRequest, this::addRequest));
        } catch (Exception e) {
            scanActive = false;
            p2pFail("جست‌وجوی وای‌فای مستقیم ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
        }
        // service discovery has to be repeated now and then
        new Thread(() -> {
            while (scanActive && !closed) {
                try { Thread.sleep(10000); } catch (InterruptedException ie) { return; }
                if (scanActive) discoverNow();
            }
        }).start();
    }

    private void addRequest() {
        try {
            p2p.addServiceRequest(ch, WifiP2pDnsSdServiceRequest.newInstance(), al(this::discoverNow, this::discoverNow));
        } catch (Exception e) { }
    }

    private void discoverNow() {
        try {
            p2p.discoverPeers(ch, al(
                () -> { try { p2p.discoverServices(ch, al(null, null)); } catch (Exception e) { } },
                () -> { try { p2p.discoverServices(ch, al(null, null)); } catch (Exception e) { } }));
        } catch (Exception e) { }
    }

    private void p2pStopScan() {
        scanActive = false;
        if (p2p == null || ch == null) return;
        try { p2p.clearServiceRequests(ch, al(null, null)); } catch (Exception e) { }
        try { p2p.stopPeerDiscovery(ch, al(null, null)); } catch (Exception e) { }
    }

    private void p2pConnect(String address, String r) {
        if (!p2pInit()) {
            p2pFail("وای‌فای مستقیم روی این گوشی در دسترس نیست.");
            return;
        }
        pendingClient = true;
        try {
            WifiP2pConfig cfg;
            if (Build.VERSION.SDK_INT >= 29) {
                cfg = new WifiP2pConfig.Builder()
                    .setDeviceAddress(MacAddress.fromString(address))
                    .setNetworkName(groupName(r))
                    .setPassphrase(groupPass(r))
                    .build();
            } else {
                // older phones: the host has to accept the invitation on screen
                cfg = new WifiP2pConfig();
                cfg.deviceAddress = address;
                cfg.wps.setup = WpsInfo.PBC;
            }
            p2p.connect(ch, cfg, al(null, () -> {
                pendingClient = false;
                p2pFail("اتصال وای‌فای مستقیم برقرار نشد. میزبان نزدیک نیست یا آن را نپذیرفته است.");
            }));
        } catch (Exception e) {
            pendingClient = false;
            p2pFail("اتصال وای‌فای مستقیم ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
            return;
        }
        new Thread(() -> {
            try { Thread.sleep(25000); } catch (InterruptedException ie) { return; }
            if (pendingClient) {
                pendingClient = false;
                p2pFail("اتصال وای‌فای مستقیم زمان زیادی طول کشید. دوباره امتحان کنید.");
            }
        }).start();
    }
}
