package com.example.hokm

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Main menu: create a game, previous games, settings, guide, about, exit. */
class MenuActivity : Activity() {

    private lateinit var resumeBtn: Button
    private lateinit var backBtn: Button
    private lateinit var resumeDuoBtn: Button
    private var snd: Sound? = null
    private var root: View? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sound(): Sound {
        var s = snd
        if (s == null) {
            s = Sound(this)
            snd = s
        }
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(24), dp(24), dp(24), dp(24))
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val title = TextView(this)
        title.text = "بازی حکم"
        title.textSize = 34f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        title.setPadding(0, dp(12), 0, dp(24))
        if (android.os.Build.VERSION.SDK_INT >= 28) title.isAccessibilityHeading = true
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun item(label: String, action: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.textSize = 18f
            b.setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            col.addView(b, lp)
            return b
        }

        backBtn = item("بازگشت به بازی") {
            startActivity(Intent(this, MpActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        }
        resumeBtn = item("ادامه بازی چهارنفرهٔ قبلی") {
            startActivity(Intent(this, SoloGameActivity::class.java).putExtra("resume", true))
        }
        resumeDuoBtn = item("ادامه بازی دونفرهٔ قبلی") {
            startActivity(Intent(this, DuoGameActivity::class.java).putExtra("resume", true))
        }
        item("ایجاد بازی") {
            if (MpActivity.active) {
                SettingsUi.confirm(
                    this,
                    "یک بازی با چند گوشی در حال اجراست. اگر بازی جدید بسازید، آن بازی بسته می‌شود. ادامه می‌دهید؟"
                ) {
                    MpActivity.closeCurrent()
                    createGame()
                }
            } else {
                createGame()
            }
        }
        item("بازی‌های قبلی") { PreviousGames.show(this) }
        item("تنظیمات") { showSettings() }
        item("راهنما") { startActivity(Intent(this, GuideActivity::class.java)) }
        item("درباره") { SettingsUi.aboutDialog(this) }
        item("خروج") {
            SettingsUi.confirm(this, "مطمئنید؟ برنامه کاملاً بسته می‌شود.") {
                MpActivity.closeCurrent()
                finishAffinity()
            }
        }

        val sv = ScrollView(this)
        sv.addView(col)
        root = sv
        sv.background = CardArt.background(this)
        setContentView(sv)

        if (!Prefs.hasName(this)) SettingsUi.nameDialog(this, false) {}
    }

    private fun createGame() {
        SettingsUi.list(
            this, "نوع بازی را انتخاب کنید",
            listOf(
                "بازی با ربات" to {
                    SettingsUi.list(
                        this, "بازی با ربات",
                        listOf(
                            "دو نفره" to { startActivity(Intent(this, DuoGameActivity::class.java)) },
                            "چهار نفره" to { startActivity(Intent(this, SoloGameActivity::class.java)) }
                        )
                    )
                },
                "بازی با چند گوشی" to { startActivity(Intent(this, MpActivity::class.java)) }
            )
        )
    }

    private fun showSettings() {
        val s = sound()
        SettingsUi.list(
            this, "تنظیمات",
            listOf(
                "تغییر نام" to { SettingsUi.nameDialog(this, true) {} },
                "تنظیمات صدا" to { SettingsUi.soundDialog(this, s) },
                "تنظیمات تصویر زمینه" to { SettingsUi.bgDialog(this) { root?.background = CardArt.background(this) } },
                "تنظیمات پشت کارت" to { SettingsUi.backDialog(this) {} },
                "سرعت انیمیشن" to { SettingsUi.animDialog(this) },
                "سرعت پخش کارت‌ها" to { SettingsUi.speedDialog(this, s) },
                SettingsUi.a11yLabel(this) to { SettingsUi.a11yToggle(this) {} }
            ),
            "بستن"
        )
    }

    override fun onResume() {
        super.onResume()
        backBtn.visibility = if (MpActivity.active) View.VISIBLE else View.GONE
        resumeBtn.visibility = if (SaveStore.exists(this)) View.VISIBLE else View.GONE
        resumeDuoBtn.visibility = if (DuoSaveStore.exists(this)) View.VISIBLE else View.GONE
        root?.background = CardArt.background(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        snd?.release()
        snd = null
    }
}
