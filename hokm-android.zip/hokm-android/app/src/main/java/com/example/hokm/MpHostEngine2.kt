package com.example.hokm

import android.os.Handler
import com.example.hokm.engine.Bot2
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText
import com.example.hokm.engine.Deck
import com.example.hokm.engine.Entry2
import com.example.hokm.engine.Game2
import com.example.hokm.engine.Phase2
import com.example.hokm.engine.Result2
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * The table of a two-player multi-phone game, running on the host phone (always player 0). Player 1 is the guest;
 * while nobody sits there the robot ([Bot2], which always plays player 1) plays. Every player gets his own view as
 * JSON ("state" messages with n = 2) and a ready-made sentence to read out.
 *
 * Messages from players: {"t":"discard","ids":[a,b]}, {"t":"trump","s":suit}, {"t":"take","face":true|false},
 * {"t":"play","id":cardId}.
 */
class MpHostEngine2(
    private val ui: Handler,
    private val deliver: (seat: Int, json: String) -> Unit,
    private val changed: () -> Unit = {}
) : TableEngine {

    companion object {
        private const val IDLE = 0
        private const val DISC1 = 1 // the hakem throws away two cards
        private const val TRUMP = 2 // the hakem names the trump
        private const val DISC2 = 3 // the other player throws away two cards
        private const val DRAW = 4 // twenty steps of taking one of two cards
        private const val PLAY = 5
        private const val END = 6
    }

    override val names = arrayOf("", "")
    override val human = BooleanArray(2)
    override val seats: Int get() = 2

    override var started = false
        private set
    private var over = false
    private var hold = false
    private var thinking = false
    private var gen = 0
    private var st = IDLE
    private var note = ""
    private var lastWin = -1

    private val g = Game2()
    private val bot = Bot2(g)
    private val pool: ExecutorService = Executors.newSingleThreadExecutor()

    private var table: List<Entry2> = emptyList()
    private var tableWin = -1

    // ------------------------------------------------------------------ texts

    override fun displayName(seat: Int): String =
        if (human[seat]) (if (names[seat].isEmpty()) "بازیکن" else names[seat]) else "ربات"

    private fun who(seat: Int, v: Int): String = if (seat == v) "شما" else displayName(seat)

    private fun sortedHand(v: Int): List<Card> {
        val l = ArrayList(g.hands[v])
        Deck.sortHand(l)
        return l
    }

    private fun handText(v: Int): String = sortedHand(v).joinToString("، ") { CardText.cardName(it) }

    private fun suit(t: Int): String = CardText.SUIT_NAMES[t]

    private fun turnText(v: Int): String {
        if (st != PLAY) return ""
        return if (g.turn == v) {
            " نوبت شماست. " + (if (g.trick.isEmpty()) "شما شروع می‌کنید." else "خال زمین: " + suit(g.trick[0].c.s) + ".")
        } else {
            " نوبت " + who(g.turn, v) + "."
        }
    }

    // ------------------------------------------------------------------ messages

    private fun stateName(): String = when (st) {
        DISC1, DISC2 -> "DISC"
        TRUMP -> "TRUMP"
        DRAW -> "DRAW"
        PLAY -> "PLAY"
        END -> "END"
        else -> "IDLE"
    }

    private fun entries(l: List<Entry2>): JSONArray {
        val a = JSONArray()
        for (e in l) a.put(JSONArray().put(e.p).put(e.c.id))
        return a
    }

    private fun stateFor(v: Int, say: String, sfx: List<String>): JSONObject {
        val o = JSONObject()
        o.put("t", "state")
        o.put("n", 2)
        o.put("seat", v)
        o.put("st", stateName())
        o.put("hk", g.hk)
        o.put("trump", if (g.trump in 0..3 && st >= DISC2) g.trump else -1)
        o.put("turn", g.turn)
        o.put("sc", JSONArray().put(g.sc[0]).put(g.sc[1]))
        o.put("tk", JSONArray().put(g.tk[0]).put(g.tk[1]))
        val hand = JSONArray()
        for (c in sortedHand(v)) hand.put(c.id)
        o.put("hand", hand)
        val legal = JSONArray()
        if (st == PLAY && g.turn == v && human[v] && !hold && !over) for (c in g.legal(v)) legal.put(c.id)
        o.put("legal", legal)
        o.put("table", entries(if (hold) table else g.trick))
        o.put("tableWin", if (hold) tableWin else -1)
        o.put("last", entries(g.lastTrick))
        o.put("lastWin", lastWin)
        val nm = JSONArray()
        for (s in 0 until 2) nm.put(displayName(s))
        o.put("names", nm)
        val hm = JSONArray()
        for (s in 0 until 2) hm.put(human[s])
        o.put("human", hm)
        o.put("need", if ((st == DISC1 && v == g.hk) || (st == DISC2 && v != g.hk)) 2 else 0)
        o.put("canPick", st == TRUMP && v == g.hk)
        o.put("ch", g.ch)
        o.put("up", if (st == DRAW) (g.up?.id ?: -1) else -1)
        o.put("canTake", st == DRAW && g.ch == v && human[v])
        o.put("step", g.step)
        o.put("over", over)
        o.put("say", say)
        val sf = JSONArray()
        for (x in sfx) sf.put(x)
        o.put("sfx", sf)
        return o
    }

    private fun push(say: (Int) -> String, sfx: (Int) -> List<String> = { emptyList() }) {
        for (v in 0 until 2) {
            if (human[v]) deliver(v, stateFor(v, say(v), sfx(v)).toString())
        }
        changed()
    }

    // ------------------------------------------------------------------ backup for host migration

    override fun snapshot(): String {
        val o = JSONObject()
        o.put("game", DuoSaveStore.dump(g, st == PLAY))
        o.put("over", over)
        val nm = JSONArray()
        for (n in names) nm.put(n)
        o.put("names", nm)
        val hm = JSONArray()
        for (h in human) hm.put(h)
        o.put("human", hm)
        return o.toString()
    }

    override fun restore(s: String): Boolean {
        return try {
            val o = JSONObject(s)
            val r = DuoSaveStore.loadInto(g, o.getString("game"))
            if (r == DuoSaveStore.NONE) return false
            val nm = o.getJSONArray("names")
            val hm = o.getJSONArray("human")
            for (i in 0 until 2) {
                names[i] = nm.optString(i)
                human[i] = hm.optBoolean(i)
            }
            over = o.optBoolean("over")
            started = true
            hold = false
            thinking = false
            table = emptyList()
            tableWin = -1
            lastWin = -1
            st = if (r == DuoSaveStore.PLAY) PLAY else IDLE
            gen++
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun resume(note: String) {
        gen++
        hold = false
        thinking = false
        if (over) {
            push({ _ -> note })
            return
        }
        if (st == PLAY) {
            push({ v -> note + turnText(v) })
            drive()
            return
        }
        push({ _ -> note + " دور از اول پخش می‌شود." })
        val my = gen
        ui.postDelayed({ if (my == gen) startRound() }, 3000)
    }

    /** The guest that takes over as host becomes player 0: turn the whole table around. */
    override fun reseatHost(oldSeat: Int): Int {
        if (oldSeat != 1) return oldSeat
        var t = g.sc[0]; g.sc[0] = g.sc[1]; g.sc[1] = t
        t = g.tk[0]; g.tk[0] = g.tk[1]; g.tk[1] = t
        g.hk = 1 - g.hk
        val h0 = g.hands[0]; g.hands[0] = g.hands[1]; g.hands[1] = h0
        g.trick = g.trick.map { Entry2(1 - it.p, it.c) }.toMutableList()
        g.lastTrick = g.lastTrick.map { Entry2(1 - it.p, it.c) }
        val v0 = HashSet(g.vo[0]); val v1 = HashSet(g.vo[1])
        g.vo[0].clear(); g.vo[0].addAll(v1)
        g.vo[1].clear(); g.vo[1].addAll(v0)
        g.turn = 1 - g.turn
        g.ch = 1 - g.ch
        if (g.kt != -1) g.kt = 1 - g.kt
        val n0 = names[0]; names[0] = names[1]; names[1] = n0
        val hu = human[0]; human[0] = human[1]; human[1] = hu
        return 0
    }

    // ------------------------------------------------------------------ flow

    override fun start() {
        gen++
        over = false
        started = true
        g.newMatch(Random.nextInt(2))
        startRound()
    }

    override fun sync(seat: Int) {
        if (started && seat in 0..1 && human[seat]) deliver(seat, stateFor(seat, "", emptyList()).toString())
    }

    override fun seatJoin(seat: Int, name: String) {
        human[seat] = true
        names[seat] = name
        if (started) {
            val nm = displayName(seat)
            push({ v -> if (v == seat) "به بازی پیوستید." else "$nm به بازی پیوست." })
            drive()
        }
    }

    override fun seatLeave(seat: Int) {
        val nm = displayName(seat)
        human[seat] = false
        names[seat] = ""
        if (!started) return
        if (st in DISC1..DISC2) {
            // the robot cannot take over in the middle of throwing cards away: deal the round again
            note = "$nm از بازی خارج شد؛ ربات جای او را می‌گیرد و دور از اول پخش می‌شود. "
            startRound()
        } else {
            push({ _ -> "$nm از بازی خارج شد؛ ربات جای او را می‌گیرد." })
            drive()
        }
    }

    override fun stop() {
        gen++
        ui.removeCallbacksAndMessages(null)
        pool.shutdownNow()
    }

    private fun startRound() {
        gen++
        hold = false
        thinking = false
        table = emptyList()
        tableWin = -1
        lastWin = -1
        g.startRound()
        st = DISC1
        val hk = g.hk
        val pre = note
        note = ""
        push({ v ->
            pre + (if (v == hk) "دور جدید. شما حاکم هستید. پنج کارت شما: " + handText(v) + ". دو کارت را برای کنار گذاشتن انتخاب کنید."
            else "دور جدید. " + who(hk, v) + " حاکم است و دو کارتش را کنار می‌گذارد و حکم را تعیین می‌کند...")
        }, { _ -> listOf("shuffle") })
        drive()
    }

    /** Lets the robot act when it is the robot's turn. The robot is always player 1. */
    private fun drive() {
        if (over || !started || thinking || hold) return
        when (st) {
            DISC1 -> if (!human[g.hk]) botAsHakem()
            DRAW -> if (!human[g.ch]) botDraw()
            PLAY -> if (!human[g.turn]) botMove(g.turn)
            else -> {}
        }
    }

    private fun botAsHakem() {
        thinking = true
        val my = gen
        try {
            pool.execute {
                val ch = try {
                    bot.choose2Hakem(g.hands[1], 1)
                } catch (e: Exception) {
                    Bot2.choose2Heur(g.hands[1])
                }
                ui.post {
                    thinking = false
                    if (my == gen && st == DISC1 && g.hk == 1 && !human[1]) {
                        g.trump = ch.trump
                        g.botKeep(ch.keep)
                        st = DISC2
                        val t = ch.trump
                        push({ v ->
                            "حریف حاکم است، دو کارتش را کنار گذاشت و حکم را تعیین کرد: " + suit(t) +
                                ". پنج کارت شما: " + handText(v) + ". دو کارت را برای کنار گذاشتن انتخاب کنید."
                        })
                    } else {
                        drive()
                    }
                }
            }
        } catch (e: Exception) {
            thinking = false
        }
    }

    private fun botDraw() {
        thinking = true
        val my = gen
        ui.postDelayed({
            if (my != gen) {
                thinking = false
                return@postDelayed
            }
            try {
                pool.execute {
                    val face = try { bot.drawFace() } catch (e: Exception) { true }
                    ui.post {
                        thinking = false
                        if (my == gen && st == DRAW && g.ch == 1 && !human[1]) {
                            g.take(1, face)
                            drawNext({ v -> who(1, v) + " کارت " + (if (face) "رو" else "پشت") + " را برداشت. " })
                        } else {
                            drive()
                        }
                    }
                }
            } catch (e: Exception) {
                thinking = false
            }
        }, 500)
    }

    private fun botMove(p: Int) {
        thinking = true
        val my = gen
        ui.postDelayed({
            if (my != gen) {
                thinking = false
                return@postDelayed
            }
            try {
                pool.execute {
                    val c = try { bot.pickCard() } catch (e: Exception) { g.legal(1).random() }
                    ui.post {
                        thinking = false
                        if (my == gen && st == PLAY && g.turn == p && !human[p] && !hold) doPlay(p, c) else drive()
                    }
                }
            } catch (e: Exception) {
                thinking = false
            }
        }, 700)
    }

    override fun action(seat: Int, o: JSONObject) {
        if (!started || over || hold || seat !in 0..1 || !human[seat]) return
        when (o.optString("t")) {
            "discard" -> {
                if (!((st == DISC1 && seat == g.hk) || (st == DISC2 && seat != g.hk))) return
                val a = o.optJSONArray("ids") ?: return
                if (a.length() != 2) return
                val cards = ArrayList<Card>()
                for (i in 0 until 2) {
                    val id = a.optInt(i, -1)
                    val c = g.hands[seat].firstOrNull { it.id == id } ?: return
                    if (cards.contains(c)) return
                    cards.add(c)
                }
                g.hands[seat].removeAll(cards.toSet())
                if (st == DISC1) {
                    st = TRUMP
                    push({ v ->
                        if (v == seat) "دو کارت کنار گذاشته شد. کارت‌های شما: " + handText(v) + ". حکم را انتخاب کنید."
                        else who(seat, v) + " دو کارتش را کنار گذاشت و حکم را انتخاب می‌کند..."
                    })
                } else {
                    beginDraw({ _ -> "دو کارت کنار گذاشته شد. حکم " + suit(g.trump) + " است. " })
                }
            }
            "trump" -> {
                val t = o.optInt("s", -1)
                if (st != TRUMP || seat != g.hk || t !in 0..3) return
                g.trump = t
                val other = 1 - seat
                if (!human[other]) {
                    g.botKeep(Bot2.keepThree(g.hands[other], t))
                    beginDraw({ _ -> "حکم " + suit(t) + " شد. " })
                } else {
                    st = DISC2
                    push({ v ->
                        if (v == seat) "حکم " + suit(t) + " شد. منتظر کنار گذاشتن دو کارت توسط " + who(other, v) + "..."
                        else who(seat, v) + " حکم را " + suit(t) + " تعیین کرد. پنج کارت شما: " + handText(v) +
                            ". دو کارت را برای کنار گذاشتن انتخاب کنید."
                    })
                }
            }
            "take" -> {
                if (st != DRAW || g.ch != seat) return
                val face = o.optBoolean("face")
                val got = if (face) g.up else g.dn
                if (got == null) return
                g.take(seat, face, false)
                drawNext({ v ->
                    if (v == seat) "کارت گرفته‌شده: " + CardText.cardName(got) + ". "
                    else who(seat, v) + " کارت " + (if (face) "رو" else "پشت") + " را برداشت. "
                })
            }
            "play" -> {
                if (st != PLAY || g.turn != seat || thinking) return
                val id = o.optInt("id", -1)
                val c = g.legal(seat).firstOrNull { it.id == id } ?: return
                doPlay(seat, c)
            }
            "sync" -> sync(seat)
        }
    }

    private fun beginDraw(prefix: (Int) -> String) {
        g.beginDraw()
        st = DRAW
        drawNext(prefix)
    }

    private fun drawNext(prefix: (Int) -> String) {
        if (!g.nextPair()) {
            g.startPlay()
            st = PLAY
            push({ v -> prefix(v) + "کارت‌ها پخش شد. کارت‌های شما: " + handText(v) + "." + turnText(v) })
            drive()
            return
        }
        val ch = g.ch
        val up = g.up!!
        push({ v ->
            prefix(v) + "مرحله " + CardText.fa(g.step + 1) + " از ۲۰. " +
                (if (v == ch) "کارت رو: " + CardText.cardName(up) + ". یکی را بردارید؛ دیگری دور ریخته می‌شود."
                else who(ch, v) + " بین کارت رو (" + CardText.cardName(up) + ") و کارت پشت انتخاب می‌کند...")
        })
        drive()
    }

    private fun doPlay(p: Int, c: Card) {
        val hkBefore = g.hk
        val res = g.play(p, c)
        fun played(v: Int): String =
            who(p, v) + " " + CardText.cardName(c) + (if (p == v) " بازی کردید" else " بازی کرد") +
                (if (c.s == g.trump) " (حکم)." else ".")
        if (!res.trickDone) {
            table = ArrayList(g.trick)
            push({ v -> played(v) + turnText(v) }, { _ -> listOf("card") })
            drive()
            return
        }
        val w = res.winner
        table = g.lastTrick
        tableWin = w
        lastWin = w
        hold = true
        fun won(v: Int): String =
            (if (w == v) "شما دست را بردید." else who(w, v) + " دست را برد.") +
                " دست‌ها: شما " + CardText.fa(g.tk[v]) + "، حریف " + CardText.fa(g.tk[1 - v]) + "."
        fun trickSfx(v: Int): List<String> = listOf("card", if (w == v) "trick" else "tlose")
        val hand = res.hand
        val my = gen
        if (hand != null) {
            st = END
            if (hand.gameOver) over = true
            push({ v -> played(v) + " " + won(v) + " " + handMessage(hand, hkBefore, v) }, { v -> trickSfx(v) + endSfx(hand, v) })
            if (!hand.gameOver) {
                ui.postDelayed({ if (my == gen) startRound() }, 4000)
            }
            return
        }
        push({ v -> played(v) + " " + won(v) }, { v -> trickSfx(v) })
        ui.postDelayed({
            if (my != gen) return@postDelayed
            hold = false
            table = emptyList()
            tableWin = -1
            push({ v -> turnText(v).trim() })
            drive()
        }, 1500)
    }

    private fun handMessage(h: Result2, hk: Int, v: Int): String {
        val mine = h.team == v
        val bn = if (h.team == hk) "بام" else "پر بام"
        if (h.bam) return if (mine) "شما $bn کردید و بازی را بردید!" else "حریف $bn کرد و بازی را برد."
        if (h.gameOver) return if (mine) "شما بازی را بردید!" else "حریف بازی را برد."
        val extra = if (h.kot) {
            if (h.team == hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)"
        } else " (۱ امتیاز)"
        return (if (mine) "شما این دست را بردید" else "حریف این دست را برد") + extra + "."
    }

    private fun endSfx(h: Result2, v: Int): List<String> {
        val mine = h.team == v
        val l = ArrayList<String>()
        if (h.kot) l.add(if (mine) "kwin" else "klose")
        if (h.gameOver) l.add(if (mine) "fwin" else "flose")
        if (!h.kot && !h.gameOver) l.add(if (mine) "win" else "lose")
        return l
    }
}
