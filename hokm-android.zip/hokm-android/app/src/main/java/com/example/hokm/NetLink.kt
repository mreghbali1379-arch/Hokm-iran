package com.example.hokm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.MacAddress
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest
import android.os.Build
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.ArrayDeque
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Plays the game over Wi-Fi instead of Nearby Connections.
 *  - direct == false: every phone is on the same Wi-Fi network (router or a phone's hotspot).
 *    The host opens a TCP port and announces itself with mDNS (NsdManager).
 *  - direct == true : Wi-Fi Direct. The host creates a Wi-Fi Direct group, the others join it,
 *    then everything runs over the same TCP link.
 * It speaks the same small interface as the Nearby code in MainActivity (conn / open / msg / drop /
 * found / lost / err events), so the game logic does not change.
 */
class NetLink(
    private val ctx: Context,
    private val direct: Boolean,
    private val emit: (type: String, cid: Int, data: String) -> Unit
) : Link {
    companion object {
        const val PORT = 47531
        private const val SVC = "_hokm._tcp"
    }

    private val lock = Any()
    private val peers = HashMap<Int, Peer>()
    private val writer: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile private var closed = false
    @Volatile private var hosting = false
    @Volatile private var scanning = false
    @Volatile private var scanActive = false
    @Volatile private var max = 4
    @Volatile private var room = ""
    @Volatile private var hostName = ""
    @Volatile private var myName = ""
    @Volatile private var wantRoom: String? = null
    private var nextId = 1
    @Volatile private var server: ServerSocket? = null

    init {
        startHeartbeat()
    }

    // ---------------------------------------------------------------- peers

    private class Peer(val id: Int, val sock: Socket) {
        val os: OutputStream = sock.getOutputStream()
        @Volatile var open = true

        fun close() {
            open = false
            try { sock.close() } catch (e: Exception) { }
        }
    }

    private fun dropPeer(id: Int, expected: Peer?, notify: Boolean) {
        val p: Peer
        synchronized(lock) {
            val cur = peers[id] ?: return
            if (expected != null && cur !== expected) return
            peers.remove(id)
            p = cur
        }
        p.close()
        if (notify) emit("drop", id, "")
    }

    private fun readLoop(p: Peer, r: BufferedReader) {
        try {
            while (p.open) {
                val line = r.readLine() ?: break
                if (line.isNotEmpty()) emit("msg", p.id, line)
            }
        } catch (e: Exception) {
            // timeout or broken link
        }
        dropPeer(p.id, p, true)
    }

    override fun send(id: Int, msg: String?) {
        if (msg == null || closed) return
        try {
            writer.execute {
                val p: Peer? = synchronized(lock) { peers[id] }
                if (p != null) {
                    try {
                        p.os.write((msg + "\n").toByteArray(Charsets.UTF_8))
                        p.os.flush()
                    } catch (e: Exception) {
                        dropPeer(id, p, true)
                    }
                }
            }
        } catch (e: Exception) {
            // writer already shut down
        }
    }

    override fun drop(id: Int) {
        try {
            writer.execute {
                try { Thread.sleep(500) } catch (ie: InterruptedException) { }
                dropPeer(id, null, false)
            }
        } catch (e: Exception) {
        }
    }

    // empty line every 3 s: a dead link is noticed within ~12 s
    private fun startHeartbeat() {
        val hb = Thread {
            while (!closed) {
                try { Thread.sleep(3000) } catch (ie: InterruptedException) { return@Thread }
                val ids: List<Int> = synchronized(lock) { peers.keys.toList() }
                for (k in ids) send(k, "")
            }
        }
        hb.isDaemon = true
        hb.start()
    }

    // ---------------------------------------------------------------- host

    override fun startHost(maxClients: Int, roomId: String?, name: String?) {
        stopHost()
        max = maxClients
        room = roomId ?: ""
        hostName = name ?: ""
        hosting = true
        try {
            val srv = ServerSocket()
            srv.reuseAddress = true
            srv.bind(InetSocketAddress(PORT))
            server = srv
            Thread { acceptLoop(srv) }.start()
        } catch (e: Exception) {
            hosting = false
            emit("err", 0, "باز کردن میزبان ممکن نشد. (جزئیات فنی: " + e.message + ")")
            return
        }
        if (direct) p2pHost() else nsdRegister()
    }

    override fun stopHost() {
        hosting = false
        val s = server
        server = null
        if (s != null) {
            try { s.close() } catch (e: Exception) { }
        }
        if (direct) p2pStopHost() else nsdUnregister()
    }

    private fun acceptLoop(srv: ServerSocket) {
        while (!closed && hosting) {
            try {
                val s = srv.accept()
                Thread { incoming(s) }.start()
            } catch (e: Exception) {
                break
            }
        }
    }

    private fun incoming(s: Socket) {
        try {
            s.tcpNoDelay = true
            s.soTimeout = 5000
            val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            val first = r.readLine()
            if (first == null || !first.startsWith("HK1\t")) {
                s.close()
                return
            }
            val name = first.substring(4).trim()
            val os = s.getOutputStream()
            val n: Int = synchronized(lock) { peers.size }
            if (!hosting || n >= max) {
                os.write("FULL\n".toByteArray(Charsets.UTF_8))
                os.flush()
                s.close()
                return
            }
            os.write("OK\n".toByteArray(Charsets.UTF_8))
            os.flush()
            s.soTimeout = 12000
            val p: Peer
            val id: Int
            synchronized(lock) {
                id = nextId++
                p = Peer(id, s)
                peers[id] = p
            }
            val ia = s.inetAddress
            emit("conn", id, (if (name.isEmpty()) "بازیکن" else name) + "\u0001tcp:" + (ia?.hostAddress ?: ""))
            readLoop(p, r)
        } catch (e: Exception) {
            try { s.close() } catch (x: Exception) { }
        }
    }

    // ---------------------------------------------------------------- client

    override fun startScan() {
        scanning = true
        startDiscovery()
    }

    override fun stopScan() {
        scanning = false
        if (wantRoom == null) stopDiscovery()
    }

    /** target = "tcp:ip:port" (same network), "p2p:mac|room" (Wi-Fi Direct) or "room:id". */
    override fun connect(target: String?, name: String?) {
        myName = if (name.isNullOrEmpty()) "بازیکن" else name
        dropPeer(0, null, false)
        if (target == null) return
        if (target.startsWith("tcp:")) {
            val body = target.substring(4)
            val k = body.lastIndexOf(':')
            if (k < 0) return
            connectTcp(body.substring(0, k), parsePort(body.substring(k + 1)))
        } else if (target.startsWith("p2p:")) {
            val body = target.substring(4)
            val k = body.indexOf('|')
            if (k < 0) return
            p2pConnect(body.substring(0, k), body.substring(k + 1))
        } else if (target.startsWith("room:")) {
            val r = target.substring(5)
            wantRoom = r
            startDiscovery()
            val wait = if (direct) 25000L else 12000L
            Thread {
                try { Thread.sleep(wait) } catch (ie: InterruptedException) { return@Thread }
                if (r == wantRoom) {
                    wantRoom = null
                    if (!scanning) stopDiscovery()
                    emit("err", 0, "بازی پیدا نشد. میزبان نزدیک نیست، بازی را بسته است یا وای‌فای هر دو گوشی روشن نیست.")
                }
            }.start()
        }
    }

    private fun parsePort(s: String): Int {
        return try { s.trim().toInt() } catch (e: Exception) { PORT }
    }

    private fun connectTcp(ip: String, port: Int) {
        Thread {
            var s: Socket? = null
            try {
                s = Socket()
                s.connect(InetSocketAddress(ip, port), 7000)
                s.tcpNoDelay = true
                s.soTimeout = 7000
                val os = s.getOutputStream()
                os.write(("HK1\t" + myName + "\n").toByteArray(Charsets.UTF_8))
                os.flush()
                val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                val ans = r.readLine()
                if (ans != "OK") {
                    s.close()
                    emit("err", 0, if (ans == "FULL") "این میز پر است." else "اتصال برقرار نشد.")
                    return@Thread
                }
                s.soTimeout = 12000
                val p = Peer(0, s)
                val old: Peer?
                synchronized(lock) { old = peers.put(0, p) }
                old?.close()
                scanning = false
                wantRoom = null
                stopDiscovery()
                emit("open", 0, "")
                readLoop(p, r)
            } catch (e: Exception) {
                try { s?.close() } catch (x: Exception) { }
                emit("err", 0, "اتصال برقرار نشد. مطمئن شوید میزبان بازی را باز کرده و وای‌فای هر دو گوشی روشن است. (جزئیات فنی: " + e.message + ")")
            }
        }.start()
    }

    override fun closeAll() {
        hosting = false
        scanning = false
        wantRoom = null
        stopHost()
        stopDiscovery()
        val all: List<Peer>
        synchronized(lock) {
            all = peers.values.toList()
            peers.clear()
        }
        for (p in all) p.close()
        if (direct) p2pReset()
    }

    override fun shutdown() {
        closed = true
        closeAll()
        p2pRelease()
        writer.shutdown()
    }

    private fun startDiscovery() {
        if (direct) p2pScan() else nsdScan()
    }

    private fun stopDiscovery() {
        if (direct) p2pStopScan() else nsdStopScan()
    }

    // ---------------------------------------------------------------- same Wi-Fi network (mDNS)

    private var nsd: NsdManager? = null
    private var regL: NsdManager.RegistrationListener? = null
    private var discL: NsdManager.DiscoveryListener? = null
    private val resolveQ = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private val nsdTargets = HashMap<String, String>()

    private fun nsdm(): NsdManager {
        var m = nsd
        if (m == null) {
            m = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
            nsd = m
        }
        return m
    }

    private fun nsdRegister() {
        try {
            val si = NsdServiceInfo()
            si.serviceName = "HK-$room"
            si.serviceType = SVC
            si.port = PORT
            si.setAttribute("room", room)
            si.setAttribute("host", hostName)
            val l = object : NsdManager.RegistrationListener {
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {
                    emit("err", 0, "اعلام میز در شبکهٔ وای‌فای ناموفق بود. (کد $e)")
                }

                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
            }
            regL = l
            nsdm().registerService(si, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {
            emit("err", 0, "اعلام میز در شبکهٔ وای‌فای ممکن نشد. (جزئیات فنی: " + e.message + ")")
        }
    }

    private fun nsdUnregister() {
        val l = regL
        regL = null
        if (l != null) {
            try { nsdm().unregisterService(l) } catch (e: Exception) { }
        }
    }

    private fun nsdScan() {
        if (discL != null) return
        try {
            val l = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(t: String, e: Int) {
                    discL = null
                    emit("err", 0, "جست‌وجو در شبکهٔ وای‌فای ممکن نشد. (کد $e)")
                }

                override fun onStopDiscoveryFailed(t: String, e: Int) {}
                override fun onDiscoveryStarted(t: String) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onServiceFound(i: NsdServiceInfo) {
                    queueResolve(i)
                }

                override fun onServiceLost(i: NsdServiceInfo) {
                    val tg: String? = synchronized(lock) { nsdTargets.remove(i.serviceName) }
                    if (tg != null && scanning) emit("lost", 0, tg)
                }
            }
            discL = l
            nsdm().discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {
            discL = null
            emit("err", 0, "جست‌وجو در شبکهٔ وای‌فای ممکن نشد. (جزئیات فنی: " + e.message + ")")
        }
    }

    private fun nsdStopScan() {
        val l = discL
        discL = null
        if (l != null) {
            try { nsdm().stopServiceDiscovery(l) } catch (e: Exception) { }
        }
        synchronized(resolveQ) { resolveQ.clear() }
    }

    private fun queueResolve(i: NsdServiceInfo) {
        synchronized(resolveQ) { resolveQ.add(i) }
        pumpResolve()
    }

    private fun resolveDone() {
        synchronized(resolveQ) { resolving = false }
        pumpResolve()
    }

    // older Android versions resolve only one service at a time, so queue them
    private fun pumpResolve() {
        val next: NsdServiceInfo
        synchronized(resolveQ) {
            if (resolving || resolveQ.isEmpty()) return
            next = resolveQ.poll() ?: return
            resolving = true
        }
        try {
            @Suppress("DEPRECATION")
            nsdm().resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) {
                    resolveDone()
                }

                override fun onServiceResolved(i: NsdServiceInfo) {
                    try { nsdResolved(i) } catch (e: Exception) { }
                    resolveDone()
                }
            })
        } catch (e: Exception) {
            resolveDone()
        }
    }

    private fun attr(a: Map<String, ByteArray?>?, k: String): String {
        if (a == null) return ""
        val v = a[k]
        return if (v == null) "" else String(v, Charsets.UTF_8)
    }

    @Suppress("DEPRECATION")
    private fun nsdResolved(i: NsdServiceInfo) {
        val h = i.host ?: return
        val ip = h.hostAddress ?: return
        val port = i.port
        val r = attr(i.attributes, "room")
        val hn = attr(i.attributes, "host")
        if (r.isEmpty()) return
        val target = "tcp:$ip:$port"
        synchronized(lock) { nsdTargets[i.serviceName] = target }
        if (scanning) emit("found", 0, target + "\u0001" + r + "\u0001" + hn)
        val w = wantRoom
        if (w != null && w == r) {
            wantRoom = null
            connectTcp(ip, port)
        }
    }

    // ---------------------------------------------------------------- Wi-Fi Direct

    private var p2p: WifiP2pManager? = null
    private var ch: WifiP2pManager.Channel? = null
    private var rx: BroadcastReceiver? = null
    @Volatile private var pendingClient = false

    private fun groupName(r: String) = "DIRECT-HK-$r"

    private fun groupPass(r: String) = "hokm-$r-play"

    private fun al(ok: (() -> Unit)?, bad: (() -> Unit)?): WifiP2pManager.ActionListener {
        return object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                ok?.invoke()
            }

            override fun onFailure(reason: Int) {
                bad?.invoke()
            }
        }
    }

    private fun p2pInit(): Boolean {
        if (p2p != null && ch != null) return true
        return try {
            val m = (ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager?) ?: return false
            p2p = m
            ch = m.initialize(ctx, Looper.getMainLooper(), null)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, intent: Intent?) {
                    p2pChanged()
                }
            }
            rx = receiver
            ctx.registerReceiver(receiver, IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION))
            ch != null
        } catch (e: Exception) {
            false
        }
    }

    private fun p2pRelease() {
        val r = rx
        rx = null
        if (r != null) {
            try { ctx.unregisterReceiver(r) } catch (e: Exception) { }
        }
    }

    private fun p2pChanged() {
        val m = p2p ?: return
        val c = ch ?: return
        if (!pendingClient) return
        try {
            m.requestConnectionInfo(c) { info ->
                if (info != null && info.groupFormed && !info.isGroupOwner &&
                    pendingClient && info.groupOwnerAddress != null
                ) {
                    pendingClient = false
                    connectTcp(info.groupOwnerAddress.hostAddress ?: "", PORT)
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun p2pFail(m: String) {
        emit("err", 0, m)
    }

    private fun p2pHost() {
        if (!p2pInit()) {
            p2pFail("وای‌فای مستقیم روی این گوشی در دسترس نیست.")
            return
        }
        val m = p2p ?: return
        val c = ch ?: return
        val r = room
        try {
            // announce the table so other phones can find it
            val txt = HashMap<String, String>()
            txt["room"] = r
            txt["host"] = hostName
            val si = WifiP2pDnsSdServiceInfo.newInstance("hk$r", SVC, txt)
            m.clearLocalServices(c, al({ addLocal(si) }, { addLocal(si) }))
            // then make our own group with a name/password derived from the room id
            m.removeGroup(c, al({ createGroupNow() }, { createGroupNow() }))
        } catch (e: Exception) {
            p2pFail("باز کردن وای‌فای مستقیم ممکن نشد. (جزئیات فنی: " + e.message + ")")
        }
    }

    private fun addLocal(si: WifiP2pDnsSdServiceInfo) {
        val m = p2p ?: return
        val c = ch ?: return
        try { m.addLocalService(c, si, al(null, null)) } catch (e: Exception) { }
    }

    private fun createGroupNow() {
        if (!hosting) return
        val m = p2p ?: return
        val c = ch ?: return
        val bad = { p2pFail("ساختن گروه وای‌فای مستقیم ممکن نشد. وای‌فای و موقعیت مکانی را روشن کنید و اجازه‌ها را بدهید.") }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cfg = WifiP2pConfig.Builder()
                    .setNetworkName(groupName(room))
                    .setPassphrase(groupPass(room))
                    .build()
                m.createGroup(c, cfg, al(null, bad))
            } else {
                m.createGroup(c, al(null, bad))
            }
        } catch (e: Exception) {
            bad()
        }
    }

    private fun p2pStopHost() {
        val m = p2p ?: return
        val c = ch ?: return
        try { m.clearLocalServices(c, al(null, null)) } catch (e: Exception) { }
        try { m.removeGroup(c, al(null, null)) } catch (e: Exception) { }
    }

    private fun p2pReset() {
        val m = p2p ?: return
        val c = ch ?: return
        pendingClient = false
        try { m.cancelConnect(c, al(null, null)) } catch (e: Exception) { }
        try { m.removeGroup(c, al(null, null)) } catch (e: Exception) { }
    }

    private fun p2pScan() {
        if (scanActive) return
        if (!p2pInit()) {
            p2pFail("وای‌فای مستقیم روی این گوشی در دسترس نیست.")
            return
        }
        val m = p2p ?: return
        val c = ch ?: return
        scanActive = true
        try {
            m.setDnsSdResponseListeners(
                c,
                { _, _, _ -> },
                { _, txt, dev ->
                    val r: String? = txt?.get("room")
                    if (r != null && dev != null) {
                        val h: String? = txt["host"]
                        val tg = "p2p:" + dev.deviceAddress + "|" + r
                        if (scanning) emit("found", 0, tg + "\u0001" + r + "\u0001" + (h ?: dev.deviceName))
                        val w = wantRoom
                        if (w != null && w == r) {
                            wantRoom = null
                            p2pConnect(dev.deviceAddress, r)
                        }
                    }
                }
            )
            m.clearServiceRequests(c, al({ addRequest() }, { addRequest() }))
        } catch (e: Exception) {
            scanActive = false
            p2pFail("جست‌وجوی وای‌فای مستقیم ممکن نشد. (جزئیات فنی: " + e.message + ")")
        }
        // service discovery has to be repeated now and then
        Thread {
            while (scanActive && !closed) {
                try { Thread.sleep(10000) } catch (ie: InterruptedException) { return@Thread }
                if (scanActive) discoverNow()
            }
        }.start()
    }

    private fun addRequest() {
        val m = p2p ?: return
        val c = ch ?: return
        try {
            m.addServiceRequest(c, WifiP2pDnsSdServiceRequest.newInstance(), al({ discoverNow() }, { discoverNow() }))
        } catch (e: Exception) {
        }
    }

    private fun discoverNow() {
        val m = p2p ?: return
        val c = ch ?: return
        val services = {
            try { m.discoverServices(c, al(null, null)) } catch (e: Exception) { }
        }
        try {
            m.discoverPeers(c, al(services, services))
        } catch (e: Exception) {
        }
    }

    private fun p2pStopScan() {
        scanActive = false
        val m = p2p ?: return
        val c = ch ?: return
        try { m.clearServiceRequests(c, al(null, null)) } catch (e: Exception) { }
        try { m.stopPeerDiscovery(c, al(null, null)) } catch (e: Exception) { }
    }

    private fun p2pConnect(address: String, r: String) {
        if (!p2pInit()) {
            p2pFail("وای‌فای مستقیم روی این گوشی در دسترس نیست.")
            return
        }
        val m = p2p ?: return
        val c = ch ?: return
        pendingClient = true
        try {
            val cfg: WifiP2pConfig
            if (Build.VERSION.SDK_INT >= 29) {
                cfg = WifiP2pConfig.Builder()
                    .setDeviceAddress(MacAddress.fromString(address))
                    .setNetworkName(groupName(r))
                    .setPassphrase(groupPass(r))
                    .build()
            } else {
                // older phones: the host has to accept the invitation on screen
                cfg = WifiP2pConfig()
                cfg.deviceAddress = address
                cfg.wps.setup = WpsInfo.PBC
            }
            m.connect(c, cfg, al(null) {
                pendingClient = false
                p2pFail("اتصال وای‌فای مستقیم برقرار نشد. میزبان نزدیک نیست یا آن را نپذیرفته است.")
            })
        } catch (e: Exception) {
            pendingClient = false
            p2pFail("اتصال وای‌فای مستقیم ممکن نشد. (جزئیات فنی: " + e.message + ")")
            return
        }
        Thread {
            try { Thread.sleep(25000) } catch (ie: InterruptedException) { return@Thread }
            if (pendingClient) {
                pendingClient = false
                p2pFail("اتصال وای‌فای مستقیم زمان زیادی طول کشید. دوباره امتحان کنید.")
            }
        }.start()
    }
}
