package com.example.hokm

import android.content.Context
import com.example.hokm.engine.Card
import com.example.hokm.engine.Entry
import com.example.hokm.engine.Game4
import com.example.hokm.engine.Phase
import com.example.hokm.engine.PlayRec
import org.json.JSONArray
import org.json.JSONObject

/** Keeps the four-player game in SharedPreferences so it can be continued after the app is closed. */
object SaveStore {
    private const val KEY = "solo4"
    private const val NAMES = "solo4names"

    private fun prefs(c: Context) = c.getSharedPreferences("hokm_save", Context.MODE_PRIVATE)

    fun exists(c: Context): Boolean = prefs(c).getString(KEY, null) != null

    fun clear(c: Context) {
        prefs(c).edit().remove(KEY).remove(NAMES).apply()
    }

    /** The saved game as JSON text, or null. */
    fun raw(c: Context): String? = prefs(c).getString(KEY, null)

    fun putRaw(c: Context, json: String) {
        prefs(c).edit().putString(KEY, json).apply()
    }

    /** Names of the three robots (seats 1..3) of the saved game. */
    fun saveNames(c: Context, names: List<String>) {
        prefs(c).edit().putString(NAMES, JSONArray(names).toString()).apply()
    }

    fun loadNames(c: Context): List<String>? = try {
        val a = JSONArray(prefs(c).getString(NAMES, null))
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) {
        null
    }

    fun save(c: Context, g: Game4) {
        try {
            prefs(c).edit().putString(KEY, toJson(g)).apply()
        } catch (e: Exception) {
        }
    }

    /** Fills [g] from the saved game; false (and [g] untouched) when nothing valid is saved. */
    fun load(c: Context, g: Game4): Boolean {
        val s = prefs(c).getString(KEY, null) ?: return false
        return try {
            fromJson(g, s)
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------ JSON

    private fun ids(l: List<Card>): JSONArray {
        val a = JSONArray()
        for (c in l) a.put(c.id)
        return a
    }

    private fun cards(a: JSONArray): MutableList<Card> {
        val l = ArrayList<Card>()
        for (i in 0 until a.length()) {
            val id = a.getInt(i)
            l.add(Card(id / 20, id % 20))
        }
        return l
    }

    private fun entries(l: List<Entry>): JSONArray {
        val a = JSONArray()
        for (e in l) a.put(JSONArray().put(e.seat).put(e.c.id))
        return a
    }

    private fun entriesFrom(a: JSONArray): MutableList<Entry> {
        val l = ArrayList<Entry>()
        for (i in 0 until a.length()) {
            val p = a.getJSONArray(i)
            val id = p.getInt(1)
            l.add(Entry(p.getInt(0), Card(id / 20, id % 20)))
        }
        return l
    }

    private fun ints(a: IntArray): JSONArray {
        val j = JSONArray()
        for (x in a) j.put(x)
        return j
    }

    fun toJson(g: Game4): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("hakem", g.hakem)
        o.put("trump", g.trump)
        o.put("turn", g.turn)
        o.put("kt", g.kt)
        o.put("phase", g.phase.name)
        o.put("win", g.winSeat)
        o.put("sc", ints(g.sc))
        o.put("tk", ints(g.tk))
        val hs = JSONArray()
        for (h in g.hands) hs.put(ids(h))
        o.put("hands", hs)
        o.put("deck", ids(g.deck))
        o.put("trick", entries(g.trick))
        o.put("last", entries(g.lastTrick))
        val seen = JSONArray()
        for (x in g.seen) seen.put(x)
        o.put("seen", seen)
        val vs = JSONArray()
        for (v in g.voids) {
            val a = JSONArray()
            for (x in v) a.put(x)
            vs.put(a)
        }
        o.put("voids", vs)
        val ps = JSONArray()
        for (p in g.plays) {
            ps.put(JSONArray().put(p.seat).put(p.c.id).put(p.len).put(p.led).put(p.bs).put(p.bc?.id ?: -1))
        }
        o.put("plays", ps)
        return o.toString()
    }

    fun fromJson(g: Game4, s: String): Boolean {
        val o = JSONObject(s)
        if (o.getInt("v") != 1) return false
        val hakem = o.getInt("hakem")
        val trump = o.getInt("trump")
        val turn = o.getInt("turn")
        val kt = o.getInt("kt")
        val phase = Phase.valueOf(o.getString("phase"))
        val win = o.getInt("win")
        if (hakem !in 0..3 || trump !in -1..3 || turn !in 0..3 || kt !in -1..1) return false
        val sc = o.getJSONArray("sc")
        val tk = o.getJSONArray("tk")
        if (sc.length() != 2 || tk.length() != 2) return false
        val hj = o.getJSONArray("hands")
        if (hj.length() != 4) return false
        val hands = ArrayList<MutableList<Card>>()
        for (i in 0 until 4) {
            val h = cards(hj.getJSONArray(i))
            if (h.size > 13) return false
            hands.add(h)
        }
        val deck = cards(o.getJSONArray("deck"))
        val trick = entriesFrom(o.getJSONArray("trick"))
        val last = entriesFrom(o.getJSONArray("last"))
        if (trick.size > 3 || (phase == Phase.PLAY && trump == -1)) return false
        val seenJ = o.getJSONArray("seen")
        val seen = ArrayList<Int>()
        for (i in 0 until seenJ.length()) seen.add(seenJ.getInt(i))
        val vj = o.getJSONArray("voids")
        if (vj.length() != 4) return false
        val voids = ArrayList<List<Int>>()
        for (i in 0 until 4) {
            val a = vj.getJSONArray(i)
            val l = ArrayList<Int>()
            for (k in 0 until a.length()) l.add(a.getInt(k))
            voids.add(l)
        }
        val pj = o.getJSONArray("plays")
        val plays = ArrayList<PlayRec>()
        for (i in 0 until pj.length()) {
            val p = pj.getJSONArray(i)
            val cid = p.getInt(1)
            val bid = p.getInt(5)
            plays.add(
                PlayRec(
                    p.getInt(0), Card(cid / 20, cid % 20), p.getInt(2), p.getInt(3), p.getInt(4),
                    if (bid >= 0) Card(bid / 20, bid % 20) else null
                )
            )
        }
        // everything parsed: now apply
        g.hakem = hakem
        g.trump = trump
        g.turn = turn
        g.kt = kt
        g.phase = phase
        g.winSeat = win
        g.sc[0] = sc.getInt(0)
        g.sc[1] = sc.getInt(1)
        g.tk[0] = tk.getInt(0)
        g.tk[1] = tk.getInt(1)
        for (i in 0 until 4) {
            g.hands[i].clear()
            g.hands[i].addAll(hands[i])
        }
        g.deck = deck
        g.trick = trick
        g.lastTrick = last
        g.seen.clear()
        g.seen.addAll(seen)
        for (i in 0 until 4) {
            g.voids[i].clear()
            g.voids[i].addAll(voids[i])
        }
        g.plays.clear()
        g.plays.addAll(plays)
        return true
    }
}
