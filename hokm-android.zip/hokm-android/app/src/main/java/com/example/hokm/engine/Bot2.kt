package com.example.hokm.engine

import kotlin.random.Random

/** The robot for the 2-player game: hakem choices, draw choices and card play. */
class Bot2(private val g: Game2) {
    var bot2Ms = 450L

    class Choice(val trump: Int, val keep: List<Card>)

    private class Abort : RuntimeException(null, null, false, false)

    private val abort = Abort()
    private var n2 = 0
    private var l2 = 0
    private var exLim = 15000

    companion object {
        /** Rough worth of card c when T is the trump. */
        fun v2(c: Card, T: Int): Double =
            if (c.s == T) 2 + c.r / 7.0 else if (c.r >= 12) (c.r - 9) / 1.2 else c.r / 25.0

        /** v2 adjusted for the rest of the hand h (long trump suit is good, long side suit is bad, aces are good). */
        fun g2(c: Card, T: Int, h: List<Card>): Double {
            var v = v2(c, T)
            if (c.s == T) {
                v += 0.3 * minOf(h.count { it.s == T }, 6)
            } else {
                val ns = h.count { it.s == c.s }
                if (ns >= 4) v -= 0.2 * (ns - 3)
                if (c.r == 14) v += 0.4
            }
            return v
        }

        /** Quick rule of thumb: the trump and the three cards to keep out of five. */
        fun choose2Heur(h: List<Card>): Choice {
            var bT = 0
            var bv = -1.0
            for (T in 0..3) {
                val v = h.map { v2(it, T) }.sortedDescending().take(3).sum()
                if (v > bv) {
                    bv = v
                    bT = T
                }
            }
            return Choice(bT, keepThree(h, bT))
        }

        /** The three best cards to keep when the trump is T. */
        fun keepThree(h: List<Card>, T: Int): List<Card> = h.sortedByDescending { v2(it, T) }.take(3)

        /** Should the opponent take the face-up card? (true = face-up, false = the hidden one) */
        fun draw2Face(h: List<Card>, T: Int, up: Card, gone: Set<Int>): Boolean {
            val unk = Deck.all().filter { c -> h.none { it.id == c.id } && !gone.contains(c.id) && c.id != up.id }
            val e = unk.sumOf { g2(it, T, h) } / unk.size
            return g2(up, T, h) >= e + 0.05
        }
    }

    private fun mn(a: List<Card>): Card {
        var m = a[0]
        for (c in a) if (c.r < m.r) m = c
        return m
    }

    /** Simple policy for both sides while simulating a whole round: returns [winner, points]. */
    private fun playFull2(hh: Array<List<Card>>, hk: Int, T: Int): IntArray {
        val h = arrayOf(ArrayList(hh[0]), ArrayList(hh[1]))
        val t = intArrayOf(0, 0, -1)
        var turn = hk
        var trick = ArrayList<Entry2>()
        fun pol(hand: List<Card>, led: Card?): Card {
            if (led == null) {
                var b: Card? = null
                var bv = -99
                for (c in hand) {
                    val v = c.r + (if (c.s == T) -50 else 0)
                    if (v > bv) {
                        bv = v
                        b = c
                    }
                }
                return b ?: hand[0]
            }
            val same = hand.filter { it.s == led.s }
            if (same.isNotEmpty()) {
                val w = same.filter { it.r > led.r }
                return mn(if (w.isNotEmpty()) w else same)
            }
            val tr = hand.filter { it.s == T }
            if (tr.isNotEmpty() && led.s != T) return mn(tr)
            var m = hand[0]
            for (c in hand) {
                val vc = if (c.s == T) 100 + c.r else c.r
                val vm = if (m.s == T) 100 + m.r else m.r
                if (vc < vm) m = c
            }
            return m
        }
        while (true) {
            val c = pol(h[turn], if (trick.isNotEmpty()) trick[0].c else null)
            h[turn].remove(c)
            trick.add(Entry2(turn, c))
            if (trick.size < 2) {
                turn = 1 - turn
                continue
            }
            val a = trick[0]
            val b = trick[1]
            val wn = if (if (b.c.s == a.c.s) b.c.r > a.c.r else b.c.s == T) b.p else a.p
            t[wn]++
            if (t[2] == -1 && t[wn] >= 7 && t[1 - wn] == 0) t[2] = wn
            trick = ArrayList()
            turn = wn
            val w = if (t[0] >= 7) 0 else if (t[1] >= 7) 1 else -1
            if (w >= 0 && (t[1 - w] > 0 || t[w] == 13)) {
                val bam = t[w] == 13
                return intArrayOf(w, if (bam) 7 else (if (t[2] == w) (if (w == hk) 2 else 3) else 1))
            }
        }
    }

    /** Chooses trump and the three cards to keep together, by simulating many deals. Null if the pool is too small. */
    private fun mc2Trump(h5: List<Card>, hk: Int, gone: Set<Int>): Choice? {
        val mine = HashSet<Int>()
        for (c in h5) mine.add(c.id)
        val pool = Deck.all().filter { !mine.contains(it.id) && !gone.contains(it.id) }
        if (pool.size < 33) return null
        class Opt(val T: Int, val keep: List<Card>)
        val opts = ArrayList<Opt>()
        for (T in 0..3) for (i in 0 until 5) for (j in i + 1 until 5) for (k in j + 1 until 5) {
            opts.add(Opt(T, listOf(h5[i], h5[j], h5[k])))
        }
        val sum = IntArray(opts.size)
        val t0 = System.currentTimeMillis()
        var n = 0
        while (n < 600 && (n < 40 || System.currentTimeMillis() - t0 < bot2Ms * 2)) {
            val pi = pool.shuffled()
            val opp = pi.subList(0, 13)
            for (o in opts.indices) {
                val T = opts[o].T
                val hand = ArrayList<Card>(opts[o].keep)
                for (k in 0 until 10) {
                    val a = pi[13 + 2 * k]
                    val b = pi[14 + 2 * k]
                    hand.add(if (g2(a, T, hand) >= g2(b, T, hand)) a else b)
                }
                val r = playFull2(arrayOf(opp, hand), hk, T)
                sum[o] += if (r[0] == 1) r[1] else -r[1]
            }
            n++
        }
        var b = 0
        for (i in sum.indices) if (sum[i] > sum[b]) b = i
        return Choice(opts[b].T, opts[b].keep)
    }

    /** Trump and the three cards to keep for the opponent as hakem, from its five cards. */
    fun choose2Hakem(h: List<Card>, hk: Int, gone: Set<Int> = g.gone): Choice {
        var r = choose2Heur(h)
        try {
            if (h.size == 5) {
                val m = mc2Trump(h, hk, gone)
                if (m != null) r = m
            }
        } catch (e: Exception) {
        }
        return r
    }

    /** Should the opponent (seat 1) take the face-up card in the current draw step? */
    fun drawFace(): Boolean = draw2Face(g.hands[1], g.trump, g.up!!, g.gone)

    // ------------------------------------------------------------------ playing

    private fun pts2(t: IntArray, team: Int): Int = Scoring.points(t, team, g.hk)

    private fun rp2(hand: List<Card>, led: Card?): Card {
        val T = g.trump
        if (led == null) {
            var b: Card? = null
            var bv = -99
            for (c in hand) {
                val v = c.r + (if (c.s == T) -50 else 0)
                if (v > bv) {
                    bv = v
                    b = c
                }
            }
            return b ?: hand[0]
        }
        val same = hand.filter { it.s == led.s }
        if (same.isNotEmpty()) {
            val w = same.filter { it.r > led.r }
            return mn(if (w.isNotEmpty()) w else same)
        }
        val tr = hand.filter { it.s == T }
        if (tr.isNotEmpty() && led.s != T) return mn(tr)
        var m = hand[0]
        for (c in hand) {
            val vc = if (c.s == T) 100 + c.r else c.r
            val vm = if (m.s == T) 100 + m.r else m.r
            if (vc < vm) m = c
        }
        return m
    }

    /** Plays the rest of the round quickly after the opponent plays c0; points for the opponent (seat 1). */
    private fun roll2(h0: Array<List<Card>>, p: Int, c0: Card): Int {
        val hh = arrayOf(ArrayList(h0[0]), ArrayList(h0[1]))
        val t = intArrayOf(g.tk[0], g.tk[1], g.kt)
        var trk = ArrayList<Entry2>(g.trick)
        hh[p].remove(c0)
        trk.add(Entry2(p, c0))
        var turn = 1 - p
        while (true) {
            if (trk.size == 2) {
                val w = if (g.beats(trk[1].c, trk[0].c)) trk[1].p else trk[0].p
                Scoring.adv(t, w)
                trk = ArrayList()
                turn = w
                val q = pts2(t, 1)
                if (q != Scoring.NONE) return q
            }
            val pc = rp2(hh[turn], if (trk.isNotEmpty()) trk[0].c else null)
            hh[turn].remove(pc)
            trk.add(Entry2(turn, pc))
            if (trk.size < 2) turn = 1 - turn
        }
    }

    private fun bt2(a: Int, b: Int): Boolean = if (a / 20 == b / 20) a % 20 > b % 20 else a / 20 == g.trump

    private fun without(a: IntArray, id: Int): IntArray {
        var k = 0
        for (x in a) if (x != id) k++
        val r = IntArray(k)
        var j = 0
        for (x in a) if (x != id) r[j++] = x
        return r
    }

    /** Exact search (alpha-beta) of the rest of the round; points for seat 1. */
    private fun sv2(hh: Array<IntArray>, ps: IntArray, pi: IntArray, n: Int, turn: Int, t: IntArray, alIn: Int, beIn: Int): Int {
        n2++
        if (n2 > l2) throw abort
        var al = alIn
        var be = beIn
        if (n == 2) {
            val w = if (bt2(pi[1], pi[0])) ps[1] else ps[0]
            val t2 = t.copyOf()
            Scoring.adv(t2, w)
            val q = pts2(t2, 1)
            if (q != Scoring.NONE) return q
            return sv2(hh, IntArray(2), IntArray(2), 0, w, t2, al, be)
        }
        val hand = hh[turn]
        val ls = if (n > 0) pi[0] / 20 else -1
        var cards: IntArray = hand
        if (ls >= 0) {
            val f = hand.filter { it / 20 == ls }
            if (f.isNotEmpty()) cards = f.toIntArray()
        }
        if (cards.isEmpty()) return 0
        val order = cards.sortedByDescending { (if (it / 20 == g.trump) 100 else 0) + it % 20 }
        val mx = turn == 1
        var best = if (mx) -9 else 9
        for (id in order) {
            hh[turn] = without(hand, id)
            ps[n] = turn
            pi[n] = id
            val v = sv2(hh, ps, pi, n + 1, 1 - turn, t, al, be)
            hh[turn] = hand
            if (mx) {
                if (v > best) best = v
                if (best > al) al = best
            } else {
                if (v < best) best = v
                if (best < be) be = best
            }
            if (al >= be) break
        }
        return best
    }

    private fun exact2(hs: Array<List<Card>>, c0: Card): Int? {
        val hh = arrayOf(IntArray(hs[0].size) { hs[0][it].id }, IntArray(hs[1].size) { hs[1][it].id })
        val id = c0.id
        hh[1] = without(hh[1], id)
        val ps = IntArray(2)
        val pi = IntArray(2)
        var n = 0
        for (x in g.trick) {
            ps[n] = x.p
            pi[n] = x.c.id
            n++
        }
        ps[n] = 1
        pi[n] = id
        n++
        n2 = 0
        l2 = exLim
        return try {
            sv2(hh, ps, pi, n, 0, intArrayOf(g.tk[0], g.tk[1], g.kt), -9, 9)
        } catch (e: Abort) {
            null
        }
    }

    /** The card the opponent (seat 1) plays now; always legal. */
    fun pickCard(): Card {
        return try {
            pickInner()
        } catch (e: Exception) {
            mn(g.legal(1))
        }
    }

    private fun pickInner(): Card {
        val h = g.hands[1]
        val T = g.trump
        val legal = g.legal(1)
        val bamZone = g.kt != -1 || (minOf(g.tk[0], g.tk[1]) == 0 && maxOf(g.tk[0], g.tk[1]) >= 5)
        exLim = if (bamZone) 40000 else 15000
        fun unseen(x: Int, r: Int): Boolean =
            !h.any { it.s == x && it.r == r } && !g.played.contains(x * 20 + r) && !g.gone.contains(x * 20 + r)

        val inTr = HashSet<Int>()
        for (x in g.trick) inTr.add(x.c.id)
        // of cards that are equal in effect only the lowest is tried
        fun same(d: Card, c: Card): Boolean {
            for (r in d.r + 1 until c.r) if (unseen(c.s, r) || inTr.contains(c.s * 20 + r)) return false
            return true
        }

        val cs = legal.filter { c -> !legal.any { d -> d.s == c.s && d.r < c.r && same(d, c) } }
        if (cs.size == 1) return cs[0]
        val cand = cs.sortedBy { if (it.s == T) 100 + it.r else it.r }
        val sc3 = DoubleArray(cand.size)
        val small = h.size <= (if (bamZone) 8 else 6)
        val total = if (small) 150 else 700
        val t0 = System.currentTimeMillis()
        val need = g.hands[0].size
        var pool = Deck.all().filter { unseen(it.s, it.r) }
        val pf = pool.filter { !g.vo[0].contains(it.s) }
        if (pf.size >= need) pool = pf
        var n = 0
        while (n < total && (n < 12 || System.currentTimeMillis() - t0 < bot2Ms)) {
            val pp = pool.shuffled(Random.Default)
            val hs = arrayOf<List<Card>>(pp.take(need), h)
            for (i in cand.indices) {
                val c = cand[i]
                var v: Int? = null
                if (small) v = exact2(hs, c)
                if (v == null) v = roll2(hs, 1, c)
                sc3[i] += v - 0.1 * (c.r / 14.0 + (if (c.s == T) 0.3 else 0.0))
            }
            n++
        }
        var bi = 0
        for (i in sc3.indices) if (sc3[i] > sc3[bi]) bi = i
        return cand[bi]
    }
}
