package com.example.hokm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Plays the background music as a foreground service (type mediaPlayback), so Android keeps it
 * running when the screen is locked. The page (index.html) only tells it "on/off" and the volume.
 */
public class MusicService extends Service {
    private static final String CHANNEL = "hokm_music_quiet";
    private static final int NOTIF_ID = 41;
    private static final String[] TRACKS = {"bidad", "kordy", "santur", "ayene", "tamanna", "feragh", "dargham"};

    // wanted state; lives in statics so that it survives while the service is (re)starting
    private static volatile MusicService inst;
    private static volatile boolean enabled = false;   // music switch of the game is on
    private static volatile boolean held = false;      // player left the game screen (not a lock) -> paused
    private static volatile float volume = 0.5f;

    // ---------- called from MainActivity ----------
    static void apply(Context ctx, boolean on, float vol) {
        volume = Math.max(0f, Math.min(1f, vol));
        enabled = on;
        MusicService s = inst;
        if (s != null) {
            s.handler.post(s::refresh);
        } else if (on) {
            try {
                Intent i = new Intent(ctx, MusicService.class);
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
                else ctx.startService(i);
            } catch (Exception ignored) {
                // not allowed to start from the background; the next call from the foreground will do it
            }
        }
    }

    static void hold(boolean h) {
        held = h;
        final MusicService s = inst;
        if (s != null) {
            s.handler.post(() -> {
                if (!held) s.permLoss = false; // back in the game: take the audio back from whoever had it
                s.refresh();
            });
        }
    }

    static void stopNow() {
        enabled = false;
        MusicService s = inst;
        if (s != null) s.handler.post(s::refresh);
    }

    // ---------- service ----------
    private Handler handler;
    private AudioManager am;
    private NotificationManager nm;
    private MediaPlayer mp;
    private AudioFocusRequest focusReq;
    private boolean hasFocus = false;
    private boolean transientLoss = false;
    private boolean permLoss = false;
    private boolean ducked = false;
    private int lastNotifState = -1;
    private int errorsInRow = 0;
    private boolean dead = false;
    private final List<String> queue = new ArrayList<>();
    private String lastTrack = "";

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        handler = new Handler(Looper.getMainLooper());
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "موسیقی بازی", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            nm.createNotificationChannel(ch);
        }
        startFg();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startFg(); // every startForegroundService() call must be answered with startForeground()
        refresh();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        enabled = false;
        finish();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        if (inst == this) inst = null;
        handler.removeCallbacksAndMessages(null);
        destroyPlayer();
        abandonFocus();
        super.onDestroy();
    }

    // ---------- notification ----------
    private void startFg() {
        try {
            Notification n = buildNotification(isPlaying());
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            // the system refused to make us a foreground service
            enabled = false;
            stopSelf();
        }
    }

    private Notification buildNotification(boolean playing) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        if (open != null) b.setContentIntent(PendingIntent.getActivity(this, 0, open, fl));
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("حکم")
            .setContentText(playing ? "موسیقی در حال پخش است" : "موسیقی تا بازگشت به بازی متوقف است")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_SECRET);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void updateNotification(boolean playing) {
        int st = playing ? 1 : 0;
        if (st == lastNotifState) return;
        lastNotifState = st;
        try { nm.notify(NOTIF_ID, buildNotification(playing)); } catch (Exception ignored) { }
    }

    // ---------- playback ----------
    private boolean shouldPlay() {
        return enabled && !held && !transientLoss && !permLoss;
    }

    private boolean isPlaying() {
        try { return mp != null && mp.isPlaying(); } catch (Exception e) { return false; }
    }

    private void refresh() {
        if (dead) return;
        if (!enabled) { finish(); return; }
        try {
            if (shouldPlay()) {
                if (mp == null && !loadNext()) { finish(); return; }
                if (!mp.isPlaying()) {
                    requestFocus();
                    mp.start();
                }
                applyVolume();
            } else {
                if (mp != null && mp.isPlaying()) mp.pause();
                if (held || permLoss) abandonFocus();
            }
            updateNotification(isPlaying());
        } catch (Exception e) {
            // the player got into a bad state: drop it, the next refresh builds a new one
            destroyPlayer();
            lastNotifState = -1;
            handler.postDelayed(this::refresh, 500);
        }
    }

    private void applyVolume() {
        if (mp == null) return;
        float v = volume * (ducked ? 0.25f : 1f);
        try { mp.setVolume(v, v); } catch (Exception ignored) { }
    }

    private String nextTrack() {
        if (queue.isEmpty()) {
            Collections.addAll(queue, TRACKS);
            Collections.shuffle(queue);
            if (queue.size() > 1 && queue.get(0).equals(lastTrack)) queue.add(queue.remove(0));
        }
        lastTrack = queue.remove(0);
        return lastTrack;
    }

    /** Prepares the next track that can be opened. A fresh MediaPlayer per track keeps its state simple. */
    private boolean loadNext() {
        for (int tries = 0; tries < TRACKS.length; tries++) {
            destroyPlayer();
            String name = nextTrack();
            MediaPlayer p = new MediaPlayer();
            try {
                p.setAudioAttributes(attrs());
                p.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK); // keep the CPU awake while the screen is off
                AssetFileDescriptor afd = getAssets().openFd("sounds/" + name + ".mp3");
                try {
                    p.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                } finally {
                    afd.close();
                }
                p.setOnCompletionListener(m -> { errorsInRow = 0; handler.post(this::trackEnded); });
                p.setOnErrorListener((m, what, extra) -> {
                    errorsInRow++; // give up after a few failures in a row instead of spinning
                    handler.post(this::trackEnded);
                    return true;
                });
                p.prepare();
                mp = p;
                applyVolume();
                return true;
            } catch (Exception e) {
                try { p.release(); } catch (Exception ignored) { }
            }
        }
        return false;
    }

    private void trackEnded() {
        if (dead || !enabled) return;
        if (errorsInRow > 4 || !loadNext()) { finish(); return; }
        refresh();
    }

    private void destroyPlayer() {
        MediaPlayer p = mp;
        mp = null;
        if (p != null) {
            try { p.setOnCompletionListener(null); p.setOnErrorListener(null); } catch (Exception ignored) { }
            try { p.release(); } catch (Exception ignored) { }
        }
    }

    private void finish() {
        dead = true;
        if (inst == this) inst = null; // a new start request must create a fresh service
        destroyPlayer();
        abandonFocus();
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    // ---------- audio focus (phone calls, other players) ----------
    private AudioAttributes attrs() {
        return new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
    }

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        switch (change) {
            case AudioManager.AUDIOFOCUS_GAIN:
                transientLoss = false;
                ducked = false;
                refresh();
                applyVolume();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                transientLoss = true;
                refresh();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                ducked = true;
                applyVolume();
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                permLoss = true; // another music app took over; we come back when the player returns to the game
                refresh();
                break;
            default:
                break;
        }
    };

    private void requestFocus() {
        if (hasFocus || am == null) return;
        int r;
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusReq == null) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs())
                    .setOnAudioFocusChangeListener(focusListener, handler)
                    .build();
            }
            r = am.requestAudioFocus(focusReq);
        } else {
            r = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        hasFocus = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED; // if refused we still play, like a normal game
    }

    private void abandonFocus() {
        if (am == null || !hasFocus) return;
        hasFocus = false;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusReq != null) am.abandonAudioFocusRequest(focusReq);
            } else {
                am.abandonAudioFocus(focusListener);
            }
        } catch (Exception ignored) { }
    }
}
