package com.example.hokm

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Google Nearby Connections (Bluetooth / Wi-Fi chosen by Google) behind the [Link] interface.
 * Permissions, Bluetooth and location must already be switched on by the caller.
 */
class NearbyLink(ctx: Context, private val emit: LinkEmit) : Link {

    companion object {
        private const val SERVICE_ID = "com.example.hokm.v1"
        private const val CHUNK = 20000
    }

    private val cc: ConnectionsClient = Nearby.getConnectionsClient(ctx)
    private val lock = Any()
    private val epToId = HashMap<String, Int>()
    private val idToEp = HashMap<Int, String>()
    private val pendingNames = HashMap<String, String>()
    private val partial = HashMap<String, StringBuilder>()
    private val writer: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile private var hosting = false
    @Volatile private var scanning = false
    @Volatile private var discovering = false
    @Volatile private var closed = false
    @Volatile private var wantRoom: String? = null
    @Volatile private var maxClients = 4
    @Volatile private var myName = "بازیکن"
    private var nextId = 1

    init {
        val hb = Thread {
            while (!closed) {
                try { Thread.sleep(3000) } catch (ie: InterruptedException) { return@Thread }
                val ids: List<Int> = synchronized(lock) { idToEp.keys.toList() }
                for (k in ids) queueSend(k, "")
            }
        }
        hb.isDaemon = true
        hb.start()
    }

    // ------------------------------------------------------------ helpers

    private fun liveCount(): Int = synchronized(lock) { epToId.size }

    private fun bind(id: Int, ep: String) {
        synchronized(lock) {
            epToId[ep] = id
            idToEp[id] = ep
        }
    }

    private fun closeConn(id: Int, notify: Boolean) {
        val ep: String?
        synchronized(lock) {
            ep = idToEp.remove(id)
            if (ep != null) {
                epToId.remove(ep)
                partial.remove(ep)
            }
        }
        if (ep != null) {
            try { cc.disconnectFromEndpoint(ep) } catch (e: Exception) { }
            if (notify) emit("drop", id, "")
        }
    }

    private fun stopDiscoveryIfIdle() {
        if (!scanning && wantRoom == null && discovering) {
            discovering = false
            try { cc.stopDiscovery() } catch (e: Exception) { }
        }
    }

    private fun queueSend(id: Int, msg: String) {
        if (closed) return
        try {
            writer.execute {
                val ep: String? = synchronized(lock) { idToEp[id] }
                if (ep != null) {
                    try {
                        if (msg.length <= CHUNK) {
                            cc.sendPayload(ep, Payload.fromBytes((msg + "\n").toByteArray(Charsets.UTF_8)))
                        } else {
                            val parts = ArrayList<String>()
                            var i = 0
                            while (i < msg.length) {
                                var e = minOf(msg.length, i + CHUNK)
                                if (e < msg.length && Character.isHighSurrogate(msg[e - 1])) e--
                                parts.add(msg.substring(i, e))
                                i = e
                            }
                            for (k in parts.indices) {
                                val f = "\u0002" + k + "," + parts.size + "," + parts[k]
                                cc.sendPayload(ep, Payload.fromBytes(f.toByteArray(Charsets.UTF_8)))
                            }
                        }
                    } catch (e: Exception) {
                        closeConn(id, true)
                    }
                }
            }
        } catch (e: Exception) {
            // writer already shut down
        }
    }

    // ------------------------------------------------------------ callbacks

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(ep: String, p: Payload) {
            val b = p.asBytes() ?: return
            val id: Int = synchronized(lock) { epToId[ep] } ?: return
            var s = String(b, Charsets.UTF_8)
            if (s.isNotEmpty() && s[0] == '\u0002') {
                val c1 = s.indexOf(',')
                val c2 = if (c1 < 0) -1 else s.indexOf(',', c1 + 1)
                if (c1 < 0 || c2 < 0) return
                try {
                    val idx = s.substring(1, c1).toInt()
                    val tot = s.substring(c1 + 1, c2).toInt()
                    val sb: StringBuilder
                    synchronized(lock) {
                        var cur = partial[ep]
                        if (idx == 0 || cur == null) {
                            cur = StringBuilder()
                            partial[ep] = cur
                        }
                        cur.append(s.substring(c2 + 1))
                        if (idx != tot - 1) return
                        partial.remove(ep)
                        sb = cur
                    }
                    s = sb.toString()
                } catch (e: Exception) {
                    return
                }
            }
            s = s.trim()
            if (s.isNotEmpty()) emit("msg", id, s)
        }

        override fun onPayloadTransferUpdate(ep: String, u: PayloadTransferUpdate) {}
    }

    private val hostCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            if (!hosting || liveCount() >= maxClients) {
                try { cc.rejectConnection(ep) } catch (e: Exception) { }
                return
            }
            synchronized(lock) { pendingNames[ep] = info.endpointName }
            try { cc.acceptConnection(ep, payloadCb) } catch (e: Exception) { }
        }

        override fun onConnectionResult(ep: String, r: ConnectionResolution) {
            val nm: String? = synchronized(lock) { pendingNames.remove(ep) }
            if (!r.status.isSuccess || !hosting) return
            val id: Int = synchronized(lock) { nextId++ }
            bind(id, ep)
            emit("conn", id, (if (nm.isNullOrEmpty()) "بازیکن" else nm) + "\u0001" + ep)
        }

        override fun onDisconnected(ep: String) {
            val id: Int? = synchronized(lock) { epToId[ep] }
            if (id != null) closeConn(id, true)
        }
    }

    private val clientCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            try { cc.acceptConnection(ep, payloadCb) } catch (e: Exception) { }
        }

        override fun onConnectionResult(ep: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                closeConn(0, false)
                bind(0, ep)
                scanning = false
                wantRoom = null
                stopDiscoveryIfIdle()
                emit("open", 0, "")
            } else {
                emit("err", 0, "اتصال برقرار نشد. مطمئن شوید میزبان صفحهٔ میزبانی را باز کرده و بلوتوث و موقعیت‌مکانی هر دو گوشی روشن است.")
            }
        }

        override fun onDisconnected(ep: String) {
            val id: Int? = synchronized(lock) { epToId[ep] }
            if (id != null) closeConn(id, true)
        }
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(ep: String, info: DiscoveredEndpointInfo) {
            val n = info.endpointName
            if (!n.startsWith("HK|")) return
            val pr = n.split("|", limit = 3)
            val room = if (pr.size > 1) pr[1] else ""
            val host = if (pr.size > 2) pr[2] else ""
            if (scanning) emit("found", 0, ep + "\u0001" + room + "\u0001" + host)
            val w = wantRoom
            if (w != null && w == room) {
                wantRoom = null
                requestTo(ep)
                stopDiscoveryIfIdle()
            }
        }

        override fun onEndpointLost(ep: String) {
            if (scanning) emit("lost", 0, ep)
        }
    }

    private fun requestTo(ep: String) {
        try {
            cc.requestConnection(myName, ep, clientCb)
                .addOnFailureListener { e -> emit("err", 0, "درخواست اتصال ناموفق بود. (" + e.message + ")") }
        } catch (e: Exception) {
            emit("err", 0, "درخواست اتصال ناموفق بود. (" + e.message + ")")
        }
    }

    private fun startDiscoveryNow() {
        if (discovering) return
        discovering = true
        try {
            cc.startDiscovery(
                SERVICE_ID, discCb,
                DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
            ).addOnFailureListener { e ->
                discovering = false
                emit("err", 0, "جست‌وجوی بازی‌های نزدیک ممکن نشد. (" + e.message + ")")
            }
        } catch (e: Exception) {
            discovering = false
            emit("err", 0, "جست‌وجوی بازی‌های نزدیک ممکن نشد. (" + e.message + ")")
        }
    }

    // ------------------------------------------------------------ Link

    override fun startHost(maxClients: Int, roomId: String?, name: String?) {
        try { cc.stopAdvertising() } catch (e: Exception) { }
        this.maxClients = maxClients
        hosting = true
        var n = name ?: ""
        if (n.length > 20) n = n.substring(0, 20)
        val adv = "HK|" + (roomId ?: "") + "|" + n
        try {
            cc.startAdvertising(
                adv, SERVICE_ID, hostCb,
                AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
            ).addOnFailureListener { e ->
                if (hosting) emit("err", 0, "باز کردن حالت میزبان ممکن نشد. بلوتوث و موقعیت‌مکانی را روشن کنید و اجازه‌ها را بدهید. (جزئیات فنی: " + e.message + ")")
            }
        } catch (e: Exception) {
            emit("err", 0, "باز کردن حالت میزبان ممکن نشد. (جزئیات فنی: " + e.message + ")")
        }
    }

    override fun stopHost() {
        hosting = false
        try { cc.stopAdvertising() } catch (e: Exception) { }
    }

    override fun startScan() {
        scanning = true
        startDiscoveryNow()
    }

    override fun stopScan() {
        scanning = false
        stopDiscoveryIfIdle()
    }

    /** target = endpoint id from a "found" event, or "room:<id>" to find whoever hosts that room. */
    override fun connect(target: String?, name: String?) {
        myName = if (name.isNullOrEmpty()) "بازیکن" else name
        closeConn(0, false)
        if (target != null && target.startsWith("room:")) {
            val room = target.substring(5)
            wantRoom = room
            startDiscoveryNow()
            Thread {
                try { Thread.sleep(12000) } catch (ie: InterruptedException) { return@Thread }
                if (room == wantRoom) {
                    wantRoom = null
                    stopDiscoveryIfIdle()
                    emit("err", 0, "بازی پیدا نشد. میزبان نزدیک نیست یا بازی را بسته است.")
                }
            }.start()
        } else if (target != null) {
            requestTo(target)
        }
    }

    override fun send(id: Int, msg: String?) {
        if (msg == null) return
        queueSend(id, msg)
    }

    override fun drop(id: Int) {
        // small delay so messages queued before (like "the table is full") are delivered first
        try {
            writer.execute {
                try { Thread.sleep(500) } catch (ie: InterruptedException) { }
                closeConn(id, false)
            }
        } catch (e: Exception) {
        }
    }

    override fun closeAll() {
        hosting = false
        scanning = false
        wantRoom = null
        discovering = false
        try { cc.stopAdvertising() } catch (e: Exception) { }
        try { cc.stopDiscovery() } catch (e: Exception) { }
        try { cc.stopAllEndpoints() } catch (e: Exception) { }
        synchronized(lock) {
            epToId.clear()
            idToEp.clear()
            pendingNames.clear()
            partial.clear()
        }
    }

    override fun shutdown() {
        closed = true
        closeAll()
        writer.shutdown()
    }
}
