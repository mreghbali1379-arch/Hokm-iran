package com.example.hokm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.Collections
import kotlin.random.Random

/**
 * Sound effects (SoundPool) and background music (MediaPlayer) from assets/sounds.
 * Settings (on/off, music volume, effects volume) are kept in SharedPreferences.
 * Effects are queued one after another so that, for example, the "trick" sound never plays on top of the card sound.
 */
class Sound(private val ctx: Context) {

    companion object {
        private val FX = arrayOf("card", "trick", "tlose", "shuffle", "win", "lose", "kwin", "klose", "fwin", "flose")

        // lengths of the effects in milliseconds
        private val DUR = mapOf(
            "card" to 600, "shuffle" to 890, "trick" to 1245, "tlose" to 1650, "win" to 2950, "lose" to 3350,
            "kwin" to 3530, "klose" to 3530, "fwin" to 5045, "flose" to 3400
        )
        private val TRACKS = arrayOf("bidad", "kordy", "santur", "ayene", "tamanna", "feragh", "dargham")
        private const val MB = 1.8f

        // lengths (ms, normal speed) of the long dealing sounds: 4a = 5 cards to each of 4 players,
        // 4b = the other 8 cards each, deal2 = 5 cards to each of 2 players
        private val DEAL_DUR = mapOf("deal4a" to 10650, "deal4b" to 17160, "deal2" to 4370)
    }

    private val prefs = ctx.getSharedPreferences("hokm_sound", Context.MODE_PRIVATE)
    var on: Boolean = prefs.getBoolean("on", true)
        private set
    var volMusic: Float = prefs.getFloat("vm", 0.5f)
        private set
    var volFx: Float = prefs.getFloat("ve", 1f)
        private set

    private val ui = Handler(Looper.getMainLooper())
    private val ids = HashMap<String, Int>()
    private val ready: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private val sp: SoundPool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private var free = 0L
    private var music: MediaPlayer? = null
    private var dealPlayer: MediaPlayer? = null
    private var dealDone: (() -> Unit)? = null
    private var dealToken = 0

    /** Speed of the dealing sounds: 0 = no dealing sound (skip), 1 = normal, 2 = fast, 4 = very fast. */
    var dealSpeed: Float = prefs.getFloat("ds", 2f)
        private set
    private var hold = false
    private var queue = ArrayList<String>()
    private var lastTrack = ""

    init {
        sp.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        for (n in FX) {
            try {
                ctx.assets.openFd("sounds/$n.mp3").use { fd -> ids[n] = sp.load(fd, 1) }
            } catch (e: Exception) {
                // a missing file just means no sound for it
            }
        }
    }

    // ------------------------------------------------------------ effects

    fun card() = sfx("card")

    /** Plays the card sound at once, without waiting for queued effects (for quick sequences). */
    fun cardNow() {
        if (on) fire("card")
    }

    fun sfx(name: String) {
        if (!on) return
        val d = (DUR[name] ?: 500).toLong()
        val now = SystemClock.uptimeMillis()
        val start = maxOf(now, free)
        if (name == "card" && start - now > 1100) return // too far behind: skip this card sound
        free = start + d + 120
        if (start > now) {
            ui.postDelayed({ if (on) fire(name) }, start - now)
        } else {
            fire(name)
        }
    }

    private fun fire(name: String) {
        val id = ids[name] ?: return
        if (!ready.contains(id)) return
        val v = if (name == "card") minOf(1f, (0.5f + Random.nextFloat() * 0.45f) * volFx) else volFx
        try {
            sp.play(id, v, v, 1, 0, 1f)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ dealing

    /** True when [deal] will really play something (sound on and dealing sound not switched off). */
    fun willDeal(): Boolean = on && dealSpeed > 0f

    /**
     * Plays a dealing sound ("deal4a", "deal4b" or "deal2") after the effects queued before it, faster by
     * [dealSpeed] without changing the pitch, then calls [done] on the main thread. [skipDeal] ends it early.
     * [done] is called at once when sound is off.
     */
    fun deal(name: String, done: () -> Unit) {
        if (!willDeal() || (DEAL_DUR[name] == null)) {
            done()
            return
        }
        stopDealQuiet()
        dealDone = done
        val token = ++dealToken
        val len = (DEAL_DUR[name]!! / dealSpeed).toLong()
        val now = SystemClock.uptimeMillis()
        val start = maxOf(now, free)
        free = start + len + 150
        val go = { if (token == dealToken) startDealPlayer(name, token) }
        if (start > now) ui.postDelayed({ go() }, start - now) else go()
    }

    private fun startDealPlayer(name: String, token: Int) {
        try {
            val fd = ctx.assets.openFd("sounds/$name.mp3")
            val mp = MediaPlayer()
            mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            fd.close()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setVolume(volFx, volFx)
            mp.setOnCompletionListener { if (token == dealToken) finishDeal() }
            mp.setOnErrorListener { _, _, _ ->
                if (token == dealToken) finishDeal()
                true
            }
            mp.setOnPreparedListener { p ->
                if (token != dealToken) return@setOnPreparedListener
                try {
                    p.start()
                    if (Build.VERSION.SDK_INT >= 23 && dealSpeed != 1f) {
                        p.playbackParams = PlaybackParams().setSpeed(dealSpeed).setPitch(1f)
                    }
                } catch (e: Exception) {
                    finishDeal()
                }
            }
            dealPlayer = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            finishDeal()
        }
    }

    private fun stopDealQuiet() {
        dealToken++
        val mp = dealPlayer
        dealPlayer = null
        dealDone = null
        if (mp != null) {
            try { mp.release() } catch (e: Exception) { }
        }
    }

    private fun finishDeal() {
        val d = dealDone
        dealToken++
        val mp = dealPlayer
        dealPlayer = null
        dealDone = null
        if (mp != null) {
            try { mp.release() } catch (e: Exception) { }
        }
        d?.invoke()
    }

    /** The player pressed "skip": stop the dealing sound and go on. */
    fun skipDeal() {
        if (dealDone != null) finishDeal()
    }

    fun setDealSpeed(v: Float) {
        dealSpeed = v
        prefs.edit().putFloat("ds", v).apply()
    }

    // ------------------------------------------------------------ music

    // Loudness is felt on a log scale: up to 50% the level follows a square, above 50% it rises in equal dB steps.
    private fun gain(): Float {
        val v = volMusic
        if (v <= 0f) return 0f
        if (v <= 0.5f) return v * v / MB
        val g0 = 0.25f / MB
        return (g0 * Math.pow((1f / g0).toDouble(), ((v - 0.5f) / 0.5f).toDouble())).toFloat()
    }

    private fun nextTrack(): String {
        if (queue.isEmpty()) {
            queue = ArrayList(TRACKS.toList())
            queue.shuffle()
            if (queue.size > 1 && queue[0] == lastTrack) queue.add(queue.removeAt(0))
        }
        lastTrack = queue.removeAt(0)
        return lastTrack
    }

    fun startMusic() {
        if (!on || hold) return
        val m = music
        if (m != null) {
            try {
                if (!m.isPlaying) m.start()
            } catch (e: Exception) {
            }
            return
        }
        playNext()
    }

    private fun releaseMusic() {
        val m = music
        music = null
        if (m != null) {
            try { m.release() } catch (e: Exception) { }
        }
    }

    private fun playNext() {
        releaseMusic()
        try {
            val fd = ctx.assets.openFd("sounds/" + nextTrack() + ".mp3")
            val mp = MediaPlayer()
            mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            fd.close()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            val g = gain()
            mp.setVolume(g, g)
            mp.setOnCompletionListener { playNext() }
            mp.setOnPreparedListener { p -> if (music === p && on && !hold) p.start() }
            mp.setOnErrorListener { _, _, _ ->
                releaseMusic()
                true
            }
            music = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            music = null
        }
    }

    /** The screen went to the background (true) or came back (false). */
    fun hold(b: Boolean) {
        hold = b
        if (b) {
            try { music?.pause() } catch (e: Exception) { }
        } else {
            startMusic()
        }
    }

    // ------------------------------------------------------------ settings

    fun setOn(b: Boolean) {
        on = b
        prefs.edit().putBoolean("on", b).apply()
        if (b) {
            startMusic()
        } else {
            try { music?.pause() } catch (e: Exception) { }
        }
    }

    fun setMusicVolume(v: Float) {
        volMusic = v.coerceIn(0f, 1f)
        prefs.edit().putFloat("vm", volMusic).apply()
        val g = gain()
        try { music?.setVolume(g, g) } catch (e: Exception) { }
    }

    fun setFxVolume(v: Float) {
        volFx = v.coerceIn(0f, 1f)
        prefs.edit().putFloat("ve", volFx).apply()
    }

    fun release() {
        stopDealQuiet()
        ui.removeCallbacksAndMessages(null)
        releaseMusic()
        try { sp.release() } catch (e: Exception) { }
    }
}
