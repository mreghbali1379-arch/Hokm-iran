package com.example.hokm.engine

import kotlin.random.Random

/** One card dealt face up during the draw: [p] is the player who receives it. */
class DrawStep(val p: Int, val c: Card)

/**
 * The draw that decides the first hakem: cards are dealt one at a time, starting with a random player; whoever gets
 * the first ace is the hakem. In a four-player game the next ace that goes to a different player is the hakem's
 * partner, and the seats are then rearranged so that the partner sits opposite the hakem ([mv]).
 *
 * Players are numbered 0..n-1 with 0 = you (before any rearranging).
 */
class HakemDraw(
    val n: Int,
    val seq: List<DrawStep>,
    /** the hakem */
    val h: Int,
    /** the hakem's partner (four players only, else -1) */
    val pt: Int,
    /** index in [seq] of the first ace / of the partner's ace (-1 for two players) */
    val i1: Int,
    val i2: Int,
    /** mv[o] = the seat player o sits in after the draw (four players only) */
    val mv: IntArray
) {
    val seatsChange: Boolean get() = n == 4 && mv.indices.any { mv[it] != it }

    companion object {
        private val PERMS = listOf(
            intArrayOf(1, 2, 3), intArrayOf(1, 3, 2), intArrayOf(2, 1, 3),
            intArrayOf(2, 3, 1), intArrayOf(3, 1, 2), intArrayOf(3, 2, 1)
        )

        /** Fewest seat moves that put partner [a] opposite hakem [h] (player 0 stays where he is). */
        fun reseatPlan(h: Int, a: Int, rnd: Random = Random.Default): IntArray {
            if ((h + 2) % 4 == a) return intArrayOf(0, 1, 2, 3)
            var best = intArrayOf(0, 1, 2, 3)
            var bc = 9
            for (q in PERMS) {
                val to = intArrayOf(0, q[0], q[1], q[2])
                if ((to[h] + 2) % 4 == to[a]) {
                    var c = 0
                    for (o in 0 until 4) if (to[o] != o) c++
                    if (c < bc || (c == bc && rnd.nextBoolean())) {
                        bc = c
                        best = to
                    }
                }
            }
            return best
        }

        fun generate(n: Int, rnd: Random = Random.Default): HakemDraw {
            for (tr in 0 until 200) {
                val d = Deck.all()
                d.shuffle(rnd)
                val st = rnd.nextInt(n)
                val ia = ArrayList<Int>()
                for (i in d.indices) if (d[i].r == 14) ia.add(i)
                val h = (st + ia[0]) % n
                var k2 = -1
                if (n == 4) {
                    for (k in 1 until ia.size) {
                        if ((st + ia[k]) % n != h) {
                            k2 = k
                            break
                        }
                    }
                    if (k2 < 0) continue
                }
                val end = if (n == 2) ia[0] else ia[k2]
                val seq = ArrayList<DrawStep>()
                for (i in 0..end) seq.add(DrawStep((st + i) % n, d[i]))
                val pt = if (n == 4) (st + ia[k2]) % n else -1
                return HakemDraw(
                    n, seq, h, pt, ia[0], if (n == 4) ia[k2] else -1,
                    if (n == 4) reseatPlan(h, pt, rnd) else intArrayOf(0, 1)
                )
            }
            val seq = ArrayList<DrawStep>()
            seq.add(DrawStep(0, Card(0, 14)))
            if (n == 4) seq.add(DrawStep(1, Card(1, 14)))
            return HakemDraw(
                n, seq, 0, if (n == 4) 1 else -1, 0, if (n == 4) 1 else -1,
                if (n == 4) reseatPlan(0, 1, rnd) else intArrayOf(0, 1)
            )
        }
    }
}
