package com.example.hokm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The game itself runs in index.html (WebView). This class is only the "pipe" between phones.
 * It uses Google Nearby Connections, so phones find each other and connect without
 * manual Bluetooth pairing. The JS side (window.AndroidBT) keeps the same small API:
 * host / discover / connect / send / drop / close, and receives events through window.btEvt.
 *
 * Connection ids: on the host side every guest gets an id 1,2,3...; on a guest phone the host is id 0.
 */
public class MainActivity extends Activity {
    private static final String SERVICE_ID = "com.example.hokm.room";
    private static final int REQ_PERM = 7;
    private static final int MAX_BYTES = 30000;

    private WebView web;
    private BluetoothAdapter adapter;
    private ConnectionsClient nc;
    private final Object lock = new Object();
    private final Map<Integer, String> idToEp = new HashMap<>();
    private final Map<String, Integer> epToId = new HashMap<>();
    private final Map<String, String> epNames = new HashMap<>();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private volatile boolean hosting = false;
    private volatile int hostMax = 4;
    private int nextId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;
        try {
            nc = Nearby.getConnectionsClient(this);
        } catch (Throwable t) {
            nc = null;
        }

        web = new WebView(this);
        web.setBackgroundColor(0xFF1F6B47);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(msg)
                    .setPositiveButton("بله", (d, w) -> r.confirm())
                    .setNegativeButton("خیر", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel())
                    .show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBT");
        setContentView(web);
        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    // The phone's back button goes one step back inside the game (see hokmBack in index.html).
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){try{return window.hokmBack?window.hokmBack():false}catch(e){return false}})()",
            value -> {
                if (!"true".equals(value)) {
                    finish();
                }
            });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeAll();
        writer.shutdown();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_PERM) {
            ev("perm", 0, hasPerm() ? "1" : "0");
        }
    }

    // ---------- permissions ----------
    private List<String> neededPerms() {
        List<String> l = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            l.add(Manifest.permission.BLUETOOTH_CONNECT);
            l.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        if (Build.VERSION.SDK_INT <= 32) {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        return l;
    }

    private boolean hasPerm() {
        for (String p : neededPerms()) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        }
        return true;
    }

    private boolean locationOn() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return true;
            if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            return true;
        }
    }

    // ---------- helpers ----------
    private void ev(String type, int cid, String data) {
        final String js = "window.btEvt&&window.btEvt(" + JSONObject.quote(type) + "," + cid + ","
            + JSONObject.quote(data == null ? "" : data) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private int liveCount() {
        synchronized (lock) { return idToEp.size(); }
    }

    private void closeConn(int id, boolean notify) {
        String ep;
        synchronized (lock) {
            ep = idToEp.remove(id);
            if (ep != null) {
                epToId.remove(ep);
                epNames.remove(ep);
            }
        }
        if (ep != null) {
            try { if (nc != null) nc.disconnectFromEndpoint(ep); } catch (Exception e) { }
            if (notify) ev("drop", id, "");
        }
    }

    private void closeAll() {
        hosting = false;
        if (nc != null) {
            try { nc.stopAdvertising(); } catch (Exception e) { }
            try { nc.stopDiscovery(); } catch (Exception e) { }
            try { nc.stopAllEndpoints(); } catch (Exception e) { }
        }
        synchronized (lock) {
            idToEp.clear();
            epToId.clear();
            epNames.clear();
        }
    }

    // ---------- Nearby callbacks ----------
    private final PayloadCallback payloadCb = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String ep, Payload p) {
            byte[] b = p.asBytes();
            if (b == null || b.length == 0) return;
            Integer id;
            synchronized (lock) { id = epToId.get(ep); }
            if (id == null) return;
            ev("msg", id, new String(b, StandardCharsets.UTF_8));
        }

        @Override
        public void onPayloadTransferUpdate(String ep, PayloadTransferUpdate u) { }
    };

    private final ConnectionLifecycleCallback connCb = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String ep, ConnectionInfo info) {
            boolean incoming = info.isIncomingConnection();
            Integer stale = null;
            int id;
            if (incoming) {
                if (!hosting || liveCount() >= hostMax) {
                    try { nc.rejectConnection(ep); } catch (Exception e) { }
                    return;
                }
                synchronized (lock) {
                    stale = epToId.get(ep);
                    if (stale != null) { idToEp.remove(stale); epToId.remove(ep); }
                    id = nextId++;
                    idToEp.put(id, ep);
                    epToId.put(ep, id);
                    epNames.put(ep, info.getEndpointName());
                }
                if (stale != null) ev("drop", stale, "");
            } else {
                synchronized (lock) {
                    String old = idToEp.get(0);
                    if (old != null) epToId.remove(old);
                    idToEp.put(0, ep);
                    epToId.put(ep, 0);
                    epNames.put(ep, info.getEndpointName());
                }
            }
            try { nc.acceptConnection(ep, payloadCb); } catch (Exception e) { }
        }

        @Override
        public void onConnectionResult(String ep, ConnectionResolution r) {
            Integer id;
            String nm;
            synchronized (lock) { id = epToId.get(ep); nm = epNames.get(ep); }
            if (id == null) return;
            if (r.getStatus().isSuccess()) {
                if (id == 0) ev("open", 0, "");
                else ev("conn", id, nm == null || nm.isEmpty() ? "بازیکن" : nm);
            } else {
                synchronized (lock) {
                    idToEp.remove(id);
                    epToId.remove(ep);
                    epNames.remove(ep);
                }
                if (id == 0) {
                    ev("err", 0, "اتصال به میزبان برقرار نشد. (کد " + r.getStatus().getStatusCode() + ")");
                }
            }
        }

        @Override
        public void onDisconnected(String ep) {
            Integer id;
            synchronized (lock) {
                id = epToId.remove(ep);
                if (id != null) idToEp.remove(id);
                epNames.remove(ep);
            }
            if (id != null) ev("drop", id, "");
        }
    };

    private final EndpointDiscoveryCallback discCb = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String ep, DiscoveredEndpointInfo info) {
            ev("found", 0, ep + "\n" + info.getEndpointName());
        }

        @Override
        public void onEndpointLost(String ep) {
            ev("lost", 0, ep);
        }
    };

    // ---------- JS bridge ----------
    private class Bridge {
        @JavascriptInterface
        public String state() {
            if (nc == null) return "nogms";
            try {
                if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MainActivity.this)
                    != ConnectionResult.SUCCESS) return "nogms";
            } catch (Throwable t) {
                return "nogms";
            }
            if (!hasPerm()) return "noperm";
            if (adapter != null && !adapter.isEnabled()) return "off";
            if (Build.VERSION.SDK_INT <= 30 && !locationOn()) return "noloc";
            return "ok";
        }

        @JavascriptInterface
        public void ensure() {
            if (hasPerm()) {
                ev("perm", 0, "1");
                return;
            }
            final List<String> missing = new ArrayList<>();
            for (String p : neededPerms()) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
            }
            runOnUiThread(() -> requestPermissions(missing.toArray(new String[0]), REQ_PERM));
        }

        @JavascriptInterface
        public String myName() {
            try {
                String n = adapter != null ? adapter.getName() : null;
                return n == null ? "" : n;
            } catch (Exception e) {
                return "";
            }
        }

        /** Start advertising this phone as a game room. advName = "room|epoch|hostName". */
        @JavascriptInterface
        public void host(final int max, final String advName) {
            if (nc == null) return;
            hostMax = max;
            hosting = true;
            try { nc.stopAdvertising(); } catch (Exception e) { }
            AdvertisingOptions o = new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build();
            nc.startAdvertising(advName, SERVICE_ID, connCb, o)
                .addOnFailureListener(e -> {
                    if (hosting) ev("err", 0, "باز کردن حالت میزبان ممکن نشد. بلوتوث و Wi-Fi را روشن کنید و مجوزها را بدهید. (جزئیات فنی: " + e.getMessage() + ")");
                });
        }

        @JavascriptInterface
        public void stopHost() {
            hosting = false;
            if (nc != null) {
                try { nc.stopAdvertising(); } catch (Exception e) { }
            }
        }

        @JavascriptInterface
        public void discover() {
            if (nc == null) return;
            try { nc.stopDiscovery(); } catch (Exception e) { }
            DiscoveryOptions o = new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build();
            nc.startDiscovery(SERVICE_ID, discCb, o)
                .addOnFailureListener(e -> ev("err", 0, "جستجوی بازی‌های اطراف ممکن نشد. بلوتوث را روشن کنید و مجوزها (و در اندروید قدیمی‌تر، مکان) را بدهید. (جزئیات فنی: " + e.getMessage() + ")"));
        }

        @JavascriptInterface
        public void stopDiscover() {
            if (nc != null) {
                try { nc.stopDiscovery(); } catch (Exception e) { }
            }
        }

        @JavascriptInterface
        public void connect(final String ep, final String myName) {
            if (nc == null) return;
            closeConn(0, false);
            nc.requestConnection(myName == null || myName.isEmpty() ? "بازیکن" : myName, ep, connCb)
                .addOnFailureListener(e -> {
                    synchronized (lock) {
                        String old = idToEp.get(0);
                        if (ep.equals(old)) { idToEp.remove(0); epToId.remove(old); }
                    }
                    ev("err", 0, "اتصال به میزبان برقرار نشد. (جزئیات فنی: " + e.getMessage() + ")");
                });
        }

        @JavascriptInterface
        public void send(final int id, final String msg) {
            final byte[] b = msg.getBytes(StandardCharsets.UTF_8);
            if (b.length > MAX_BYTES) {
                ev("err", 0, "پیام بازی بیش از حد بزرگ بود.");
                return;
            }
            writer.submit(() -> {
                String ep;
                synchronized (lock) { ep = idToEp.get(id); }
                if (ep == null || nc == null) return;
                try {
                    nc.sendPayload(ep, Payload.fromBytes(b));
                } catch (Exception e) {
                    closeConn(id, true);
                }
            });
        }

        @JavascriptInterface
        public void drop(final int id) {
            writer.submit(() -> closeConn(id, false));
        }

        @JavascriptInterface
        public void close() {
            closeAll();
        }
    }
}
