package com.example.hokm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.Priority;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    // Transport: Google Nearby Connections (no Bluetooth pairing needed).
    private static final String SERVICE_ID = "com.example.hokm.v1";
    private static final int REQ_BT = 7;
    private static final int REQ_LOC = 8;
    private static final int REQ_BTON = 9;
    private final List<Runnable> afterLocation = new ArrayList<>();
    private static final int CHUNK = 20000;

    private WebView web;
    private BluetoothAdapter adapter;
    private ConnectionsClient cc;
    private final Object lock = new Object();
    private final Map<String, Integer> epToId = new HashMap<>();
    private final Map<Integer, String> idToEp = new HashMap<>();
    private final Map<String, String> pendingNames = new HashMap<>();
    private final Map<String, StringBuilder> partial = new HashMap<>();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private volatile boolean hosting = false;
    private volatile boolean scanning = false;
    private volatile boolean discovering = false;
    private volatile String wantRoom = null;
    private volatile int maxClients = 4;
    private volatile boolean alive = true;
    private int nextId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;
        cc = Nearby.getConnectionsClient(this);

        web = new WebView(this);
        web.setBackgroundColor(0xFF1F6B47);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(msg)
                    .setPositiveButton("بله", (d, w) -> r.confirm())
                    .setNegativeButton("خیر", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel())
                    .show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBT");
        setContentView(web);
        startHeartbeat();
        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    // The phone's back button goes one step back inside the game (see hokmBack in index.html).
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){try{return window.hokmBack?window.hokmBack():false}catch(e){return false}})()",
            value -> {
                if (!"true".equals(value)) {
                    finish();
                }
            });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.evaluateJavascript("window.musicHold&&window.musicHold(true)", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.evaluateJavascript("window.musicHold&&window.musicHold(false)", null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        closeAll();
        synchronized (this) { if (link != null) { link.shutdown(); link = null; } }
        writer.shutdown();
    }

    // Shows the system "turn on location?" dialog (one tap) when location is off, then runs r.
    private void withLocationOn(final Runnable r) {
        runOnUiThread(() -> {
            if (!afterLocation.isEmpty()) { afterLocation.add(r); return; }
            try {
                LocationRequest lr = new LocationRequest.Builder(Priority.PRIORITY_LOW_POWER, 10000).build();
                LocationSettingsRequest req = new LocationSettingsRequest.Builder().addLocationRequest(lr).build();
                LocationServices.getSettingsClient(this).checkLocationSettings(req)
                    .addOnSuccessListener(x -> r.run())
                    .addOnFailureListener(e -> {
                        if (e instanceof ResolvableApiException) {
                            afterLocation.add(r);
                            try {
                                ((ResolvableApiException) e).startResolutionForResult(MainActivity.this, REQ_LOC);
                            } catch (Exception ex) {
                                afterLocation.clear();
                                r.run();
                            }
                        } else {
                            r.run();
                        }
                    });
            } catch (Throwable t) {
                r.run();
            }
        });
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_BTON) {
            ev("perm", 0, result == Activity.RESULT_OK ? "1" : "0");
        }
        if (code == REQ_LOC) {
            List<Runnable> todo = new ArrayList<>(afterLocation);
            afterLocation.clear();
            for (Runnable t : todo) t.run();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_BT) {
            ev("perm", 0, hasPerm() ? "1" : "0");
        }
    }

    // ---------- helpers ----------
    private String[] neededPerms() {
        List<String> l = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            l.add(Manifest.permission.BLUETOOTH_CONNECT);
            l.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        // Nearby Connections needs location permission on every Android version
        l.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        l.add(Manifest.permission.ACCESS_FINE_LOCATION);
        return l.toArray(new String[0]);
    }

    private boolean hasPerm() {
        for (String p : neededPerms()) {
            boolean isLoc = p.equals(Manifest.permission.ACCESS_COARSE_LOCATION)
                || p.equals(Manifest.permission.ACCESS_FINE_LOCATION);
            if (isLoc) continue; // location is checked below: either one is enough
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void ev(String type, int cid, String data) {
        final String js = "window.btEvt&&window.btEvt(" + JSONObject.quote(type) + "," + cid + ","
            + JSONObject.quote(data == null ? "" : data) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private String localName() {
        try {
            String n = adapter != null ? adapter.getName() : null;
            if (n != null && !n.isEmpty()) return n;
        } catch (Exception e) { }
        return "بازیکن";
    }

    private int liveCount() {
        synchronized (lock) { return epToId.size(); }
    }

    private void bind(int id, String ep) {
        synchronized (lock) {
            epToId.put(ep, id);
            idToEp.put(id, ep);
        }
    }

    private void closeConn(int id, boolean notify) {
        String ep;
        synchronized (lock) {
            ep = idToEp.remove(id);
            if (ep != null) {
                epToId.remove(ep);
                partial.remove(ep);
            }
        }
        if (ep != null) {
            try { cc.disconnectFromEndpoint(ep); } catch (Exception e) { }
            if (notify) ev("drop", id, "");
        }
    }

    private void stopDiscoveryIfIdle() {
        if (!scanning && wantRoom == null && discovering) {
            discovering = false;
            try { cc.stopDiscovery(); } catch (Exception e) { }
        }
    }

    private void closeAll() {
        synchronized (this) { if (link != null) link.closeAll(); }
        hosting = false;
        scanning = false;
        wantRoom = null;
        discovering = false;
        try { cc.stopAdvertising(); } catch (Exception e) { }
        try { cc.stopDiscovery(); } catch (Exception e) { }
        try { cc.stopAllEndpoints(); } catch (Exception e) { }
        synchronized (lock) {
            epToId.clear();
            idToEp.clear();
            pendingNames.clear();
            partial.clear();
        }
    }

    private void queueSend(final int id, final String msg) {
        writer.submit(() -> {
            String ep;
            synchronized (lock) { ep = idToEp.get(id); }
            if (ep == null) return;
            try {
                if (msg.length() <= CHUNK) {
                    cc.sendPayload(ep, Payload.fromBytes((msg + "\n").getBytes(StandardCharsets.UTF_8)));
                } else {
                    List<String> parts = new ArrayList<>();
                    int i = 0;
                    while (i < msg.length()) {
                        int e = Math.min(msg.length(), i + CHUNK);
                        if (e < msg.length() && Character.isHighSurrogate(msg.charAt(e - 1))) e--;
                        parts.add(msg.substring(i, e));
                        i = e;
                    }
                    for (int k = 0; k < parts.size(); k++) {
                        String f = "\u0002" + k + "," + parts.size() + "," + parts.get(k);
                        cc.sendPayload(ep, Payload.fromBytes(f.getBytes(StandardCharsets.UTF_8)));
                    }
                }
            } catch (Exception e) {
                closeConn(id, true);
            }
        });
    }

    // Sends an empty message every few seconds so a lost link is noticed quickly.
    private void startHeartbeat() {
        Thread hb = new Thread(() -> {
            while (alive) {
                try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
                Integer[] ids;
                synchronized (lock) { ids = idToEp.keySet().toArray(new Integer[0]); }
                for (int k : ids) queueSend(k, "");
            }
        });
        hb.setDaemon(true);
        hb.start();
    }

    private final PayloadCallback payloadCb = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String ep, Payload p) {
            byte[] b = p.asBytes();
            if (b == null) return;
            Integer id;
            synchronized (lock) { id = epToId.get(ep); }
            if (id == null) return;
            String s = new String(b, StandardCharsets.UTF_8);
            if (s.length() > 0 && s.charAt(0) == '\u0002') {
                int c1 = s.indexOf(',');
                int c2 = c1 < 0 ? -1 : s.indexOf(',', c1 + 1);
                if (c1 < 0 || c2 < 0) return;
                try {
                    int idx = Integer.parseInt(s.substring(1, c1));
                    int tot = Integer.parseInt(s.substring(c1 + 1, c2));
                    StringBuilder sb;
                    synchronized (lock) {
                        sb = partial.get(ep);
                        if (idx == 0 || sb == null) { sb = new StringBuilder(); partial.put(ep, sb); }
                        sb.append(s.substring(c2 + 1));
                        if (idx != tot - 1) return;
                        partial.remove(ep);
                    }
                    s = sb.toString();
                } catch (Exception e) { return; }
            }
            s = s.trim();
            if (!s.isEmpty()) ev("msg", id, s);
        }

        @Override
        public void onPayloadTransferUpdate(String ep, PayloadTransferUpdate u) { }
    };

    // Host side: players ask to connect to us.
    private final ConnectionLifecycleCallback hostCb = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String ep, ConnectionInfo info) {
            if (!hosting || liveCount() >= maxClients) {
                try { cc.rejectConnection(ep); } catch (Exception e) { }
                return;
            }
            synchronized (lock) { pendingNames.put(ep, info.getEndpointName()); }
            try { cc.acceptConnection(ep, payloadCb); } catch (Exception e) { }
        }

        @Override
        public void onConnectionResult(String ep, ConnectionResolution r) {
            String nm;
            synchronized (lock) { nm = pendingNames.remove(ep); }
            if (!r.getStatus().isSuccess() || !hosting) return;
            int id;
            synchronized (lock) { id = nextId++; }
            bind(id, ep);
            ev("conn", id, (nm == null || nm.isEmpty() ? "بازیکن" : nm) + "\u0001" + ep);
        }

        @Override
        public void onDisconnected(String ep) {
            Integer id;
            synchronized (lock) { id = epToId.get(ep); }
            if (id != null) closeConn(id, true);
        }
    };

    // Client side: we ask a host to connect.
    private final ConnectionLifecycleCallback clientCb = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String ep, ConnectionInfo info) {
            try { cc.acceptConnection(ep, payloadCb); } catch (Exception e) { }
        }

        @Override
        public void onConnectionResult(String ep, ConnectionResolution r) {
            if (r.getStatus().isSuccess()) {
                closeConn(0, false);
                bind(0, ep);
                scanning = false;
                wantRoom = null;
                stopDiscoveryIfIdle();
                ev("open", 0, "");
            } else {
                ev("err", 0, "اتصال برقرار نشد. مطمئن شوید میزبان صفحه‌ی «میزبان بازی می‌شوم» را باز کرده، بلوتوث و موقعیت‌مکانی/وای‌فای هر دو گوشی روشن است و اجازه‌ها داده شده است.");
            }
        }

        @Override
        public void onDisconnected(String ep) {
            Integer id;
            synchronized (lock) { id = epToId.get(ep); }
            if (id != null) closeConn(id, true);
        }
    };

    // "bt" = Nearby Connections (Bluetooth / Wi-Fi chosen by Google), "lan" = same Wi-Fi network, "direct" = Wi-Fi Direct
    private volatile String net = "bt";
    private volatile boolean wifiAsked = false;
    private NetLink link;

    private synchronized NetLink link() {
        if (link == null) link = new NetLink(this, "direct".equals(net), (type, cid, data) -> ev(type, cid, data));
        return link;
    }

    private boolean wifiOn() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            return wm == null || wm.isWifiEnabled();
        } catch (Exception e) {
            return true;
        }
    }

    private boolean viaWifi() {
        return !"bt".equals(net);
    }

    private void requestTo(String ep) {
        try {
            cc.requestConnection(localName(), ep, clientCb)
                .addOnFailureListener(e -> ev("err", 0, "درخواست اتصال ناموفق بود. (" + e.getMessage() + ")"));
        } catch (Exception e) {
            ev("err", 0, "درخواست اتصال ناموفق بود. (" + e.getMessage() + ")");
        }
    }

    private final EndpointDiscoveryCallback discCb = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String ep, DiscoveredEndpointInfo info) {
            String n = info.getEndpointName();
            if (n == null || !n.startsWith("HK|")) return;
            String[] pr = n.split("\\|", 3);
            String room = pr.length > 1 ? pr[1] : "";
            String host = pr.length > 2 ? pr[2] : "";
            if (scanning) ev("found", 0, ep + "\u0001" + room + "\u0001" + host);
            String w = wantRoom;
            if (w != null && w.equals(room)) {
                wantRoom = null;
                requestTo(ep);
                stopDiscoveryIfIdle();
            }
        }

        @Override
        public void onEndpointLost(String ep) {
            if (scanning) ev("lost", 0, ep);
        }
    };

    private void startDiscoveryNow() {
        if (discovering) return;
        withLocationOn(this::startDiscoveryReal);
    }

    private void startDiscoveryReal() {
        if (discovering) return;
        discovering = true;
        try {
            cc.startDiscovery(SERVICE_ID, discCb,
                new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build())
                .addOnFailureListener(e -> {
                    discovering = false;
                    ev("err", 0, "جست‌وجوی بازی‌های نزدیک ممکن نشد. (" + e.getMessage() + ")");
                });
        } catch (Exception e) {
            discovering = false;
            ev("err", 0, "جست‌وجوی بازی‌های نزدیک ممکن نشد. (" + e.getMessage() + ")");
        }
    }

    // ---------- JS bridge ----------
    private class Bridge {
        @JavascriptInterface
        public String state() {
            if (viaWifi()) {
                if (!hasPerm()) return "noperm";
                if (!wifiAsked && !wifiOn()) return "wifioff";
                return "ok";
            }
            if (adapter == null) return "nobt";
            try {
                if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MainActivity.this) != ConnectionResult.SUCCESS) return "nogms";
            } catch (Exception e) {
                return "nogms";
            }
            if (!hasPerm()) return "noperm";
            return adapter.isEnabled() ? "ok" : "off";
        }

        // Shows the system "allow Bluetooth to be turned on?" dialog.
        @JavascriptInterface
        public void enableBt() {
            runOnUiThread(() -> {
                try {
                    startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BTON);
                } catch (Exception e) {
                    ev("err", 0, "روشن کردن خودکار بلوتوث ممکن نشد. آن را از تنظیمات گوشی روشن کنید.");
                }
            });
        }

        @JavascriptInterface
        public void ensure() {
            if (!hasPerm()) {
                runOnUiThread(() -> requestPermissions(neededPerms(), REQ_BT));
            } else {
                ev("perm", 0, "1");
            }
        }

        @JavascriptInterface
        public String myName() {
            try {
                String n = adapter != null ? adapter.getName() : null;
                return n == null ? "" : n;
            } catch (Exception e) {
                return "";
            }
        }

        // Start advertising a game room. room = short id kept for the whole game (even when the host changes).
        @JavascriptInterface
        public void host(final int max, final String room, final String name) {
            if (viaWifi()) { link().startHost(max, room, name); return; }
            try { cc.stopAdvertising(); } catch (Exception e) { }
            maxClients = max;
            hosting = true;
            String n = name == null ? "" : name;
            if (n.length() > 20) n = n.substring(0, 20);
            final String adv = "HK|" + room + "|" + n;
            withLocationOn(() -> {
                try {
                    cc.startAdvertising(adv, SERVICE_ID, hostCb,
                        new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build())
                        .addOnFailureListener(e -> {
                            if (hosting) ev("err", 0, "باز کردن حالت میزبان ممکن نشد. بلوتوث و موقعیت‌مکانی را روشن کنید و اجازه‌ها را بدهید. (جزئیات فنی: " + e.getMessage() + ")");
                        });
                } catch (Exception e) {
                    ev("err", 0, "باز کردن حالت میزبان ممکن نشد. (جزئیات فنی: " + e.getMessage() + ")");
                }
            });
        }

        @JavascriptInterface
        public void stopHost() {
            if (viaWifi()) { link().stopHost(); return; }
            hosting = false;
            try { cc.stopAdvertising(); } catch (Exception e) { }
        }

        // Start listing nearby games ("found" / "lost" events).
        @JavascriptInterface
        public void scan() {
            if (viaWifi()) { link().startScan(); return; }
            scanning = true;
            startDiscoveryNow();
        }

        @JavascriptInterface
        public void stopScan() {
            if (viaWifi()) { link().stopScan(); return; }
            scanning = false;
            stopDiscoveryIfIdle();
        }

        // target = endpoint id from a "found" event, or "room:<id>" to find whoever hosts that room.
        @JavascriptInterface
        public void connect(final String target) {
            if (viaWifi()) { link().connect(target, localName()); return; }
            closeConn(0, false);
            if (target != null && target.startsWith("room:")) {
                final String room = target.substring(5);
                wantRoom = room;
                startDiscoveryNow();
                new Thread(() -> {
                    try { Thread.sleep(12000); } catch (InterruptedException ie) { return; }
                    if (room.equals(wantRoom)) {
                        wantRoom = null;
                        stopDiscoveryIfIdle();
                        ev("err", 0, "بازی پیدا نشد. میزبان نزدیک نیست یا بازی را بسته است.");
                    }
                }).start();
            } else {
                requestTo(target);
            }
        }

        @JavascriptInterface
        public void send(final int id, final String msg) {
            if (viaWifi()) { link().send(id, msg); return; }
            queueSend(id, msg);
        }

        @JavascriptInterface
        public void drop(final int id) {
            if (viaWifi()) { link().drop(id); return; }
            // small delay so messages queued before (like "you were removed") are delivered first
            writer.submit(() -> {
                try { Thread.sleep(500); } catch (InterruptedException ie) { }
                closeConn(id, false);
            });
        }

        // Chooses how games are played: "bt", "lan" or "direct". Only called while no game is open.
        @JavascriptInterface
        public void setNet(String n) {
            String v = "lan".equals(n) || "direct".equals(n) ? n : "bt";
            if (v.equals(net)) return;
            closeAll();
            synchronized (MainActivity.this) {
                if (link != null) { link.shutdown(); link = null; }
            }
            net = v;
            wifiAsked = false;
        }

        // Opens the Wi-Fi panel once so the player can switch Wi-Fi on (it only has to be on, not connected).
        @JavascriptInterface
        public void enableWifi() {
            wifiAsked = true;
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS));
                } catch (Exception e) {
                    ev("err", 0, "روشن کردن وای‌فای ممکن نشد. آن را از تنظیمات گوشی روشن کنید.");
                }
            });
        }

        @JavascriptInterface
        public String version() {
            try {
                PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                long vc = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                return pi.versionName + " (" + vc + ")";
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> { closeAll(); finish(); });
        }

        @JavascriptInterface
        public void close() {
            closeAll();
        }
    }
}
