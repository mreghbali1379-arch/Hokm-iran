package com.example.hokm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final UUID APP_UUID = UUID.fromString("7b3f2c9e-5a1d-4c8b-9e2f-6d0a4b1c8e57");
    private static final int REQ_BT = 7;

    private WebView web;
    private BluetoothAdapter adapter;
    private final Object lock = new Object();
    private final Map<Integer, BluetoothSocket> socks = new HashMap<>();
    private final Map<Integer, OutputStream> outs = new HashMap<>();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private BluetoothServerSocket server;
    private volatile boolean hosting = false;
    private volatile boolean alive = true;
    private int nextId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;

        web = new WebView(this);
        web.setBackgroundColor(0xFF1F6B47);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(msg)
                    .setPositiveButton("بله", (d, w) -> r.confirm())
                    .setNegativeButton("خیر", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel())
                    .show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBT");
        setContentView(web);
        startHeartbeat();
        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    // The phone's back button goes one step back inside the game (see hokmBack in index.html).
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){try{return window.hokmBack?window.hokmBack():false}catch(e){return false}})()",
            value -> {
                if (!"true".equals(value)) {
                    finish();
                }
            });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        closeAll();
        writer.shutdown();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_BT) {
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            ev("perm", 0, ok ? "1" : "0");
        }
    }

    // ---------- helpers ----------
    private boolean hasPerm() {
        if (Build.VERSION.SDK_INT < 31) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void ev(String type, int cid, String data) {
        final String js = "window.btEvt&&window.btEvt(" + JSONObject.quote(type) + "," + cid + ","
            + JSONObject.quote(data == null ? "" : data) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private int liveCount() {
        synchronized (lock) { return socks.size(); }
    }

    private void closeServer() {
        BluetoothServerSocket sv = server;
        server = null;
        if (sv != null) {
            try { sv.close(); } catch (Exception e) { }
        }
    }

    private void closeConn(int id, boolean notify) {
        BluetoothSocket s;
        synchronized (lock) {
            s = socks.remove(id);
            outs.remove(id);
        }
        if (s != null) {
            try { s.close(); } catch (Exception e) { }
            if (notify) ev("drop", id, "");
        }
    }

    private void closeAll() {
        hosting = false;
        closeServer();
        Integer[] ids;
        synchronized (lock) { ids = socks.keySet().toArray(new Integer[0]); }
        for (int id : ids) closeConn(id, false);
    }

    private void attach(final int id, final BluetoothSocket s) throws Exception {
        synchronized (lock) {
            socks.put(id, s);
            outs.put(id, s.getOutputStream());
        }
        Thread t = new Thread(() -> {
            try {
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                String line;
                while ((line = r.readLine()) != null) {
                    if (!line.isEmpty()) ev("msg", id, line);
                }
            } catch (Exception e) {
                // connection lost
            } finally {
                closeConn(id, true);
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void queueSend(final int id, final String msg) {
        writer.submit(() -> {
            OutputStream o;
            synchronized (lock) { o = outs.get(id); }
            if (o == null) return;
            try {
                o.write((msg + "\n").getBytes("UTF-8"));
                o.flush();
            } catch (Exception e) {
                closeConn(id, true);
            }
        });
    }

    // Sends an empty line every few seconds so a lost link is noticed quickly.
    private void startHeartbeat() {
        Thread hb = new Thread(() -> {
            while (alive) {
                try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
                Integer[] ids;
                synchronized (lock) { ids = outs.keySet().toArray(new Integer[0]); }
                for (int k : ids) queueSend(k, "");
            }
        });
        hb.setDaemon(true);
        hb.start();
    }

    // ---------- JS bridge ----------
    private class Bridge {
        @JavascriptInterface
        public String state() {
            if (adapter == null) return "nobt";
            if (!hasPerm()) return "noperm";
            return adapter.isEnabled() ? "ok" : "off";
        }

        @JavascriptInterface
        public void ensure() {
            if (Build.VERSION.SDK_INT >= 31 && !hasPerm()) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT));
            } else {
                ev("perm", 0, "1");
            }
        }

        @JavascriptInterface
        public String myName() {
            try {
                String n = adapter != null ? adapter.getName() : null;
                return n == null ? "" : n;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String paired() {
            JSONArray a = new JSONArray();
            try {
                Set<BluetoothDevice> set = adapter.getBondedDevices();
                for (BluetoothDevice d : set) {
                    JSONObject o = new JSONObject();
                    String n = d.getName();
                    o.put("name", n == null ? d.getAddress() : n);
                    o.put("addr", d.getAddress());
                    a.put(o);
                }
            } catch (Exception e) {
                // no permission or no adapter
            }
            return a.toString();
        }

        @JavascriptInterface
        public void host(final int max) {
            closeServer();
            hosting = true;
            Thread t = new Thread(() -> {
                try {
                    BluetoothServerSocket sv = adapter.listenUsingRfcommWithServiceRecord("Hokm", APP_UUID);
                    server = sv;
                    while (hosting) {
                        BluetoothSocket s = sv.accept();
                        if (liveCount() >= max) {
                            try { s.close(); } catch (Exception e) { }
                            continue;
                        }
                        int id;
                        synchronized (lock) { id = nextId++; }
                        attach(id, s);
                        String nm = null;
                        try { nm = s.getRemoteDevice().getName(); } catch (Exception e) { }
                        ev("conn", id, nm == null ? "بازیکن" : nm);
                    }
                } catch (Exception e) {
                    if (hosting) ev("err", 0, "باز کردن حالت میزبان ممکن نشد. بلوتوث را روشن کنید و اجازه‌ی بلوتوث را به برنامه بدهید. (جزئیات فنی: " + e.getMessage() + ")");
                }
            });
            t.setDaemon(true);
            t.start();
        }

        @JavascriptInterface
        public void stopHost() {
            hosting = false;
            closeServer();
        }

        @JavascriptInterface
        public void connect(final String addr) {
            Thread t = new Thread(() -> {
                String last = "";
                for (int attempt = 1; attempt <= 3; attempt++) {
                    BluetoothSocket sock = null;
                    try {
                        try { adapter.cancelDiscovery(); } catch (Exception ignore) { }
                        BluetoothDevice d = adapter.getRemoteDevice(addr);
                        sock = d.createRfcommSocketToServiceRecord(APP_UUID);
                        sock.connect();
                        closeConn(0, false);
                        attach(0, sock);
                        ev("open", 0, "");
                        return;
                    } catch (Exception e) {
                        last = String.valueOf(e.getMessage());
                        if (sock != null) {
                            try { sock.close(); } catch (Exception ignore2) { }
                        }
                        try { Thread.sleep(800); } catch (InterruptedException ie) { }
                    }
                }
                ev("err", 0, "اتصال برقرار نشد. بررسی کنید: ۱) میزبان صفحه‌ی «میزبان بازی می‌شوم» را باز کرده و منتظر است ۲) بلوتوث هر دو گوشی روشن است ۳) دو گوشی در تنظیمات بلوتوث جفت شده‌اند ۴) هر دو گوشی اجازه‌ی بلوتوث را به برنامه داده‌اند. (جزئیات فنی: " + last + ")");
            });
            t.setDaemon(true);
            t.start();
        }

        @JavascriptInterface
        public void send(final int id, final String msg) {
            queueSend(id, msg);
        }

        @JavascriptInterface
        public void drop(final int id) {
            writer.submit(() -> closeConn(id, false));
        }

        @JavascriptInterface
        public void close() {
            closeAll();
        }
    }
}
