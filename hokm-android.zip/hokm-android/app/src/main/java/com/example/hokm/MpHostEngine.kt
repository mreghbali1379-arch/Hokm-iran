package com.example.hokm

import android.os.Handler
import com.example.hokm.engine.Bot4
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText
import com.example.hokm.engine.Deck
import com.example.hokm.engine.Entry
import com.example.hokm.engine.Game4
import com.example.hokm.engine.HandResult
import com.example.hokm.engine.Phase
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * The table of a multi-phone game. It runs only on the host phone: it owns the four-player game, plays for
 * every seat that has no human (robots), and sends each human a personal view of the game as JSON
 * ("state" messages: only that player's own cards are included, plus a ready-made sentence to read out).
 * Everything here runs on the main thread, except the robots' thinking.
 *
 * Seat 0 is the host. Humans are teams 0/2 vs 1/3 like in the single-player game.
 */
class MpHostEngine(
    private val ui: Handler,
    /** Delivers one JSON message to the human sitting in [seat] (the host's own seat is the host's screen). */
    private val deliver: (seat: Int, json: String) -> Unit,
    /** Called after every change that was sent to the players (the host then refreshes the guests' backup copy). */
    private val changed: () -> Unit = {}
) : TableEngine {
    override val names = arrayOf("", "", "", "")
    override val human = BooleanArray(4)
    override val seats: Int get() = 4

    override var started = false
        private set
    private var over = false
    private var hold = false
    private var thinking = false
    private var gen = 0

    private val g = Game4()
    private val bot = Bot4(g)
    private val pool: ExecutorService = Executors.newSingleThreadExecutor()

    private var table: List<Entry> = emptyList()
    private var tableWin = -1

    // ------------------------------------------------------------------ names and texts

    override fun displayName(seat: Int): String =
        if (human[seat]) (if (names[seat].isEmpty()) "بازیکن" else names[seat]) else "ربات " + CardText.fa(seat)

    private fun who(seat: Int, v: Int): String =
        if (seat == v) "شما" else displayName(seat) + (if (seat % 2 == v % 2) " (یار)" else "")

    private fun sortedHand(v: Int): List<Card> {
        val l = ArrayList(g.hands[v])
        Deck.sortHand(l)
        return l
    }

    private fun handText(v: Int): String = sortedHand(v).joinToString("، ") { CardText.cardName(it) }

    private fun turnText(v: Int): String {
        if (g.phase != Phase.PLAY) return ""
        return if (g.turn == v) {
            " نوبت شماست. " + (if (g.trick.isEmpty()) "شما شروع می‌کنید." else "خال زمین: " + CardText.SUIT_NAMES[g.trick[0].c.s] + ".")
        } else {
            " نوبت " + who(g.turn, v) + "."
        }
    }

    // ------------------------------------------------------------------ messages to the players

    private fun stateFor(v: Int, say: String, sfx: List<String>): JSONObject {
        val o = JSONObject()
        o.put("t", "state")
        o.put("seat", v)
        o.put("phase", g.phase.name)
        o.put("hakem", g.hakem)
        o.put("trump", if (g.phase == Phase.PLAY || g.phase == Phase.END) g.trump else -1)
        o.put("turn", g.turn)
        o.put("sc", JSONArray().put(g.sc[0]).put(g.sc[1]))
        o.put("tk", JSONArray().put(g.tk[0]).put(g.tk[1]))
        val hand = JSONArray()
        for (c in sortedHand(v)) hand.put(c.id)
        o.put("hand", hand)
        val legal = JSONArray()
        if (g.phase == Phase.PLAY && g.turn == v && human[v] && !hold && !over) {
            for (c in g.legal(v)) legal.put(c.id)
        }
        o.put("legal", legal)
        val tb = if (hold) table else g.trick
        o.put("table", entries(tb))
        o.put("tableWin", if (hold) tableWin else -1)
        o.put("last", entries(g.lastTrick))
        o.put("lastWin", g.winSeat)
        val nm = JSONArray()
        for (s in 0 until 4) nm.put(displayName(s))
        o.put("names", nm)
        val hm = JSONArray()
        for (s in 0 until 4) hm.put(human[s])
        o.put("human", hm)
        o.put("canPick", g.phase == Phase.PICK && g.hakem == v && !over)
        o.put("over", over)
        o.put("say", say)
        val sf = JSONArray()
        for (x in sfx) sf.put(x)
        o.put("sfx", sf)
        return o
    }

    private fun entries(l: List<Entry>): JSONArray {
        val a = JSONArray()
        for (e in l) a.put(JSONArray().put(e.seat).put(e.c.id))
        return a
    }

    private fun push(say: (Int) -> String, sfx: (Int) -> List<String> = { emptyList() }) {
        for (v in 0 until 4) {
            if (human[v]) deliver(v, stateFor(v, say(v), sfx(v)).toString())
        }
        changed()
    }

    // ------------------------------------------------------------------ backup for host migration

    /** The whole table as text; guests keep the latest copy so one of them can take over as host. */
    override fun snapshot(): String {
        val o = JSONObject()
        o.put("game", SaveStore.toJson(g))
        o.put("over", over)
        val nm = JSONArray()
        for (n in names) nm.put(n)
        o.put("names", nm)
        val hm = JSONArray()
        for (h in human) hm.put(h)
        o.put("human", hm)
        return o.toString()
    }

    /** Loads a table from [snapshot]; false when it is not valid. Call [resume] afterwards. */
    override fun restore(s: String): Boolean {
        return try {
            val o = JSONObject(s)
            if (!SaveStore.fromJson(g, o.getString("game"))) return false
            val nm = o.getJSONArray("names")
            val hm = o.getJSONArray("human")
            for (i in 0 until 4) {
                names[i] = nm.optString(i)
                human[i] = hm.optBoolean(i)
            }
            over = o.optBoolean("over")
            started = true
            hold = false
            thinking = false
            table = emptyList()
            tableWin = -1
            gen++
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Carries on after [restore]: shows everybody the table and lets robots act. */
    override fun resume(note: String) {
        gen++
        hold = false
        thinking = false
        if (over) {
            push({ _ -> note })
            return
        }
        if (g.phase == Phase.END) {
            push({ _ -> note })
            val my = gen
            ui.postDelayed({ if (my == gen) startHand() }, 4000)
            return
        }
        val hk = g.hakem
        push({ v ->
            note + (if (g.phase == Phase.PICK) {
                if (hk == v) " شما حاکم هستید و باید حکم را انتخاب کنید." else " منتظر انتخاب حکم توسط " + who(hk, v) + " هستیم."
            } else turnText(v))
        })
        drive()
    }

    // ------------------------------------------------------------------ flow

    override fun start() {
        gen++
        over = false
        started = true
        g.newMatch(Random.nextInt(4))
        startHand()
    }

    /** Sends the current view again (a phone that just joined or lost its screen). */
    override fun sync(seat: Int) {
        if (started && human[seat]) deliver(seat, stateFor(seat, "", emptyList()).toString())
    }

    override fun seatJoin(seat: Int, name: String) {
        human[seat] = true
        names[seat] = name
        if (started) {
            val nm = displayName(seat)
            push({ v -> if (v == seat) "به بازی پیوستید." else "$nm به بازی پیوست." })
            drive()
        }
    }

    override fun seatLeave(seat: Int) {
        val nm = displayName(seat)
        human[seat] = false
        names[seat] = ""
        if (started) {
            push({ _ -> "$nm از بازی خارج شد؛ ربات جای او را می‌گیرد." })
            drive()
        }
    }

    override fun stop() {
        gen++
        ui.removeCallbacksAndMessages(null)
        pool.shutdownNow()
    }

    private fun startHand() {
        gen++
        hold = false
        table = emptyList()
        tableWin = -1
        g.newHand()
        val hk = g.hakem
        push({ v ->
            if (v == hk) "دور جدید. شما حاکم هستید. پنج کارت اول شما: " + handText(v) + ". حکم را انتخاب کنید."
            else "دور جدید. " + who(hk, v) + " حاکم است و حکم را انتخاب می‌کند..."
        }, { _ -> listOf("shuffle") })
        drive()
    }

    /** Lets a robot act when it is a robot's turn (or the hakem is a robot). */
    private fun drive() {
        if (over || !started || thinking || hold) return
        when (g.phase) {
            Phase.PICK -> if (!human[g.hakem]) botTrump(g.hakem)
            Phase.PLAY -> if (!human[g.turn]) botMove(g.turn)
            else -> {}
        }
    }

    private fun botTrump(hk: Int) {
        thinking = true
        val my = gen
        try {
            pool.execute {
                val t = try { bot.chooseTrump(hk) } catch (e: Exception) { 0 }
                ui.post {
                    thinking = false
                    if (my == gen && g.phase == Phase.PICK && g.hakem == hk && !human[hk]) trumpChosen(t) else drive()
                }
            }
        } catch (e: Exception) {
            thinking = false
        }
    }

    private fun botMove(s: Int) {
        thinking = true
        val my = gen
        ui.postDelayed({
            if (my != gen) {
                thinking = false
                return@postDelayed
            }
            try {
                pool.execute {
                    val c = bot.pick(s)
                    ui.post {
                        thinking = false
                        if (my == gen && g.phase == Phase.PLAY && g.turn == s && !human[s] && !hold) doPlay(s, c) else drive()
                    }
                }
            } catch (e: Exception) {
                thinking = false
            }
        }, 700)
    }

    /** A message from a human: {"t":"trump","s":suit} or {"t":"play","id":cardId}. */
    override fun action(seat: Int, o: JSONObject) {
        if (!started || over || hold || seat !in 0..3 || !human[seat]) return
        when (o.optString("t")) {
            "trump" -> {
                val t = o.optInt("s", -1)
                if (g.phase == Phase.PICK && g.hakem == seat && t in 0..3) trumpChosen(t)
            }
            "play" -> {
                if (g.phase != Phase.PLAY || g.turn != seat || thinking) return
                val id = o.optInt("id", -1)
                val c = g.legal(seat).firstOrNull { it.id == id }
                if (c != null) doPlay(seat, c)
            }
            "sync" -> sync(seat)
        }
    }

    private fun trumpChosen(t: Int) {
        g.setTrump(t)
        val hk = g.hakem
        push({ v ->
            "حکم: " + CardText.SUIT_NAMES[t] + (if (hk == v) "" else " (انتخاب " + who(hk, v) + ")") +
                ". کارت‌های شما: " + handText(v) + "." + turnText(v)
        })
        drive()
    }

    private fun doPlay(seat: Int, c: Card) {
        val hkTeam = g.hakem % 2
        val res = g.play(seat, c)
        fun played(v: Int): String =
            who(seat, v) + " " + CardText.cardName(c) + (if (seat == v) " بازی کردید" else " بازی کرد") +
                (if (c.s == g.trump) " (حکم)." else ".")
        if (!res.trickDone) {
            table = ArrayList(g.trick)
            push({ v -> played(v) + turnText(v) }, { _ -> listOf("card") })
            drive()
            return
        }
        val w = res.winner
        table = g.lastTrick
        tableWin = w
        hold = true
        fun won(v: Int): String =
            (if (w == v) "شما دست را بردید." else who(w, v) + " دست را برد.") +
                " دست‌ها: تیم شما " + CardText.fa(g.tk[v % 2]) + "، حریف " + CardText.fa(g.tk[1 - v % 2]) + "."
        fun trickSfx(v: Int): List<String> = listOf("card", if (w % 2 == v % 2) "trick" else "tlose")
        val hand = res.hand
        val my = gen
        if (hand != null) {
            if (hand.gameOver) over = true
            push({ v -> played(v) + " " + won(v) + " " + handMessage(hand, hkTeam, v) }, { v -> trickSfx(v) + endSfx(hand, v) })
            if (!hand.gameOver) {
                ui.postDelayed({ if (my == gen) startHand() }, 4000)
            }
            return
        }
        push({ v -> played(v) + " " + won(v) }, { v -> trickSfx(v) })
        ui.postDelayed({
            if (my != gen) return@postDelayed
            hold = false
            table = emptyList()
            tableWin = -1
            push({ v -> turnText(v).trim() })
            drive()
        }, 1500)
    }

    private fun handMessage(h: HandResult, hk: Int, v: Int): String {
        val mine = h.team == v % 2
        val bn = if (h.team == hk) "بام" else "پر بام"
        if (h.bam) {
            return if (mine) "تیم شما $bn کرد و بازی را برد!" else "تیم حریف $bn کرد و بازی را برد."
        }
        if (h.gameOver) {
            return if (mine) "تیم شما بازی را برد!" else "تیم حریف بازی را برد."
        }
        val extra = if (h.kot) {
            if (h.team == hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)"
        } else " (۱ امتیاز)"
        return (if (mine) "تیم شما" else "تیم حریف") + " این دست را برد" + extra + "."
    }

    private fun endSfx(h: HandResult, v: Int): List<String> {
        val mine = h.team == v % 2
        val l = ArrayList<String>()
        if (h.kot) l.add(if (mine) "kwin" else "klose")
        if (h.gameOver) l.add(if (mine) "fwin" else "flose")
        if (!h.kot && !h.gameOver) l.add(if (mine) "win" else "lose")
        return l
    }
}
