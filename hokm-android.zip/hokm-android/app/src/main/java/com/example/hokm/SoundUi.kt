package com.example.hokm

import android.content.Context
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

/** Adds the "dealing sound speed" choice to a sound settings dialog. */
fun Sound.addDealSpeedControl(ctx: Context, box: LinearLayout) {
    val title = TextView(ctx)
    title.text = "صدای پخش کارت‌ها"
    title.setPadding(0, (12 * ctx.resources.displayMetrics.density).toInt(), 0, 0)
    box.addView(title)
    val rg = RadioGroup(ctx)
    rg.orientation = RadioGroup.VERTICAL
    val options = listOf("بدون صدای پخش (رد شدن)" to 0f, "عادی" to 1f, "سریع" to 2f, "خیلی سریع" to 4f)
    for ((i, o) in options.withIndex()) {
        val r = RadioButton(ctx)
        r.id = 200 + i
        r.text = o.first
        r.isChecked = dealSpeed == o.second
        rg.addView(r)
    }
    rg.setOnCheckedChangeListener { _, id ->
        val k = id - 200
        if (k in options.indices) setDealSpeed(options[k].second)
    }
    box.addView(rg)
}
