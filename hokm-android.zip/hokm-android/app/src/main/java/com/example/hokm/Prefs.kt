package com.example.hokm

import android.content.Context

/** The player's own settings (name, gender, card back, background, ...) kept in SharedPreferences. */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("hokm_prefs", Context.MODE_PRIVATE)

    fun hasName(c: Context): Boolean = !p(c).getString("name", "").isNullOrBlank()

    fun name(c: Context): String {
        val n = p(c).getString("name", "")?.trim() ?: ""
        return if (n.isEmpty()) "بازیکن" else n
    }

    fun setName(c: Context, n: String) {
        p(c).edit().putString("name", n.trim().take(20)).apply()
    }

    /** "f" (woman) or "m" (man): used for the figure that sits at the table for you. */
    fun gender(c: Context): String = if (p(c).getString("gender", "f") == "m") "m" else "f"

    fun setGender(c: Context, g: String) {
        p(c).edit().putString("gender", if (g == "m") "m" else "f").apply()
    }

    /** Card back design 1..35. */
    fun back(c: Context): Int = p(c).getInt("back", 1).coerceIn(1, 35)

    fun setBack(c: Context, n: Int) {
        p(c).edit().putInt("back", n.coerceIn(1, 35)).apply()
    }

    /** Table background: 0 = plain green, 1..4 = rugs. */
    fun bg(c: Context): Int = p(c).getInt("bg", 0).coerceIn(0, 4)

    fun setBg(c: Context, n: Int) {
        p(c).edit().putInt("bg", n.coerceIn(0, 4)).apply()
    }

    /** "slow", "norm" or "fast": speed of the dealing (sound) in the games. */
    fun anim(c: Context): String = p(c).getString("anim", "fast") ?: "fast"

    fun setAnim(c: Context, m: String) {
        p(c).edit().putString("anim", m).apply()
    }

    /** Screen-reader helpers: when off, messages are not put in a live region (no automatic reading). */
    fun a11y(c: Context): Boolean = p(c).getBoolean("a11y", true)

    fun setA11y(c: Context, on: Boolean) {
        p(c).edit().putBoolean("a11y", on).apply()
    }

    fun net(c: Context): String = p(c).getString("net", Net.BT) ?: Net.BT

    fun setNet(c: Context, m: String) {
        p(c).edit().putString("net", m).apply()
    }
}
