package com.example.hokm

import android.os.Handler
import com.example.hokm.engine.HakemDraw

/**
 * Plays the draw for the first hakem as sound and speech: a card sound for every card dealt, a sentence when the
 * first ace (hakem) and the second ace (partner) appear, and the result at the end. [skip] ends it at once.
 */
class DrawNarrator(private val ui: Handler, private val snd: Sound) {
    private var token = 0
    private var onDone: (() -> Unit)? = null
    private var say: ((String) -> Unit)? = null
    private var finalMsg = ""

    val running: Boolean get() = onDone != null

    /** [labels] = the name of every player (index 0 = you). With [fast] the cards are not played one by one. */
    fun run(d: HakemDraw, labels: List<String>, fast: Boolean, say: (String) -> Unit, done: () -> Unit) {
        cancel()
        val my = ++token
        onDone = done
        this.say = say
        val hText = if (d.h == 0) "شما حاکم شدید" else labels[d.h] + " حاکم شد"
        val ptText = when {
            d.n != 4 -> ""
            d.h == 0 -> labels[d.pt] + " یار شماست"
            d.pt == 0 -> "شما یار او هستید"
            else -> labels[d.pt] + " یار اوست"
        }
        finalMsg = hText + (if (d.n == 4) " و $ptText" else "") + "." +
            (if (d.seatsChange) " صندلی‌ها جابه‌جا می‌شوند تا یار روبه‌روی حاکم بنشیند." else "")
        say("تعیین حاکم: اولین آس.")
        if (fast) {
            ui.postDelayed({
                if (my == token) {
                    say(finalMsg)
                    ui.postDelayed({ if (my == token) complete() }, if (d.seatsChange) 3000L else 2000L)
                }
            }, 600)
            return
        }
        fun step(i: Int) {
            if (my != token) return
            if (i >= d.seq.size) {
                say(finalMsg)
                ui.postDelayed({ if (my == token) complete() }, if (d.seatsChange) 3200L else 2200L)
                return
            }
            snd.cardNow()
            if (i == d.i1) say("$hText.") else if (i == d.i2 && d.n == 4) say("$ptText.")
            ui.postDelayed({ step(i + 1) }, if (i < 5) 380L else 230L)
        }
        ui.postDelayed({ step(0) }, 400)
    }

    /** The player pressed "skip": announce the result and go on. */
    fun skip() {
        if (onDone == null) return
        token++
        say?.invoke(finalMsg)
        complete()
    }

    fun cancel() {
        token++
        onDone = null
    }

    private fun complete() {
        val d = onDone
        onDone = null
        d?.invoke()
    }
}
